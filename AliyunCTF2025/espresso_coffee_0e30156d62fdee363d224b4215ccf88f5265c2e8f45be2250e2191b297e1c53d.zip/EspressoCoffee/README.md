# Espresso Coffee

Buy me a cup of Espresso Coffee plz!

Here are some JDK download links you may need

```
https://gds.oracle.com/download/espresso/archive/espresso-java21-24.1.1-linux-amd64.tar.gz
https://gds.oracle.com/download/espresso/archive/espresso-java21-24.1.1-linux-aarch64.tar.gz
https://gds.oracle.com/download/espresso/archive/espresso-java21-24.1.1-macos-amd64.tar.gz
https://gds.oracle.com/download/espresso/archive/espresso-java21-24.1.1-macos-aarch64.tar.gz
https://gds.oracle.com/download/espresso/archive/espresso-java21-24.1.1-windows-amd64.zip
```
