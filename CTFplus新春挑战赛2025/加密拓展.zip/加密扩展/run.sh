#!/bin/bash

EXTENSION_PATH="./librustencphpext.so"
PHP_FILE="enc.php"

php -d extension="$EXTENSION_PATH" "$PHP_FILE"
