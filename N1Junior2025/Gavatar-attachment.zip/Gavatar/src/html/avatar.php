<?php
require_once 'common.php';

$user = isset($_GET['user']) ? findUserByUsername($_GET['user']) : null;
$defaultAvatar = __DIR__ . '/images/default-avatar.png';

if (!$user) {
    header('Content-Type: image/png');
    readfile($defaultAvatar);
    exit;
}

$avatarPath = __DIR__ . "/avatars/{$user['id']}";

if (!file_exists($avatarPath)) {
    header('Content-Type: image/png');
    readfile($defaultAvatar);
} else {
    header('Content-Type: ' . mime_content_type($avatarPath));
    readfile($avatarPath);
}
