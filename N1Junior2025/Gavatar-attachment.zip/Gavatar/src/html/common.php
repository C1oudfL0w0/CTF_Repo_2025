<?php
session_start();

function generateUuid()
{
    return sprintf(
        '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        mt_rand(0, 0xffff),
        mt_rand(0, 0xffff),
        mt_rand(0, 0xffff),
        mt_rand(0, 0x0fff) | 0x4000,
        mt_rand(0, 0x3fff) | 0x8000,
        mt_rand(0, 0xffff),
        mt_rand(0, 0xffff),
        mt_rand(0, 0xffff)
    );
}

function getDb()
{
    $dbPath = __DIR__ . '/../db/db.json';
    if (!file_exists($dbPath)) {
        file_put_contents($dbPath, json_encode(['users' => []]));
    }
    return json_decode(file_get_contents($dbPath), true) ?: ['users' => []];
}

function saveDb($data)
{
    file_put_contents(__DIR__ . '/../db/db.json', json_encode($data, JSON_PRETTY_PRINT));
}

function findUserByUsername($username)
{
    $db = getDb();
    foreach ($db['users'] as $user) {
        if ($user['username'] === $username) return $user;
    }
    return null;
}

function getCurrentUser()
{
    return isset($_SESSION['user_id']) ? findUserById($_SESSION['user_id']) : null;
}

function findUserById($id)
{
    $db = getDb();
    foreach ($db['users'] as $user) {
        if ($user['id'] === $id) return $user;
    }
    return null;
}
