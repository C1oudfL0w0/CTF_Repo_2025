<?php
require_once 'common.php';
$error = $_GET['error'] ?? '';
?>
<!DOCTYPE html>
<html lang="en" class="h-100">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gavatar: Your Avatar Service</title>
    <link rel="icon" href="/images/favicon.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .auth-card {
            border: none;
            border-radius: 1rem;
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
            overflow: hidden;
        }

        .gradient-bg {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }

        .form-control:focus {
            box-shadow: none;
            border-color: #764ba2;
        }

        .btn-primary {
            background: #764ba2;
            border: none;
            padding: 0.8rem 2rem;
            transition: all 0.3s;
        }

        .btn-primary:hover {
            background: #5a3792;
            transform: translateY(-2px);
        }
    </style>
</head>

<body class="gradient-bg h-100">
    <div class="container d-flex align-items-center justify-content-center h-100 py-5">
        <div class="row w-100 justify-content-center">
            <div class="col-lg-8">
                <?php if ($error): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?= htmlspecialchars($error) ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <div class="auth-card bg-white">
                    <div class="row g-0">
                        <div class="col-md-6 d-none d-md-block bg-primary">
                            <div class="d-flex align-items-center justify-content-center h-100 p-5 text-white">
                                <div class="text-center">
                                    <h1 class="display-5 fw-bold mb-4">Create Your Unique Avatar</h1>
                                    <p class="lead">Yet Another Gavatar Website</p>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="p-5">
                                <form method="POST" action="register.php" class="mb-4">
                                    <h3 class="mb-4 text-center">Create Account</h3>
                                    <div class="input-group mb-3">
                                        <span class="input-group-text"><i class="fas fa-user"></i></span>
                                        <input type="text" name="username" class="form-control" placeholder="Username" required>
                                    </div>
                                    <div class="input-group mb-4">
                                        <span class="input-group-text"><i class="fas fa-lock"></i></span>
                                        <input type="password" name="password" class="form-control" placeholder="Password" required>
                                    </div>
                                    <button type="submit" class="btn btn-primary w-100">
                                        <i class="fas fa-user-plus me-2"></i>Register Now
                                    </button>
                                </form>

                                <form method="POST" action="login.php">
                                    <h3 class="mb-4 text-center">Welcome Back</h3>
                                    <div class="input-group mb-3">
                                        <span class="input-group-text"><i class="fas fa-user"></i></span>
                                        <input type="text" name="username" class="form-control" placeholder="Username" required>
                                    </div>
                                    <div class="input-group mb-4">
                                        <span class="input-group-text"><i class="fas fa-lock"></i></span>
                                        <input type="password" name="password" class="form-control" placeholder="Password" required>
                                    </div>
                                    <button type="submit" class="btn btn-primary w-100">
                                        <i class="fas fa-sign-in-alt me-2"></i>Sign In
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>