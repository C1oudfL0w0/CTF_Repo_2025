<?php
require_once 'common.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

$user = findUserByUsername($_POST['username'] ?? '');

if (!$user || !password_verify($_POST['password'], $user['password'])) {
    header('Location: index.php?error=Invalid credentials');
} else {
    $_SESSION['user_id'] = $user['id'];
    header('Location: profile.php');
}
