<?php
require_once 'common.php';
$user = getCurrentUser();
if (!$user) header('Location: index.php');
?>
<!DOCTYPE html>
<html lang="en" class="h-100">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile | Gavatar</title>
    <link rel="icon" href="/images/favicon.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .profile-card {
            border: none;
            border-radius: 1.5rem;
            box-shadow: 0 1rem 2rem rgba(0, 0, 0, 0.1);
        }

        .avatar-wrapper {
            position: relative;
            width: 200px;
            height: 200px;
            margin: -100px auto 2rem;
        }

        .avatar-img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border: 5px solid white;
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.1);
        }

        .upload-btn {
            position: absolute;
            bottom: 10px;
            right: 10px;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .copy-btn {
            position: absolute;
            bottom: 10px;
            left: 10px;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
    </style>
</head>

<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="#">Gavatar</a>
            <div class="d-flex align-items-center">
                <span class="text-white me-3"><?= htmlspecialchars($user['username']) ?></span>
                <a href="logout.php" class="btn btn-outline-light">
                    <i class="fas fa-sign-out-alt"></i>
                </a>
            </div>
        </div>
    </nav>

    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="profile-card bg-white p-4">
                    <div class="avatar-wrapper">
                        <img src="avatar.php?user=<?= urlencode($user['username']) ?>"
                            class="avatar-img rounded-circle"
                            id="avatarImage">
                        <button class="btn btn-primary upload-btn" data-bs-toggle="modal" data-bs-target="#uploadModal">
                            <i class="fas fa-camera"></i>
                        </button>
                        <button class="btn btn-success copy-btn" onclick="copyAvatarUrl()">
                            <i class="fas fa-link"></i>
                        </button>
                    </div>

                    <h2 class="text-center mb-4"><?= htmlspecialchars($user['username']) ?></h2>

                    <div class="toast-container position-fixed bottom-0 end-0 p-3">
                        <div id="copyToast" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
                            <div class="toast-header">
                                <i class="fas fa-check-circle me-2 text-success"></i>
                                <strong class="me-auto">Success</strong>
                                <button type="button" class="btn-close" data-bs-dismiss="toast"></button>
                            </div>
                            <div class="toast-body">
                                Avatar URL copied to clipboard!
                            </div>
                        </div>
                    </div>

                    <div class="modal fade" id="uploadModal" tabindex="-1">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">Update Avatar</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <form method="POST" action="upload.php" enctype="multipart/form-data">
                                    <div class="modal-body">
                                        <div class="mb-4">
                                            <label class="form-label">Upload from computer</label>
                                            <input type="file" name="avatar" class="form-control" accept="image/*">
                                        </div>
                                        <div class="text-center text-muted mb-3">— OR —</div>
                                        <div class="mb-3">
                                            <label class="form-label">Use image URL</label>
                                            <div class="input-group">
                                                <span class="input-group-text"><i class="fas fa-link"></i></span>
                                                <input type="url" name="url"
                                                    class="form-control"
                                                    placeholder="https://example.com/image.jpg">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                        <button type="submit" class="btn btn-primary">Save Changes</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function copyAvatarUrl() {
            const avatarUrl = document.getElementById('avatarImage').src;
            const textArea = document.createElement('textarea');
            textArea.value = avatarUrl;
            document.body.appendChild(textArea);
            textArea.select();
            document.execCommand('copy');
            document.body.removeChild(textArea);
            showToast();
        }

        function showToast() {
            const toast = new bootstrap.Toast(document.getElementById('copyToast'));
            toast.show();

            setTimeout(() => {
                toast.hide();
            }, 3000);
        }
    </script>
</body>

</html>