<?php
require_once 'common.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

if (empty($username) || empty($password)) {
    header('Location: index.php?error=Invalid input');
    exit;
}

if (findUserByUsername($username)) {
    header('Location: index.php?error=Username already exists');
    exit;
}

$user = [
    'id' => generateUuid(),
    'username' => $username,
    'password' => password_hash($password, PASSWORD_DEFAULT)
];

$db = getDb();
$db['users'][] = $user;
saveDb($db);

$_SESSION['user_id'] = $user['id'];
header('Location: profile.php');
