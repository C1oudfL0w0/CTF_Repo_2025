<h1>Ser Value</h1>
<p><?= h($ser) ?></p>
