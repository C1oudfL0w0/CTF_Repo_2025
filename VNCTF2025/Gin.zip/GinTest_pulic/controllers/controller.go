package controllers

import (
	"GinTest/config"
	"GinTest/model"
	"GinTest/response"
	"GinTest/utils"
	"bufio"
	"fmt"
	"github.com/gin-gonic/gin"
	"golang.org/x/crypto/bcrypt"
	"gorm.io/gorm"
	"io"
	"io/ioutil"
	"log"
	"mime/multipart"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"regexp"
	"strings"
)

var DB = config.InitDB()

func Register(c *gin.Context) {
	var requestUser = model.User{}
	c.Bind(&requestUser)
	username := requestUser.Username
	password := requestUser.Password

	if len(username) == 0 || len(password) == 0 {
		response.Response(c, http.StatusBadRequest, 400, nil, "账号或密码不能为空")
		return
	}

	if len(password) < 6 {
		response.Response(c, http.StatusBadRequest, 400, nil, "密码不能小于6位")
		return
	}

	if isUserExist(DB, username) {
		response.Response(c, http.StatusConflict, 409, nil, "用户已存在")
		return
	}

	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		response.Response(c, http.StatusInternalServerError, 500, nil, "加密错误")
		log.Printf("password hashing failed: %v", err)
		return
	}
	newUser := model.User{
		Username: username,
		Password: string(hashedPassword),
	}
	DB.Create(&newUser)
	response.Success(c, nil, "注册成功")
}

func isUserExist(db *gorm.DB, username string) bool {
	user := model.User{}
	db.Where("username = ?", username).First(&user)
	if user.ID != 0 {
		return true
	}
	return false
}

func Login(c *gin.Context) {
	var requestUser = model.User{}
	c.Bind(&requestUser)
	username := requestUser.Username
	password := requestUser.Password

	if len(username) == 0 || len(password) == 0 {
		response.Response(c, http.StatusBadRequest, 400, nil, "账号或密码不能为空")
		return
	}

	if len(password) < 6 {
		response.Response(c, http.StatusBadRequest, 400, nil, "密码不能小于6位")
		return
	}

	user := model.User{}
	DB.Where("username = ?", username).First(&user)
	if user.ID == 0 {
		response.Response(c, http.StatusNotFound, 404, nil, "用户不存在")
		return
	}

	if err := bcrypt.CompareHashAndPassword([]byte(user.Password), []byte(password)); err != nil {
		response.Response(c, http.StatusUnauthorized, 401, nil, "密码错误")
		log.Printf("密码错误：%v", err)
		return
	}

	token, err := utils.GenerateToken(user.Username)
	if err != nil {
		response.Response(c, http.StatusInternalServerError, 500, nil, "加密错误")
		log.Printf("token generate error: %v", err)
	}

	response.Success(c, gin.H{"token": token}, "登录成功")
}

func Upload(c *gin.Context) {
	file, _ := c.FormFile("file")
	contentDisposition := file.Header["Content-Disposition"][0]
	filename := parseFilenameFromContentDisposition(contentDisposition)
	if filename == "" {
		fmt.Println("Failed to parse filename from Content-Disposition")
		return
	}
	in, _ := file.Open()
	log.Println(in)
	defer in.Close()
	hasMaliciousContent, err := containsMaliciousContent(in)
	if err != nil {
		response.Response(c, http.StatusInternalServerError, 500, nil, "Error checking file content")
		return
	}
	if hasMaliciousContent {
		response.Response(c, http.StatusBadRequest, 400, nil, "File contains malicious content")
		return
	}
	in.Seek(0, io.SeekStart)
	basepath := "./uploads"
	filepath, _ := url.JoinPath(basepath, filename)
	out, _ := os.Create(filepath)
	defer out.Close()
	log.Println(in)
	io.Copy(out, in)
	log.Println(out)
	log.Println(filepath)
	downloadLink := "/download?filename=" + filename
	response.Success(c, gin.H{"filepath": filepath, "downloadLink": downloadLink}, "upload success")
}

func parseFilenameFromContentDisposition(contentDisposition string) string {
	parts := strings.Split(contentDisposition, ";")
	for _, part := range parts {
		part = strings.TrimSpace(part)
		if strings.HasPrefix(part, "filename=") {
			filename := strings.TrimPrefix(part, "filename=")
			filename = strings.Trim(filename, `"`) 
			return filename
		}
	}
	return ""
}

func containsMaliciousContent(file multipart.File) (bool, error) {
	maliciousPatterns := []string{
		"package",
		"<script>",
		"eval(",
		"base64",
		"file://",
		"exec",
		"flag",
		"cat",
		"bash",
		"/bin",
		"import",
	}

	reader := bufio.NewReader(file)

	for {
		line, err := reader.ReadString('\n')
		if err != nil && err != io.EOF {
			return false, err
		}

		for _, pattern := range maliciousPatterns {
			if strings.Contains(line, pattern) {
				return true, nil
			}
		}

		if err == io.EOF {
			break
		}
	}
	return false, nil
}

func Download(c *gin.Context) {
	filename := c.DefaultQuery("filename", "")
	if filename == "" {
		response.Response(c, http.StatusBadRequest, 400, nil, "Filename is required")
	}
	basepath := "./uploads"
	filepath, _ := url.JoinPath(basepath, filename)
	if _, err := os.Stat(filepath); os.IsNotExist(err) {
		response.Response(c, http.StatusBadRequest, 404, nil, "File not found")
	}
	c.Header("Content-Disposition", "attachment; filename="+filename)
	c.File(filepath)
}

func Eval(c *gin.Context) {
	code := c.PostForm("code")
	log.Println(code)
	if code == "" {
		response.Response(c, http.StatusBadRequest, 400, nil, "No code provided")
		return
	}
	log.Println(containsBannedPackages(code))
	if containsBannedPackages(code) {
		response.Response(c, http.StatusBadRequest, 400, nil, "Code contains banned packages")
		return
	}
	tmpFile, err := ioutil.TempFile("", "goeval-*.go")
	if err != nil {
		log.Println("Error creating temp file:", err)
		response.Response(c, http.StatusInternalServerError, 500, nil, "Error creating temporary file")
		return
	}
	defer os.Remove(tmpFile.Name())

	_, err = tmpFile.WriteString(code)
	if err != nil {
		log.Println("Error writing code to temp file:", err)
		response.Response(c, http.StatusInternalServerError, 500, nil, "Error writing code to temp file")
		return
	}

	cmd := exec.Command("go", "run", tmpFile.Name())
	output, err := cmd.CombinedOutput()
	if err != nil {
		log.Println("Error running Go code:", err)
		response.Response(c, http.StatusInternalServerError, 500, gin.H{"error": string(output)}, "Error executing code")
		return
	}

	response.Success(c, gin.H{"result": string(output)}, "success")
}

func containsBannedPackages(code string) bool {
	importRegex := `(?i)import\s*\((?s:.*?)\)`
	re := regexp.MustCompile(importRegex)
	matches := re.FindStringSubmatch(code)
	imports := matches[0]
	log.Println(imports)
	if strings.Contains(imports, "os/exec") {
		return true
	}

	return false
}
