package dto

import "GinTest/model"

type UserDto struct {
	Name string `json:"name"`
}

func ToUserDto(user model.User) UserDto {
	return UserDto{
		Name: user.Username,
	}
}
