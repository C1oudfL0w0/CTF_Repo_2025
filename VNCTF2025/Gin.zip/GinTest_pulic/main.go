package main

import (
	"GinTest/middleware"
	"GinTest/routes"
	"github.com/gin-gonic/gin"
)

func main() {
	r := gin.Default()
	r.Use(middleware.CORSMiddleware())
	r.Static("/static", "./static")
	r.Static("/uploads", "./uploads")
	routes.SetupRoutes(r)
	panic(r.Run(":8888"))
}
