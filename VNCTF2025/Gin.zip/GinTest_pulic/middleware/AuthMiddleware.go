package middleware

import (
	"GinTest/controllers"
	"GinTest/model"
	"GinTest/response"
	"GinTest/utils"
	"github.com/gin-gonic/gin"
	"net/http"
)

func AuthMiddleware(Role string) gin.HandlerFunc {
	return func(c *gin.Context) {
		tokenString, err := c.Cookie("token")
		if err != nil {
			response.Response(c, http.StatusUnauthorized, 401, nil, "权限不足")
			c.Abort()
			return
		}

		token, err := utils.ParseToken(tokenString)
		if err != nil {
			response.Response(c, http.StatusUnauthorized, 401, nil, "权限不足")
			c.Abort()
			return
		}

		username := token.Username
		DB := controllers.DB
		var user model.User
		DB.Where("username = ?", username).First(&user)

		if user.ID == 0 {
			response.Response(c, http.StatusUnauthorized, 401, nil, "权限不足")
			c.Abort()
			return
		}

		if Role == "admin" {
			if user.Username != "admin" {
				response.Response(c, http.StatusUnauthorized, 401, nil, "权限不足")
				c.Abort()
				return
			}
		}

		c.Set("user", user)
		c.Next()
	}

}
