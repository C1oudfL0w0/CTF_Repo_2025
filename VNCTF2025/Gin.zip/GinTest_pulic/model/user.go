package model

type User struct {
	ID       uint   `gorm:"primaryKey" json:"id"`
	Username string `gorm:"type:varchar(45);not null" json:"username"`
	Password string `gorm:"size:255;not null" json:"password"`
}
