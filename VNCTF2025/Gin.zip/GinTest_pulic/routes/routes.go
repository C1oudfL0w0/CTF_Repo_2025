package routes

import (
	"GinTest/controllers"
	"GinTest/middleware"
	"github.com/gin-gonic/gin"
	"net/http"
)

func SetupRoutes(r *gin.Engine) *gin.Engine {
	r.GET("/", func(c *gin.Context) {
		c.Redirect(http.StatusFound, "/login")
	})
	r.GET("/register", func(c *gin.Context) {
		c.File("./static/register.html")
	})
	r.POST("/register", controllers.Register)
	r.GET("/login", func(c *gin.Context) {
		c.File("./static/login.html")
	})
	r.POST("/login", controllers.Login)
	r.GET("/user", middleware.AuthMiddleware("user"), func(c *gin.Context) {
		c.File("./static/user.html")
	})
	r.POST("/upload", middleware.AuthMiddleware("upload"), controllers.Upload)
	r.GET("/download", middleware.AuthMiddleware("download"), controllers.Download)
	r.GET("/admin", middleware.AuthMiddleware("admin"), func(c *gin.Context) {
		c.File("./static/admin.html")
	})
	r.POST("/eval", middleware.AuthMiddleware("admin"), controllers.Eval)
	return r
}
