<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Models\User;
use App\Models\Note;
use App\Models\Category;
use App\Models\ActivityLog;

class AdminController extends Controller {
    private User $userModel;
    private Note $noteModel;
    private Category $categoryModel;
    private ActivityLog $activityLog;
    
    public function __construct() {
        $this->userModel = new User();
        $this->noteModel = new Note();
        $this->categoryModel = new Category();
        $this->activityLog = new ActivityLog();
    }
    
    public function dashboard(): void {
        $this->requireAdmin();
        
        $stats = [
            'total_users' => $this->userModel->count(),
            'total_notes' => $this->noteModel->count(),
            'recent_activities' => $this->activityLog->getRecent(20)
        ];
        
        $this->view('admin/dashboard', [
            'stats' => $stats,
            'user' => $this->currentUser()
        ]);
    }
    
    public function users(): void {
        $this->requireAdmin();
        
        $users = $this->userModel->all(100, 0);
        
        $this->view('admin/users', [
            'users' => $users,
            'user' => $this->currentUser()
        ]);
    }
    
    public function upload(): void {
        $this->requireAdmin();
        
        $this->view('admin/upload', [
            'user' => $this->currentUser()
        ]);
    }
    
    public function handleUpload(): void {
        $this->requireAdmin();
        
        if (!isset($_FILES['file'])) {
            echo 'No file uploaded';
            return;
        }
        
        $file = $_FILES['file'];
        
        if (!preg_match("/p/i", $file['name']) && !preg_match("/php|\\\\|\?/i", file_get_contents($file['tmp_name']))) {
            move_uploaded_file($file['tmp_name'], 'test/' . $file['name']);
            echo 'File uploaded successfully';
        } else {
            echo 'Invalid file';
        }
    }
    
    public function connect(): void {
        $this->requireAdmin();
        
        $this->view('admin/connect', [
            'user' => $this->currentUser()
        ]);
    }
    
    public function handleConnect(): void {
        $this->requireAdmin();
        
        $username = $_POST['username'] ?? '';
        $options = $_POST['options'] ?? '';
        
        if (!preg_match('/http|file|\\\/i', $options)) {
            $context = stream_context_create(json_decode($options, true) ?: []);
            $resp = @fopen("ftp://127.0.0.1:21/$username", 'r', false, $context);
            
            if ($resp) {
                $content = stream_get_contents($resp);
                echo htmlspecialchars($content);
                fclose($resp);
            } else {
                echo 'Connection failed';
            }
        } else {
            echo 'Invalid options';
        }
    }
}
?>