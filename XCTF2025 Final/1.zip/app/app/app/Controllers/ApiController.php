<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Models\Note;
use App\Models\User;
use App\Models\Category;
use App\Models\Tag;

class ApiController extends Controller {
    private Note $noteModel;
    private User $userModel;
    private Category $categoryModel;
    private Tag $tagModel;
    
    public function __construct() {
        $this->noteModel = new Note();
        $this->userModel = new User();
        $this->categoryModel = new Category();
        $this->tagModel = new Tag();
    }
    
    public function notes(): void {
        $page = max(1, (int)($_GET['page'] ?? 1));
        $perPage = min(100, (int)($_GET['per_page'] ?? 20));
        $offset = ($page - 1) * $perPage;
        
        $notes = $this->noteModel->findPublic($perPage, $offset);
        $total = $this->noteModel->count();
        
        $this->json([
            'data' => $notes,
            'pagination' => [
                'page' => $page,
                'per_page' => $perPage,
                'total' => $total,
                'total_pages' => ceil($total / $perPage)
            ]
        ]);
    }
    
    public function note(string $id): void {
        $note = $this->noteModel->findById($id);
        
        if (!$note) {
            $this->json(['error' => 'Note not found'], 404);
            return;
        }
        
        if (!$note['is_public']) {
            $this->json(['error' => 'Access denied'], 403);
            return;
        }
        
        $tags = $this->tagModel->getByNote($id);
        $note['tags'] = $tags;
        
        $this->json(['data' => $note]);
    }
    
    public function user(string $username): void {
        $user = $this->userModel->findByUsername($username);
        
        if (!$user) {
            $this->json(['error' => 'User not found'], 404);
            return;
        }
        
        $this->json([
            'data' => [
                'id' => $user['id'],
                'username' => $user['username'],
                'bio' => $user['bio'] ?? '',
                'created_at' => $user['created_at']
            ]
        ]);
    }
    
    public function categories(): void {
        $categories = $this->categoryModel->all();
        $this->json(['data' => $categories]);
    }
    
    public function tags(): void {
        $tags = $this->tagModel->all();
        $this->json(['data' => $tags]);
    }
    
    public function search(): void {
        $query = $_GET['q'] ?? '';
        
        if (empty($query)) {
            $this->json(['error' => 'Query parameter required'], 400);
            return;
        }
        
        $page = max(1, (int)($_GET['page'] ?? 1));
        $perPage = min(100, (int)($_GET['per_page'] ?? 20));
        $offset = ($page - 1) * $perPage;
        
        $notes = $this->noteModel->search($query, $perPage, $offset);
        
        $this->json([
            'data' => $notes,
            'query' => $query,
            'pagination' => [
                'page' => $page,
                'per_page' => $perPage
            ]
        ]);
    }
    
    public function popular(): void {
        $limit = min(50, (int)($_GET['limit'] ?? 10));
        $popular = $this->noteModel->popular($limit);
        
        $this->json(['data' => $popular]);
    }
}
?>