<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Services\FileService;
use App\Models\Note;
use App\Models\Attachment;

class AttachmentController extends Controller {
    private FileService $fileService;
    private Note $noteModel;
    private Attachment $attachmentModel;
    
    public function __construct() {
        $this->fileService = new FileService();
        $this->noteModel = new Note();
        $this->attachmentModel = new Attachment();
    }
    
    public function upload(string $noteId): void {
        $this->requireAuth();
        $user = $this->currentUser();
        
        $note = $this->noteModel->findById($noteId);
        
        if (!$note || $note['user_id'] !== $user['id']) {
            http_response_code(403);
            echo 'Access denied';
            return;
        }
        
        if (!isset($_FILES['file'])) {
            \Session::flash('error', 'No file uploaded');
            $this->redirect('/notes/' . $noteId);
            return;
        }
        
        try {
            $this->fileService->upload($noteId, $_FILES['file']);
            \Session::flash('success', 'File uploaded successfully');
        } catch (\Exception $e) {
            \Session::flash('error', $e->getMessage());
        }
        
        $this->redirect('/notes/' . $noteId);
    }
    
    public function download(string $id): void {
        $attachment = $this->attachmentModel->findById($id);
        
        if (!$attachment) {
            http_response_code(404);
            echo 'File not found';
            return;
        }
        
        $filepath = $this->fileService->getFilePath($attachment['filename']);
        
        if (!file_exists($filepath)) {
            http_response_code(404);
            echo 'File not found';
            return;
        }
        
        header('Content-Type: ' . $attachment['mime_type']);
        header('Content-Disposition: attachment; filename="' . $attachment['original_name'] . '"');
        header('Content-Length: ' . filesize($filepath));
        
        readfile($filepath);
        exit;
    }
    
    public function delete(string $id): void {
        $this->requireAuth();
        $user = $this->currentUser();
        
        $attachment = $this->attachmentModel->findById($id);
        
        if (!$attachment) {
            http_response_code(404);
            echo 'File not found';
            return;
        }
        
        $note = $this->noteModel->findById($attachment['note_id']);
        
        if (!$note || $note['user_id'] !== $user['id']) {
            http_response_code(403);
            echo 'Access denied';
            return;
        }
        
        $this->fileService->delete($id);
        
        \Session::flash('success', 'File deleted');
        $this->redirect('/notes/' . $attachment['note_id']);
    }
}
?>