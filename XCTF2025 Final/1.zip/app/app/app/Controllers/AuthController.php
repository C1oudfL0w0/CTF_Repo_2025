<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Models\User;
use App\Models\ActivityLog;

class AuthController extends Controller {
    private User $userModel;
    private ActivityLog $activityLog;
    
    public function __construct() {
        $this->userModel = new User();
        $this->activityLog = new ActivityLog();
    }
    
    public function showLogin(): void {
        $this->view('auth/login', [
            'error' => \Session::getFlash('error')
        ]);
    }
    
    public function login(): void {
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        
        $user = $this->userModel->findByUsername($username);
        
        if ($user && password_verify($password, $user['password_hash'])) {
            \Session::regenerate();
            \Session::set('user', [
                'id' => $user['id'],
                'username' => $user['username'],
                'email' => $user['email'],
                'role' => $user['role'],
                'chance' => $user['chance']
            ]);
            
            $this->userModel->updateLastLogin($user['id']);
            $this->activityLog->log($user['id'], 'login');
            
            \Session::flash('success', 'Welcome back!');
            $this->redirect('/');
        } else {
            $this->activityLog->log(null, 'failed_login', null, null, ['username' => $username]);
            \Session::flash('error', 'Invalid credentials');
            $this->redirect('/login');
        }
    }
    
    public function showRegister(): void {
        $this->view('auth/register', [
            'error' => \Session::getFlash('error')
        ]);
    }
    
    public function register(): void {
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        $email = trim($_POST['email'] ?? '');
        
        if (strlen($username) < 3 || strlen($username) > 32) {
            \Session::flash('error', 'Username must be 3-32 characters');
            $this->redirect('/register');
            return;
        }
        
        if (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
            \Session::flash('error', 'Username can only contain letters, numbers and underscores');
            $this->redirect('/register');
            return;
        }
        
        if ($this->userModel->findByUsername($username)) {
            \Session::flash('error', 'Username already exists');
            $this->redirect('/register');
            return;
        }
        
        if (strlen($password) < 6) {
            \Session::flash('error', 'Password must be at least 6 characters');
            $this->redirect('/register');
            return;
        }
        
        $hash = password_hash($password, PASSWORD_BCRYPT);
        $user = $this->userModel->create($username, $hash, $email);
        
        \Session::set('user', $user);
        $this->activityLog->log($user['id'], 'register');
        
        \Session::flash('success', 'Registration successful!');
        $this->redirect('/');
    }
    
    public function logout(): void {
        $user = $this->currentUser();
        if ($user) {
            $this->activityLog->log($user['id'], 'logout');
        }
        
        \Session::destroy();
        $this->redirect('/');
    }
    
    public function profile(): void {
        $this->requireAuth();
        $user = $this->currentUser();
        $profile = $this->userModel->findById($user['id']);
        
        $this->view('auth/profile', [
            'user' => $profile,
            'success' => \Session::getFlash('success'),
            'error' => \Session::getFlash('error')
        ]);
    }
    
    public function updateProfile(): void {
        $this->requireAuth();
        $user = $this->currentUser();
        
        $email = trim($_POST['email'] ?? '');
        $bio = trim($_POST['bio'] ?? '');
        
        $this->userModel->update($user['id'], [
            'email' => $email,
            'bio' => $bio
        ]);
        
        $this->activityLog->log($user['id'], 'update_profile');
        \Session::flash('success', 'Profile updated');
        $this->redirect('/profile');
    }
}
?>