<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Models\Comment;
use App\Models\Note;
use App\Models\ActivityLog;

class CommentController extends Controller {
    private Comment $commentModel;
    private Note $noteModel;
    private ActivityLog $activityLog;
    
    public function __construct() {
        $this->commentModel = new Comment();
        $this->noteModel = new Note();
        $this->activityLog = new ActivityLog();
    }
    
    public function store(string $noteId): void {
        $this->requireAuth();
        $user = $this->currentUser();
        
        $note = $this->noteModel->findById($noteId);
        if (!$note) {
            http_response_code(404);
            echo 'Note not found';
            return;
        }
        
        $content = trim($_POST['content'] ?? '');
        $parentId = $_POST['parent_id'] ?? null;
        
        if (empty($content)) {
            \Session::flash('error', 'Comment cannot be empty');
            $this->redirect('/notes/' . $noteId);
            return;
        }
        
        $commentId = $this->commentModel->create($noteId, $user['id'], $content, $parentId);
        $this->activityLog->log($user['id'], 'create_comment', 'comment', $commentId);
        
        \Session::flash('success', 'Comment posted');
        $this->redirect('/notes/' . $noteId);
    }
    
    public function delete(string $id): void {
        $this->requireAuth();
        $user = $this->currentUser();
        
        $comment = $this->commentModel->findById($id);
        
        if (!$comment) {
            http_response_code(404);
            echo 'Comment not found';
            return;
        }
        
        if ($comment['user_id'] !== $user['id']) {
            http_response_code(403);
            echo 'Access denied';
            return;
        }
        
        $noteId = $comment['note_id'];
        $this->commentModel->delete($id);
        $this->activityLog->log($user['id'], 'delete_comment', 'comment', $id);
        
        \Session::flash('success', 'Comment deleted');
        $this->redirect('/notes/' . $noteId);
    }
}
?>