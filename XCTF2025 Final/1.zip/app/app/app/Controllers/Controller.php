<?php
declare(strict_types=1);

namespace App\Controllers;

abstract class Controller {
    
    protected function view(string $template, array $data = []): void {
        extract($data);
        $viewPath = __DIR__ . '/../../views/' . $template . '.php';
        
        if (file_exists($viewPath)) {
            require $viewPath;
        } else {
            http_response_code(500);
            echo "View not found: $template";
        }
    }
    
    protected function json($data, int $code = 200): void {
        http_response_code($code);
        header('Content-Type: application/json');
        echo json_encode($data);
        exit;
    }
    
    protected function redirect(string $path): void {
        header("Location: $path");
        exit;
    }
    
    protected function currentUser(): ?array {
        return \Session::get('user');
    }
    
    protected function requireAuth(): void {
        if (!$this->currentUser()) {
            \Session::flash('error', 'Please login to continue');
            $this->redirect('/login');
        }
    }
    
    protected function requireAdmin(): void {
        $user = $this->currentUser();
        if (!$user || $user['role'] !== 'admin') {
            http_response_code(403);
            echo 'Access denied';
            exit;
        }
    }
}
?>