<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Models\Note;
use App\Models\Category;
use App\Models\Tag;
use App\Models\Comment;
use App\Models\Favorite;
use App\Models\ActivityLog;
use App\Models\User;

class NoteController extends Controller {
    private Note $noteModel;
    private Category $categoryModel;
    private Tag $tagModel;
    private Comment $commentModel;
    private Favorite $favoriteModel;
    private ActivityLog $activityLog;
    private User $userModel;
    
    public function __construct() {
        $this->noteModel = new Note();
        $this->categoryModel = new Category();
        $this->tagModel = new Tag();
        $this->commentModel = new Comment();
        $this->favoriteModel = new Favorite();
        $this->activityLog = new ActivityLog();
        $this->userModel = new User();
    }
    
    public function index(): void {
        $page = max(1, (int)($_GET['page'] ?? 1));
        $perPage = 20;
        $offset = ($page - 1) * $perPage;
        
        $categoryId = $_GET['category'] ?? null;
        $search = $_GET['search'] ?? null;
        
        if ($search) {
            $notes = $this->noteModel->search($search, $perPage, $offset);
            $total = 0;
        } elseif ($categoryId) {
            $notes = $this->noteModel->findByCategory($categoryId, $perPage, $offset);
            $total = 0;
        } else {
            $notes = $this->noteModel->findPublic($perPage, $offset);
            $total = $this->noteModel->count();
        }
        
        $categories = $this->categoryModel->all();
        $popular = $this->noteModel->popular(5);
        
        $this->view('home', [
            'notes' => $notes,
            'categories' => $categories,
            'popular' => $popular,
            'currentCategory' => $categoryId,
            'search' => $search,
            'page' => $page,
            'totalPages' => ceil($total / $perPage),
            'user' => $this->currentUser(),
            'success' => \Session::getFlash('success'),
            'error' => \Session::getFlash('error')
        ]);
    }
    
    public function show(string $id): void {
        $note = $this->noteModel->findById($id);
        
        if (!$note) {
            http_response_code(404);
            echo 'Note not found';
            return;
        }
        
        $user = $this->currentUser();
        $isOwner = $user && $user['id'] === $note['user_id'];
        
        if (!$note['is_public']) {
            if (isset($_GET['password']) && $_GET['password'] !== '' && password_verify($_GET['password'], $note['password_hash'])) {
                
            } else if ($isOwner) {

            } else {
                http_response_code(403);
                echo 'Access denied';
                return;
            }
        }
        
        $this->noteModel->incrementViews($id);
        
        $tags = $this->tagModel->getByNote($id);
        $comments = $this->commentModel->getByNote($id);
        $isFavorited = $user ? $this->favoriteModel->exists($user['id'], $id) : false;
        
        $this->view('notes/show', [
            'note' => $note,
            'tags' => $tags,
            'comments' => $comments,
            'isOwner' => $isOwner,
            'isFavorited' => $isFavorited,
            'user' => $user,
            'success' => \Session::getFlash('success'),
            'error' => \Session::getFlash('error')
        ]);
    }
    
    public function create(): void {
        $this->requireAuth();
        $categories = $this->categoryModel->all();
        
        $this->view('notes/create', [
            'categories' => $categories,
            'user' => $this->currentUser()
        ]);
    }
    
    public function store(): void {
        $this->requireAuth();
        $user = $this->currentUser();

        if ($user['chance'] <= 0) {
            \Session::flash('error', 'Only 2 notes per day');
            $this->redirect('/profile');
            return;
        }
        
        $title = trim($_POST['title'] ?? '');
        $content = $_POST['content'] ?? '';
        $categoryId = $_POST['category_id'] ?? null;
        $tagInput = $_POST['tags'] ?? '';
        $isPublic = isset($_POST['is_public']) ? 1 : 0;
        
        if (empty($title) || empty($content)) {
            \Session::flash('error', 'Title and content are required');
            $this->redirect('/notes/create');
            return;
        }
        
        
        $id = $this->noteModel->create([
            'user_id' => $user['id'],
            'title' => $title,
            'content' => $content,
            'category_id' => $categoryId,
            'is_public' => $isPublic
        ]);
        
        if ($tagInput) {
            $tagNames = array_map('trim', explode(',', $tagInput));
            foreach ($tagNames as $tagName) {
                if (!empty($tagName)) {
                    $tag = $this->tagModel->findOrCreate($tagName);
                    $this->tagModel->attachToNote($id, $tag['id']);
                }
            }
        }
        
        $_SESSION['user']['chance'] -= 1;
        $this->userModel->decrementChance($user['id']);
        $this->activityLog->log($user['id'], 'create_note', 'note', $id);
        
        \Session::flash('success', 'Note created successfully');
        $this->redirect('/notes/' . $id);
    }
    
    public function edit(string $id): void {
        $this->requireAuth();
        $user = $this->currentUser();
        
        $note = $this->noteModel->findById($id);
        
        if (!$note || $note['user_id'] !== $user['id']) {
            http_response_code(403);
            echo 'Access denied';
            return;
        }
        
        $categories = $this->categoryModel->all();
        $tags = $this->tagModel->getByNote($id);
        
        $this->view('notes/edit', [
            'note' => $note,
            'categories' => $categories,
            'tags' => $tags,
            'user' => $user
        ]);
    }
    
    public function update(string $id): void {
        $this->requireAuth();
        $user = $this->currentUser();
        
        $note = $this->noteModel->findById($id);
        
        if (!$note || $note['user_id'] !== $user['id']) {
            http_response_code(403);
            echo 'Access denied';
            return;
        }
        
        $title = trim($_POST['title'] ?? '');
        $content = $_POST['content'] ?? '';
        $categoryId = $_POST['category_id'] ?? null;
        $tagInput = $_POST['tags'] ?? '';
        $isPublic = isset($_POST['is_public']) ? 1 : 0;
        
        $this->noteModel->update($id, [
            'title' => $title,
            'content' => $content,
            'category_id' => $categoryId,
            'is_public' => $isPublic
        ]);
        
        $this->tagModel->clearNote($id);
        if ($tagInput) {
            $tagNames = array_map('trim', explode(',', $tagInput));
            foreach ($tagNames as $tagName) {
                if (!empty($tagName)) {
                    $tag = $this->tagModel->findOrCreate($tagName);
                    $this->tagModel->attachToNote($id, $tag['id']);
                }
            }
        }
        
        $this->activityLog->log($user['id'], 'update_note', 'note', $id);
        
        \Session::flash('success', 'Note updated');
        $this->redirect('/notes/' . $id);
    }
    
    public function delete(string $id): void {
        $this->requireAuth();
        $user = $this->currentUser();
        
        $note = $this->noteModel->findById($id);
        
        if (!$note || $note['user_id'] !== $user['id']) {
            http_response_code(403);
            echo 'Access denied';
            return;
        }
        
        $this->noteModel->delete($id);
        $this->activityLog->log($user['id'], 'delete_note', 'note', $id);
        
        \Session::flash('success', 'Note deleted');
        $this->redirect('/my-notes');
    }
    
    public function myNotes(): void {
        $this->requireAuth();
        $user = $this->currentUser();
        
        $notes = $this->noteModel->findByUser($user['id']);
        
        $this->view('notes/my_notes', [
            'notes' => $notes,
            'user' => $user,
            'success' => \Session::getFlash('success')
        ]);
    }
    
    public function favorites(): void {
        $this->requireAuth();
        $user = $this->currentUser();
        
        $favorites = $this->favoriteModel->getByUser($user['id']);
        
        $this->view('notes/favorites', [
            'favorites' => $favorites,
            'user' => $user
        ]);
    }
    
    public function toggleFavorite(string $id): void {
        $this->requireAuth();
        $user = $this->currentUser();
        
        $added = $this->favoriteModel->toggle($user['id'], $id);
        
        $action = $added ? 'favorite_note' : 'unfavorite_note';
        $this->activityLog->log($user['id'], $action, 'note', $id);
        
        $message = $added ? 'Added to favorites' : 'Removed from favorites';
        \Session::flash('success', $message);
        
        $this->redirect('/notes/' . $id);
    }

    public function prize(): void {
        $this->requireAuth();
        $user = $this->currentUser();
        
        $count = $this->noteModel->countByUser($user['id']);
        if ($count >= 10) {
            echo file_get_contents('/flag');
        } else {
            echo "work hard";
        }
    }
}
?>