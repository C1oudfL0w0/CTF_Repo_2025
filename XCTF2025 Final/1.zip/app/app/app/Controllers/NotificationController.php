<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Services\NotificationService;

class NotificationController extends Controller {
    private NotificationService $notificationService;
    
    public function __construct() {
        $this->notificationService = new NotificationService();
    }
    
    public function index(): void {
        $this->requireAuth();
        $user = $this->currentUser();
        
        $notifications = $this->notificationService->getByUser($user['id']);
        
        $this->view('notifications/index', [
            'notifications' => $notifications,
            'user' => $user
        ]);
    }
    
    public function markAsRead(string $id): void {
        $this->requireAuth();
        
        $this->notificationService->markAsRead($id);
        
        $this->json(['success' => true]);
    }
    
    public function markAllAsRead(): void {
        $this->requireAuth();
        $user = $this->currentUser();
        
        $this->notificationService->markAllAsRead($user['id']);
        
        \Session::flash('success', 'All notifications marked as read');
        $this->redirect('/notifications');
    }
    
    public function count(): void {
        $this->requireAuth();
        $user = $this->currentUser();
        
        $count = $this->notificationService->countUnread($user['id']);
        
        $this->json(['count' => $count]);
    }
}
?>