<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Services\SearchService;

class SearchController extends Controller {
    private SearchService $searchService;
    
    public function __construct() {
        $this->searchService = new SearchService();
    }
    
    public function index(): void {
        $query = $_GET['q'] ?? '';
        $type = $_GET['type'] ?? 'notes';
        
        $page = max(1, (int)($_GET['page'] ?? 1));
        $perPage = 20;
        $offset = ($page - 1) * $perPage;
        
        $results = [];
        
        switch ($type) {
            case 'notes':
                $results = $this->searchService->searchNotes($query, [
                    'limit' => $perPage,
                    'offset' => $offset
                ]);
                break;
            case 'users':
                $results = $this->searchService->searchUsers($query);
                break;
            case 'tags':
                $results = $this->searchService->searchByTag($query, [
                    'limit' => $perPage,
                    'offset' => $offset
                ]);
                break;
        }
        
        $this->view('search/results', [
            'query' => $query,
            'type' => $type,
            'results' => $results,
            'page' => $page,
            'user' => $this->currentUser()
        ]);
    }
    
    public function suggest(): void {
        $query = $_GET['q'] ?? '';
        
        if (strlen($query) < 2) {
            $this->json(['suggestions' => []]);
            return;
        }
        
        $notes = $this->searchService->searchNotes($query, ['limit' => 5]);
        
        $suggestions = array_map(function($note) {
            return [
                'id' => $note['id'],
                'title' => $note['title'],
                'type' => 'note'
            ];
        }, $notes);
        
        $this->json(['suggestions' => $suggestions]);
    }
}
?>