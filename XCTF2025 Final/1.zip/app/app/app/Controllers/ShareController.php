<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Models\Share;
use App\Models\Note;
use App\Models\ActivityLog;

class ShareController extends Controller {
    private Share $shareModel;
    private Note $noteModel;
    private ActivityLog $activityLog;
    
    public function __construct() {
        $this->shareModel = new Share();
        $this->noteModel = new Note();
        $this->activityLog = new ActivityLog();
    }
    
    public function create(string $noteId): void {
        $this->requireAuth();
        $user = $this->currentUser();
        
        $note = $this->noteModel->findById($noteId);
        
        if (!$note || $note['user_id'] !== $user['id']) {
            http_response_code(403);
            echo 'Access denied';
            return;
        }
        
        $password = $_POST['password'] ?? null;
        $expiresAt = $_POST['expires_at'] ?? null;
        $maxViews = !empty($_POST['max_views']) ? (int)$_POST['max_views'] : null;
        
        $share = $this->shareModel->create($noteId, $password, $expiresAt, $maxViews);
        $this->activityLog->log($user['id'], 'create_share', 'share', $share['id']);
        
        \Session::flash('success', 'Share link created');
        \Session::flash('share_code', $share['share_code']);
        
        $this->redirect('/notes/' . $noteId);
    }
    
    public function view(string $shareCode): void {
        $share = $this->shareModel->findByCode($shareCode);
        
        if (!$share) {
            http_response_code(404);
            echo 'Share link not found';
            return;
        }
        
        if (!$this->shareModel->isValid($share)) {
            echo 'Share link expired or limit reached';
            return;
        }
        
        if ($share['password']) {
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $password = $_POST['password'] ?? '';
                
                if ($password === $share['password']) {
                    $this->shareModel->incrementViews($share['id']);
                    
                    $this->view('share/view', [
                        'share' => $share,
                        'user' => $this->currentUser()
                    ]);
                    return;
                } else {
                    $error = 'Invalid password';
                }
            }
            
            $this->view('share/password', [
                'shareCode' => $shareCode,
                'error' => $error ?? null
            ]);
        } else {
            $this->shareModel->incrementViews($share['id']);
            
            $this->view('share/view', [
                'share' => $share,
                'user' => $this->currentUser()
            ]);
        }
    }
}
?>