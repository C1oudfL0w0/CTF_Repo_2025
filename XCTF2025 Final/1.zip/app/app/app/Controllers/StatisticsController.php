<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Services\StatisticsService;

class StatisticsController extends Controller {
    private StatisticsService $statsService;
    
    public function __construct() {
        $this->statsService = new StatisticsService();
    }
    
    public function index(): void {
        $globalStats = $this->statsService->getGlobalStats();
        $trendingTags = $this->statsService->getTrendingTags(15);
        $activeUsers = $this->statsService->getActiveUsers(10);
        
        $this->view('statistics/index', [
            'globalStats' => $globalStats,
            'trendingTags' => $trendingTags,
            'activeUsers' => $activeUsers,
            'user' => $this->currentUser()
        ]);
    }
    
    public function user(string $userId): void {
        $userStats = $this->statsService->getUserStats($userId);
        
        $this->json([
            'data' => $userStats
        ]);
    }
    
    public function note(string $noteId): void {
        $noteStats = $this->statsService->getNoteStats($noteId);
        
        $this->json([
            'data' => $noteStats
        ]);
    }
}
?>