<?php
declare(strict_types=1);

class Database {
    private static ?PDO $instance = null;
    
    public static function getInstance(): PDO {
        if (self::$instance === null) {
            $config = require __DIR__ . '/config.php';
            $dbPath = $config['database']['path'];
            
            self::$instance = new PDO('sqlite:' . $dbPath);
            self::$instance->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            self::$instance->exec('PRAGMA foreign_keys = ON');
        }
        
        return self::$instance;
    }
    
    public static function init(): void {
        $pdo = self::getInstance();
        
        $pdo->exec('CREATE TABLE IF NOT EXISTS users (
            id TEXT PRIMARY KEY,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            email TEXT DEFAULT "",
            bio TEXT DEFAULT "",
            avatar TEXT DEFAULT "",
            role TEXT DEFAULT "user",
            chance INT NOT NULL DEFAULT 2,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            last_login DATETIME
        )');
        
        $pdo->exec('CREATE TABLE IF NOT EXISTS notes (
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            title TEXT NOT NULL,
            content TEXT NOT NULL,
            password_hash TEXT NOT NULL,
            category_id TEXT,
            is_public INTEGER DEFAULT 1,
            views INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY(category_id) REFERENCES categories(id) ON DELETE SET NULL
        )');
        
        $pdo->exec('CREATE TABLE IF NOT EXISTS categories (
            id TEXT PRIMARY KEY,
            name TEXT UNIQUE NOT NULL,
            description TEXT DEFAULT "",
            color TEXT DEFAULT "#3498db",
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )');
        
        $pdo->exec('CREATE TABLE IF NOT EXISTS tags (
            id TEXT PRIMARY KEY,
            name TEXT UNIQUE NOT NULL,
            color TEXT DEFAULT "#95a5a6",
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )');
        
        $pdo->exec('CREATE TABLE IF NOT EXISTS note_tags (
            note_id TEXT NOT NULL,
            tag_id TEXT NOT NULL,
            PRIMARY KEY (note_id, tag_id),
            FOREIGN KEY(note_id) REFERENCES notes(id) ON DELETE CASCADE,
            FOREIGN KEY(tag_id) REFERENCES tags(id) ON DELETE CASCADE
        )');
        
        $pdo->exec('CREATE TABLE IF NOT EXISTS comments (
            id TEXT PRIMARY KEY,
            note_id TEXT NOT NULL,
            user_id TEXT NOT NULL,
            parent_id TEXT,
            content TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(note_id) REFERENCES notes(id) ON DELETE CASCADE,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY(parent_id) REFERENCES comments(id) ON DELETE CASCADE
        )');
        
        $pdo->exec('CREATE TABLE IF NOT EXISTS attachments (
            id TEXT PRIMARY KEY,
            note_id TEXT NOT NULL,
            filename TEXT NOT NULL,
            original_name TEXT NOT NULL,
            file_size INTEGER NOT NULL,
            mime_type TEXT NOT NULL,
            uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(note_id) REFERENCES notes(id) ON DELETE CASCADE
        )');
        
        $pdo->exec('CREATE TABLE IF NOT EXISTS favorites (
            user_id TEXT NOT NULL,
            note_id TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (user_id, note_id),
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY(note_id) REFERENCES notes(id) ON DELETE CASCADE
        )');
        
        $pdo->exec('CREATE TABLE IF NOT EXISTS note_shares (
            id TEXT PRIMARY KEY,
            note_id TEXT NOT NULL,
            share_code TEXT UNIQUE NOT NULL,
            password TEXT,
            expires_at DATETIME,
            max_views INTEGER,
            current_views INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(note_id) REFERENCES notes(id) ON DELETE CASCADE
        )');
        
        $pdo->exec('CREATE TABLE IF NOT EXISTS activity_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT,
            action TEXT NOT NULL,
            entity_type TEXT,
            entity_id TEXT,
            ip_address TEXT,
            user_agent TEXT,
            metadata TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL
        )');
        
        $pdo->exec('CREATE INDEX IF NOT EXISTS idx_notes_user_id ON notes(user_id)');
        $pdo->exec('CREATE INDEX IF NOT EXISTS idx_notes_category_id ON notes(category_id)');
        $pdo->exec('CREATE INDEX IF NOT EXISTS idx_notes_created_at ON notes(created_at)');
        $pdo->exec('CREATE INDEX IF NOT EXISTS idx_notes_views ON notes(views)');
        $pdo->exec('CREATE INDEX IF NOT EXISTS idx_comments_note_id ON comments(note_id)');
        $pdo->exec('CREATE INDEX IF NOT EXISTS idx_comments_user_id ON comments(user_id)');
        $pdo->exec('CREATE INDEX IF NOT EXISTS idx_activity_logs_user_id ON activity_logs(user_id)');
        
        $pdo->exec("INSERT OR IGNORE INTO categories (id, name, description, color) VALUES 
            ('cat-1', 'Technology', 'Technology-related notes', '#3498db'),
            ('cat-2', 'Personal', 'Personal journals', '#e74c3c'),
            ('cat-3', 'Work', 'Work-related notes', '#2ecc71'),
            ('cat-4', 'Study', 'Study notes', '#9b59b6'),
            ('cat-5', 'Projects', 'Project documentation', '#f39c12'),
            ('cat-6', 'Ideas', 'Ideas and brainstorming', '#1abc9c'),
            ('cat-7', 'Archive', 'Archived notes', '#95a5a6')
        ");
    }
}

function db(): PDO {
    return Database::getInstance();
}

function init_db(): void {
    Database::init();
}
?>