<?php
declare(strict_types=1);

namespace App\Models;

class ActivityLog extends Model {
    
    public function log(?string $userId, string $action, ?string $entityType = null, ?string $entityId = null, ?array $metadata = null): void {
        $st = $this->db->prepare('INSERT INTO activity_logs (user_id, action, entity_type, entity_id, ip_address, user_agent, metadata) VALUES (?, ?, ?, ?, ?, ?, ?)');
        $st->execute([
            $userId,
            $action,
            $entityType,
            $entityId,
            $_SERVER['REMOTE_ADDR'] ?? null,
            $_SERVER['HTTP_USER_AGENT'] ?? null,
            $metadata ? json_encode($metadata) : null
        ]);
    }
    
    public function getByUser(string $userId, int $limit = 50): array {
        $st = $this->db->prepare('
            SELECT * FROM activity_logs 
            WHERE user_id = ? 
            ORDER BY created_at DESC 
            LIMIT ?
        ');
        $st->execute([$userId, $limit]);
        return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
    }
    
    public function getRecent(int $limit = 100): array {
        $st = $this->db->prepare('
            SELECT l.*, u.username 
            FROM activity_logs l
            LEFT JOIN users u ON u.id = l.user_id
            ORDER BY l.created_at DESC 
            LIMIT ?
        ');
        $st->bindValue(1, $limit, \PDO::PARAM_INT);
        $st->execute();
        return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
    }
}
?>