<?php
declare(strict_types=1);

namespace App\Models;

class Attachment extends Model {
    
    public function create(string $noteId, array $data): string {
        $id = $this->uuid();
        $st = $this->db->prepare('INSERT INTO attachments (id, note_id, filename, original_name, file_size, mime_type) VALUES (?, ?, ?, ?, ?, ?)');
        $st->execute([
            $id,
            $noteId,
            $data['filename'],
            $data['original_name'],
            $data['file_size'],
            $data['mime_type']
        ]);
        return $id;
    }
    
    public function getByNote(string $noteId): array {
        $st = $this->db->prepare('SELECT * FROM attachments WHERE note_id = ? ORDER BY uploaded_at DESC');
        $st->execute([$noteId]);
        return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
    }
    
    public function findById(string $id): ?array {
        $st = $this->db->prepare('SELECT * FROM attachments WHERE id = ?');
        $st->execute([$id]);
        $row = $st->fetch(\PDO::FETCH_ASSOC);
        return $row ?: null;
    }
    
    public function delete(string $id): void {
        $st = $this->db->prepare('DELETE FROM attachments WHERE id = ?');
        $st->execute([$id]);
    }
}
?>