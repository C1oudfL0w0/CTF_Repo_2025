<?php
declare(strict_types=1);

namespace App\Models;

class Category extends Model {
    
    public function all(): array {
        $st = $this->db->query('SELECT * FROM categories ORDER BY name ASC');
        return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
    }
    
    public function findById(string $id): ?array {
        $st = $this->db->prepare('SELECT * FROM categories WHERE id = ?');
        $st->execute([$id]);
        $row = $st->fetch(\PDO::FETCH_ASSOC);
        return $row ?: null;
    }
    
    public function create(string $name, string $description = '', string $color = '#3498db'): string {
        $id = $this->uuid();
        $st = $this->db->prepare('INSERT INTO categories (id, name, description, color) VALUES (?, ?, ?, ?)');
        $st->execute([$id, $name, $description, $color]);
        return $id;
    }
}
?>