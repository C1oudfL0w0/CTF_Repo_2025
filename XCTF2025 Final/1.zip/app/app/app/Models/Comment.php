<?php
declare(strict_types=1);

namespace App\Models;

class Comment extends Model {
    
    public function create(string $noteId, string $userId, string $content, ?string $parentId = null): string {
        $id = $this->uuid();
        $st = $this->db->prepare('INSERT INTO comments (id, note_id, user_id, parent_id, content) VALUES (?, ?, ?, ?, ?)');
        $st->execute([$id, $noteId, $userId, $parentId, $content]);
        return $id;
    }
    
    public function findById(string $id): ?array {
        $st = $this->db->prepare('SELECT * FROM comments WHERE id = ?');
        $st->execute([$id]);
        $row = $st->fetch(\PDO::FETCH_ASSOC);
        return $row ?: null;
    }
    
    public function getByNote(string $noteId): array {
        $st = $this->db->prepare('
            SELECT c.*, u.username AS author
            FROM comments c
            JOIN users u ON u.id = c.user_id
            WHERE c.note_id = ?
            ORDER BY c.created_at ASC
        ');
        $st->execute([$noteId]);
        return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
    }
    
    public function delete(string $id): void {
        $st = $this->db->prepare('DELETE FROM comments WHERE id = ?');
        $st->execute([$id]);
    }
}
?>