<?php
declare(strict_types=1);

namespace App\Models;

class Favorite extends Model {
    
    public function toggle(string $userId, string $noteId): bool {
        if ($this->exists($userId, $noteId)) {
            $this->remove($userId, $noteId);
            return false;
        } else {
            $this->add($userId, $noteId);
            return true;
        }
    }
    
    public function add(string $userId, string $noteId): void {
        $st = $this->db->prepare('INSERT OR IGNORE INTO favorites (user_id, note_id) VALUES (?, ?)');
        $st->execute([$userId, $noteId]);
    }
    
    public function remove(string $userId, string $noteId): void {
        $st = $this->db->prepare('DELETE FROM favorites WHERE user_id = ? AND note_id = ?');
        $st->execute([$userId, $noteId]);
    }
    
    public function exists(string $userId, string $noteId): bool {
        $st = $this->db->prepare('SELECT COUNT(*) as count FROM favorites WHERE user_id = ? AND note_id = ?');
        $st->execute([$userId, $noteId]);
        $row = $st->fetch(\PDO::FETCH_ASSOC);
        return ((int)($row['count'] ?? 0)) > 0;
    }
    
    public function getByUser(string $userId): array {
        $st = $this->db->prepare('
            SELECT n.*, u.username AS author, f.created_at AS favorited_at
            FROM favorites f
            JOIN notes n ON n.id = f.note_id
            JOIN users u ON u.id = n.user_id
            WHERE f.user_id = ?
            ORDER BY f.created_at DESC
        ');
        $st->execute([$userId]);
        return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
    }
}
?>