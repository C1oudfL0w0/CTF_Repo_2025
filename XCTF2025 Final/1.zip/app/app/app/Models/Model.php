<?php
declare(strict_types=1);

namespace App\Models;

abstract class Model {
    protected \PDO $db;
    
    public function __construct() {
        $this->db = \db();
    }
    
    protected function uuid(): string {
        $data = random_bytes(16);
        $data[6] = chr((ord($data[6]) & 0x0f) | 0x40);
        $data[8] = chr((ord($data[8]) & 0x3f) | 0x80);
        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
    }
    
    protected function now(): string {
        return date('Y-m-d H:i:s');
    }
}
?>