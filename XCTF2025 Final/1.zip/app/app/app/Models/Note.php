<?php
declare(strict_types=1);

namespace App\Models;

class Note extends Model {
    
    public function create(array $data): string {
        $id = $this->uuid();
        $secret = getenv('SECRET_SALT') ?: 'DEVELOPMENT_DEFAULT_SECRET';
        $derivedPassword = $id . ':' . $data['user_id'] . ':' . $secret;
        $passwordHash = password_hash($derivedPassword, PASSWORD_BCRYPT);
        
        $st = $this->db->prepare('INSERT INTO notes (id, user_id, title, content, password_hash, category_id, is_public) VALUES (?, ?, ?, ?, ?, ?, ?)');
        $st->execute([
            $id,
            $data['user_id'],
            $data['title'],
            $data['content'],
            $passwordHash,
            $data['category_id'] ?? null,
            $data['is_public'] ?? 1
        ]);
        return $id;
    }
    
    public function findById(string $id): ?array {
        $st = $this->db->prepare('
            SELECT n.*, u.username AS author, c.name AS category_name, c.color AS category_color
            FROM notes n 
            JOIN users u ON u.id = n.user_id 
            LEFT JOIN categories c ON c.id = n.category_id
            WHERE n.id = ?
        ');
        $st->execute([$id]);
        $row = $st->fetch(\PDO::FETCH_ASSOC);
        return $row ?: null;
    }
    
    public function update(string $id, array $data): void {
        $fields = [];
        $values = [];
        
        foreach ($data as $key => $value) {
            $fields[] = "$key = ?";
            $values[] = $value;
        }
        
        $fields[] = 'updated_at = ?';
        $values[] = $this->now();
        $values[] = $id;
        
        $sql = 'UPDATE notes SET ' . implode(', ', $fields) . ' WHERE id = ?';
        $st = $this->db->prepare($sql);
        $st->execute($values);
    }
    
    public function delete(string $id): void {
        $st = $this->db->prepare('DELETE FROM notes WHERE id = ?');
        $st->execute([$id]);
    }
    
    public function incrementViews(string $id): void {
        $st = $this->db->prepare('UPDATE notes SET views = views + 1 WHERE id = ?');
        $st->execute([$id]);
    }
    
    public function findByUser(string $userId, int $limit = 100, int $offset = 0): array {
        $st = $this->db->prepare('
            SELECT n.*, c.name AS category_name
            FROM notes n 
            LEFT JOIN categories c ON c.id = n.category_id
            WHERE n.user_id = ?
            ORDER BY n.created_at DESC
            LIMIT ? OFFSET ?
        ');
        $st->execute([$userId, $limit, $offset]);
        return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
    }
    
    public function findPublic(int $limit = 20, int $offset = 0): array {
        $st = $this->db->prepare('
            SELECT n.id, n.title, n.views, n.created_at, u.username AS author, c.name AS category_name, c.color AS category_color
            FROM notes n 
            JOIN users u ON u.id = n.user_id 
            LEFT JOIN categories c ON c.id = n.category_id
            WHERE n.is_public = 1
            ORDER BY n.created_at DESC 
            LIMIT ? OFFSET ?
        ');
        $st->bindValue(1, $limit, \PDO::PARAM_INT);
        $st->bindValue(2, $offset, \PDO::PARAM_INT);
        $st->execute();
        return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
    }
    
    public function search(string $query, int $limit = 20, int $offset = 0): array {
        $searchTerm = '%' . $query . '%';
        $st = $this->db->prepare('
            SELECT n.id, n.title, n.views, n.created_at, u.username AS author, c.name AS category_name
            FROM notes n 
            JOIN users u ON u.id = n.user_id 
            LEFT JOIN categories c ON c.id = n.category_id
            WHERE (n.title LIKE ? OR n.content LIKE ?)
            ORDER BY n.created_at DESC 
            LIMIT ? OFFSET ?
        ');
        $st->execute([$searchTerm, $searchTerm, $limit, $offset]);
        return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
    }
    
    public function findByCategory(string $categoryId, int $limit = 20, int $offset = 0): array {
        $st = $this->db->prepare('
            SELECT n.id, n.title, n.views, n.created_at, u.username AS author, c.name AS category_name
            FROM notes n 
            JOIN users u ON u.id = n.user_id 
            JOIN categories c ON c.id = n.category_id
            WHERE n.category_id = ? AND n.is_public = 1
            ORDER BY n.created_at DESC 
            LIMIT ? OFFSET ?
        ');
        $st->execute([$categoryId, $limit, $offset]);
        return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
    }
    
    public function popular(int $limit = 10): array {
        $st = $this->db->prepare('
            SELECT n.id, n.title, n.views, u.username AS author
            FROM notes n 
            JOIN users u ON u.id = n.user_id 
            WHERE n.is_public = 1
            ORDER BY n.views DESC 
            LIMIT ?
        ');
        $st->bindValue(1, $limit, \PDO::PARAM_INT);
        $st->execute();
        return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
    }
    
    public function count(): int {
        $st = $this->db->query('SELECT COUNT(*) as count FROM notes WHERE is_public = 1');
        $row = $st->fetch(\PDO::FETCH_ASSOC);
        return (int)($row['count'] ?? 0);
    }
    
    public function countByUser(string $userId): int {
        $st = $this->db->prepare('SELECT COUNT(*) as count FROM notes WHERE user_id = ?');
        $st->execute([$userId]);
        $row = $st->fetch(\PDO::FETCH_ASSOC);
        return (int)($row['count'] ?? 0);
    }
}
?>