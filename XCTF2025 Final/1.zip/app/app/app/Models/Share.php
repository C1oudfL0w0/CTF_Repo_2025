<?php
declare(strict_types=1);

namespace App\Models;

class Share extends Model {
    
    public function create(string $noteId, ?string $password = null, ?string $expiresAt = null, ?int $maxViews = null): array {
        $id = $this->uuid();
        $shareCode = bin2hex(random_bytes(8));
        
        $st = $this->db->prepare('INSERT INTO note_shares (id, note_id, share_code, password, expires_at, max_views) VALUES (?, ?, ?, ?, ?, ?)');
        $st->execute([$id, $noteId, $shareCode, $password, $expiresAt, $maxViews]);
        
        return [
            'id' => $id,
            'share_code' => $shareCode
        ];
    }
    
    public function findByCode(string $shareCode): ?array {
        $st = $this->db->prepare('
            SELECT s.*, n.title, n.content, u.username AS author
            FROM note_shares s
            JOIN notes n ON n.id = s.note_id
            JOIN users u ON u.id = n.user_id
            WHERE s.share_code = ?
        ');
        $st->execute([$shareCode]);
        $row = $st->fetch(\PDO::FETCH_ASSOC);
        return $row ?: null;
    }
    
    public function incrementViews(string $id): void {
        $st = $this->db->prepare('UPDATE note_shares SET current_views = current_views + 1 WHERE id = ?');
        $st->execute([$id]);
    }
    
    public function isValid(array $share): bool {
        if ($share['expires_at'] && strtotime($share['expires_at']) < time()) {
            return false;
        }
        
        if ($share['max_views'] && $share['current_views'] >= $share['max_views']) {
            return false;
        }
        
        return true;
    }
    
    public function getByNote(string $noteId): array {
        $st = $this->db->prepare('SELECT * FROM note_shares WHERE note_id = ? ORDER BY created_at DESC');
        $st->execute([$noteId]);
        return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
    }
    
    public function delete(string $id): void {
        $st = $this->db->prepare('DELETE FROM note_shares WHERE id = ?');
        $st->execute([$id]);
    }
}
?>