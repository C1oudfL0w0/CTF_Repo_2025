<?php
declare(strict_types=1);

namespace App\Models;

class Tag extends Model {
    
    public function all(): array {
        $st = $this->db->query('SELECT * FROM tags ORDER BY name ASC');
        return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
    }
    
    public function findById(string $id): ?array {
        $st = $this->db->prepare('SELECT * FROM tags WHERE id = ?');
        $st->execute([$id]);
        $row = $st->fetch(\PDO::FETCH_ASSOC);
        return $row ?: null;
    }
    
    public function findByName(string $name): ?array {
        $st = $this->db->prepare('SELECT * FROM tags WHERE name = ?');
        $st->execute([$name]);
        $row = $st->fetch(\PDO::FETCH_ASSOC);
        return $row ?: null;
    }
    
    public function create(string $name, string $color = '#95a5a6'): string {
        $id = $this->uuid();
        $st = $this->db->prepare('INSERT INTO tags (id, name, color) VALUES (?, ?, ?)');
        $st->execute([$id, $name, $color]);
        return $id;
    }
    
    public function findOrCreate(string $name): array {
        $tag = $this->findByName($name);
        if ($tag) {
            return $tag;
        }
        $id = $this->create($name);
        return ['id' => $id, 'name' => $name, 'color' => '#95a5a6'];
    }
    
    public function attachToNote(string $noteId, string $tagId): void {
        $st = $this->db->prepare('INSERT OR IGNORE INTO note_tags (note_id, tag_id) VALUES (?, ?)');
        $st->execute([$noteId, $tagId]);
    }
    
    public function detachFromNote(string $noteId, string $tagId): void {
        $st = $this->db->prepare('DELETE FROM note_tags WHERE note_id = ? AND tag_id = ?');
        $st->execute([$noteId, $tagId]);
    }
    
    public function getByNote(string $noteId): array {
        $st = $this->db->prepare('
            SELECT t.* FROM tags t
            JOIN note_tags nt ON nt.tag_id = t.id
            WHERE nt.note_id = ?
        ');
        $st->execute([$noteId]);
        return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
    }
    
    public function clearNote(string $noteId): void {
        $st = $this->db->prepare('DELETE FROM note_tags WHERE note_id = ?');
        $st->execute([$noteId]);
    }
}
?>