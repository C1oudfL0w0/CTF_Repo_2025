<?php
declare(strict_types=1);

namespace App\Models;

class User extends Model {
    
    public function create(string $username, string $passwordHash, string $email = '', string $role = 'user'): array {
        $id = $this->uuid();
        $st = $this->db->prepare('INSERT INTO users (id, username, password_hash, email, role, chance) VALUES (?, ?, ?, ?, ?, ?)');
        $st->execute([$id, $username, $passwordHash, $email, $role, 2]);
        
        return [
            'id' => $id,
            'username' => $username,
            'email' => $email,
            'role' => $role,
            'chance' => 2
        ];
    }
    
    public function findById(string $id): ?array {
        $st = $this->db->prepare('SELECT * FROM users WHERE id = ?');
        $st->execute([$id]);
        $row = $st->fetch(\PDO::FETCH_ASSOC);
        return $row ?: null;
    }
    
    public function findByUsername(string $username): ?array {
        $st = $this->db->prepare('SELECT * FROM users WHERE username = ?');
        $st->execute([$username]);
        $row = $st->fetch(\PDO::FETCH_ASSOC);
        return $row ?: null;
    }
    
    public function update(string $id, array $data): void {
        $fields = [];
        $values = [];
        
        foreach ($data as $key => $value) {
            $fields[] = "$key = ?";
            $values[] = $value;
        }
        
        $values[] = $id;
        $sql = 'UPDATE users SET ' . implode(', ', $fields) . ' WHERE id = ?';
        $st = $this->db->prepare($sql);
        $st->execute($values);
    }
    
    public function updateLastLogin(string $id): void {
        $st = $this->db->prepare('UPDATE users SET last_login = ? WHERE id = ?');
        $st->execute([$this->now(), $id]);
    }
    
    public function decrementChance(string $id): void {
        $st = $this->db->prepare('UPDATE users SET chance = chance - 1 WHERE id = ?');
        $st->execute([$id]);
    }
    
    public function all(int $limit = 100, int $offset = 0): array {
        $st = $this->db->prepare('SELECT id, username, email, role, created_at, last_login, chance FROM users ORDER BY created_at DESC LIMIT ? OFFSET ?');
        $st->bindValue(1, $limit, \PDO::PARAM_INT);
        $st->bindValue(2, $offset, \PDO::PARAM_INT);
        $st->execute();
        return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
    }
    
    public function count(): int {
        $st = $this->db->query('SELECT COUNT(*) as count FROM users');
        $row = $st->fetch(\PDO::FETCH_ASSOC);
        return (int)($row['count'] ?? 0);
    }
}
?>