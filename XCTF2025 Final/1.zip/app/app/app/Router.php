<?php
declare(strict_types=1);

class Router {
    private array $routes = [];
    private string $method;
    private string $path;
    
    public function __construct() {
        $this->method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
        $this->path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
    }
    
    public function get(string $pattern, $handler): void {
        $this->addRoute('GET', $pattern, $handler);
    }
    
    public function post(string $pattern, $handler): void {
        $this->addRoute('POST', $pattern, $handler);
    }
    
    public function put(string $pattern, $handler): void {
        $this->addRoute('PUT', $pattern, $handler);
    }
    
    public function delete(string $pattern, $handler): void {
        $this->addRoute('DELETE', $pattern, $handler);
    }
    
    private function addRoute(string $method, string $pattern, $handler): void {
        $this->routes[] = [
            'method' => $method,
            'pattern' => $pattern,
            'handler' => $handler
        ];
    }
    
    public function dispatch(): void {
        foreach ($this->routes as $route) {
            if ($route['method'] !== $this->method) {
                continue;
            }
            
            $params = [];
            if ($this->match($route['pattern'], $this->path, $params)) {
                $handler = $route['handler'];
                
                if (is_array($handler)) {
                    [$controller, $action] = $handler;
                    $controllerInstance = new $controller();
                    call_user_func_array([$controllerInstance, $action], array_values($params));
                } else {
                    call_user_func_array($handler, array_values($params));
                }
                return;
            }
        }
        
        http_response_code(404);
        echo '404 - Page Not Found';
    }
    
    private function match(string $pattern, string $path, array &$params): bool {
        $regex = '#^' . preg_replace('#\{([a-zA-Z0-9_]+)\}#', '(?P<$1>[^/]+)', $pattern) . '$#';
        if (preg_match($regex, $path, $matches)) {
            foreach ($matches as $key => $value) {
                if (!is_int($key)) {
                    $params[$key] = $value;
                }
            }
            return true;
        }
        return false;
    }
}
?>