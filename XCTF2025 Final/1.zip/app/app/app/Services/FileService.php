<?php
declare(strict_types=1);

namespace App\Services;

use App\Models\Attachment;

class FileService {
    private Attachment $attachmentModel;
    private string $uploadDir;
    private array $allowedExtensions;
    private int $maxFileSize;
    
    public function __construct() {
        $this->attachmentModel = new Attachment();
        $config = require __DIR__ . '/../config.php';
        $this->uploadDir = $config['upload']['upload_dir'];
        $this->allowedExtensions = $config['upload']['allowed_extensions'];
        $this->maxFileSize = $config['upload']['max_size'];
        
        if (!is_dir($this->uploadDir)) {
            mkdir($this->uploadDir, 0755, true);
        }
    }
    
    public function upload(string $noteId, array $file): ?string {
        if ($file['error'] !== UPLOAD_ERR_OK) {
            throw new \Exception('Upload failed');
        }
        
        if ($file['size'] > $this->maxFileSize) {
            throw new \Exception('File too large');
        }
        
        $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($extension, $this->allowedExtensions)) {
            throw new \Exception('Invalid file type');
        }
        
        $filename = bin2hex(random_bytes(16)) . '.' . $extension;
        $filepath = $this->uploadDir . $filename;
        
        if (!move_uploaded_file($file['tmp_name'], $filepath)) {
            throw new \Exception('Failed to save file');
        }
        
        $attachmentId = $this->attachmentModel->create($noteId, [
            'filename' => $filename,
            'original_name' => $file['name'],
            'file_size' => $file['size'],
            'mime_type' => mime_content_type($filepath)
        ]);
        
        return $attachmentId;
    }
    
    public function delete(string $attachmentId): bool {
        $attachment = $this->attachmentModel->findById($attachmentId);
        
        if (!$attachment) {
            return false;
        }
        
        $filepath = $this->uploadDir . $attachment['filename'];
        if (file_exists($filepath)) {
            unlink($filepath);
        }
        
        $this->attachmentModel->delete($attachmentId);
        return true;
    }
    
    public function getFilePath(string $filename): string {
        return $this->uploadDir . $filename;
    }
}
?>