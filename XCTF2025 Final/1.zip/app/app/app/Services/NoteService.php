<?php
declare(strict_types=1);

namespace App\Services;

use App\Models\Note;
use App\Models\Tag;
use App\Models\User;

class NoteService {
    private Note $noteModel;
    private Tag $tagModel;
    private User $userModel;
    
    public function __construct() {
        $this->noteModel = new Note();
        $this->tagModel = new Tag();
        $this->userModel = new User();
    }
    
    public function create(string $userId, array $data): string {
        $noteId = bin2hex(random_bytes(16));
        $secret = getenv('SECRET_SALT') ?: 'DEVELOPMENT_DEFAULT_SECRET';
        $derivedPassword = $noteId . ':' . $userId . ':' . $secret;
        $passwordHash = password_hash($derivedPassword, PASSWORD_BCRYPT);
        
        $id = $this->noteModel->create([
            'user_id' => $userId,
            'title' => $data['title'],
            'content' => $data['content'],
            'password_hash' => $passwordHash,
            'category_id' => $data['category_id'] ?? null,
            'is_public' => $data['is_public'] ?? 1
        ]);
        
        if (!empty($data['tags'])) {
            $this->attachTags($id, $data['tags']);
        }
        
        $this->userModel->decrementChance($userId);
        
        return $id;
    }
    
    public function update(string $noteId, array $data): void {
        $this->noteModel->update($noteId, [
            'title' => $data['title'],
            'content' => $data['content'],
            'category_id' => $data['category_id'] ?? null,
            'is_public' => $data['is_public'] ?? 1
        ]);
        
        $this->tagModel->clearNote($noteId);
        
        if (!empty($data['tags'])) {
            $this->attachTags($noteId, $data['tags']);
        }
    }
    
    private function attachTags(string $noteId, array $tagNames): void {
        foreach ($tagNames as $tagName) {
            $tagName = trim($tagName);
            if (!empty($tagName)) {
                $tag = $this->tagModel->findOrCreate($tagName);
                $this->tagModel->attachToNote($noteId, $tag['id']);
            }
        }
    }
    
    public function search(string $query, array $filters = []): array {
        return $this->noteModel->search($query, $filters['limit'] ?? 20, $filters['offset'] ?? 0);
    }
}
?>