<?php
declare(strict_types=1);

namespace App\Services;

class NotificationService {
    private \PDO $db;
    
    public function __construct() {
        $this->db = \db();
        $this->initTable();
    }
    
    private function initTable(): void {
        $this->db->exec('CREATE TABLE IF NOT EXISTS notifications (
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            type TEXT NOT NULL,
            title TEXT NOT NULL,
            message TEXT NOT NULL,
            link TEXT,
            is_read INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        )');
        
        $this->db->exec('CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id)');
    }
    
    public function create(string $userId, string $type, string $title, string $message, ?string $link = null): string {
        $id = $this->uuid();
        $st = $this->db->prepare('INSERT INTO notifications (id, user_id, type, title, message, link) VALUES (?, ?, ?, ?, ?, ?)');
        $st->execute([$id, $userId, $type, $title, $message, $link]);
        return $id;
    }
    
    public function getByUser(string $userId, bool $unreadOnly = false, int $limit = 50): array {
        $sql = 'SELECT * FROM notifications WHERE user_id = ?';
        if ($unreadOnly) {
            $sql .= ' AND is_read = 0';
        }
        $sql .= ' ORDER BY created_at DESC LIMIT ?';
        
        $st = $this->db->prepare($sql);
        $st->execute([$userId, $limit]);
        return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
    }
    
    public function markAsRead(string $id): void {
        $st = $this->db->prepare('UPDATE notifications SET is_read = 1 WHERE id = ?');
        $st->execute([$id]);
    }
    
    public function markAllAsRead(string $userId): void {
        $st = $this->db->prepare('UPDATE notifications SET is_read = 1 WHERE user_id = ?');
        $st->execute([$userId]);
    }
    
    public function countUnread(string $userId): int {
        $st = $this->db->prepare('SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0');
        $st->execute([$userId]);
        $row = $st->fetch(\PDO::FETCH_ASSOC);
        return (int)($row['count'] ?? 0);
    }
    
    private function uuid(): string {
        $data = random_bytes(16);
        $data[6] = chr((ord($data[6]) & 0x0f) | 0x40);
        $data[8] = chr((ord($data[8]) & 0x3f) | 0x80);
        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
    }
}
?>