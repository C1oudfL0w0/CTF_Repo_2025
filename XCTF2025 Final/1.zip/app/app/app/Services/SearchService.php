<?php
declare(strict_types=1);

namespace App\Services;

use App\Models\Note;
use App\Models\Tag;
use App\Models\User;

class SearchService {
    private Note $noteModel;
    private Tag $tagModel;
    private User $userModel;
    
    public function __construct() {
        $this->noteModel = new Note();
        $this->tagModel = new Tag();
        $this->userModel = new User();
    }
    
    public function searchNotes(string $query, array $options = []): array {
        $limit = $options['limit'] ?? 20;
        $offset = $options['offset'] ?? 0;
        
        return $this->noteModel->search($query, $limit, $offset);
    }
    
    public function searchByTag(string $tagName, array $options = []): array {
        $tag = $this->tagModel->findByName($tagName);
        
        if (!$tag) {
            return [];
        }
        
        $db = \db();
        $limit = $options['limit'] ?? 20;
        $offset = $options['offset'] ?? 0;
        
        $st = $db->prepare('
            SELECT n.*, u.username AS author 
            FROM notes n
            JOIN note_tags nt ON nt.note_id = n.id
            JOIN users u ON u.id = n.user_id
            WHERE nt.tag_id = ? AND n.is_public = 1
            ORDER BY n.created_at DESC
            LIMIT ? OFFSET ?
        ');
        $st->execute([$tag['id'], $limit, $offset]);
        
        return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
    }
    
    public function searchUsers(string $query): array {
        $db = \db();
        $searchTerm = '%' . $query . '%';
        
        $st = $db->prepare('
            SELECT id, username, bio, created_at 
            FROM users 
            WHERE username LIKE ? OR bio LIKE ?
            LIMIT 50
        ');
        $st->execute([$searchTerm, $searchTerm]);
        
        return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
    }
    
    public function getRelatedNotes(string $noteId, int $limit = 5): array {
        $note = $this->noteModel->findById($noteId);
        
        if (!$note) {
            return [];
        }
        
        $db = \db();
        $st = $db->prepare('
            SELECT DISTINCT n.*, u.username AS author
            FROM notes n
            JOIN users u ON u.id = n.user_id
            WHERE n.category_id = ? AND n.id != ? AND n.is_public = 1
            ORDER BY n.created_at DESC
            LIMIT ?
        ');
        $st->execute([$note['category_id'], $noteId, $limit]);
        
        return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
    }
}
?>