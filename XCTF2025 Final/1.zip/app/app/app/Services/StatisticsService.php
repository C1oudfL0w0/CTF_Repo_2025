<?php
declare(strict_types=1);

namespace App\Services;

class StatisticsService {
    private \PDO $db;
    
    public function __construct() {
        $this->db = \db();
    }
    
    public function getUserStats(string $userId): array {
        $stats = [];
        
        $st = $this->db->prepare('SELECT COUNT(*) as count FROM notes WHERE user_id = ?');
        $st->execute([$userId]);
        $stats['total_notes'] = (int)$st->fetchColumn();
        
        $st = $this->db->prepare('SELECT COUNT(*) as count FROM notes WHERE user_id = ? AND is_public = 1');
        $st->execute([$userId]);
        $stats['public_notes'] = (int)$st->fetchColumn();
        
        $st = $this->db->prepare('SELECT SUM(views) as total FROM notes WHERE user_id = ?');
        $st->execute([$userId]);
        $stats['total_views'] = (int)$st->fetchColumn();
        
        $st = $this->db->prepare('SELECT COUNT(*) as count FROM comments WHERE user_id = ?');
        $st->execute([$userId]);
        $stats['total_comments'] = (int)$st->fetchColumn();
        
        $st = $this->db->prepare('SELECT COUNT(*) as count FROM favorites WHERE user_id = ?');
        $st->execute([$userId]);
        $stats['total_favorites'] = (int)$st->fetchColumn();
        
        return $stats;
    }
    
    public function getNoteStats(string $noteId): array {
        $stats = [];
        
        $st = $this->db->prepare('SELECT views FROM notes WHERE id = ?');
        $st->execute([$noteId]);
        $stats['views'] = (int)$st->fetchColumn();
        
        $st = $this->db->prepare('SELECT COUNT(*) as count FROM comments WHERE note_id = ?');
        $st->execute([$noteId]);
        $stats['comments'] = (int)$st->fetchColumn();
        
        $st = $this->db->prepare('SELECT COUNT(*) as count FROM favorites WHERE note_id = ?');
        $st->execute([$noteId]);
        $stats['favorites'] = (int)$st->fetchColumn();
        
        return $stats;
    }
    
    public function getGlobalStats(): array {
        $stats = [];
        
        $st = $this->db->query('SELECT COUNT(*) FROM users');
        $stats['total_users'] = (int)$st->fetchColumn();
        
        $st = $this->db->query('SELECT COUNT(*) FROM notes');
        $stats['total_notes'] = (int)$st->fetchColumn();
        
        $st = $this->db->query('SELECT COUNT(*) FROM comments');
        $stats['total_comments'] = (int)$st->fetchColumn();
        
        $st = $this->db->query('SELECT COUNT(*) FROM tags');
        $stats['total_tags'] = (int)$st->fetchColumn();
        
        $st = $this->db->query('SELECT SUM(views) FROM notes');
        $stats['total_views'] = (int)$st->fetchColumn();
        
        return $stats;
    }
    
    public function getTrendingTags(int $limit = 10): array {
        $st = $this->db->prepare('
            SELECT t.name, t.color, COUNT(nt.note_id) as usage_count
            FROM tags t
            JOIN note_tags nt ON nt.tag_id = t.id
            GROUP BY t.id
            ORDER BY usage_count DESC
            LIMIT ?
        ');
        $st->bindValue(1, $limit, \PDO::PARAM_INT);
        $st->execute();
        
        return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
    }
    
    public function getActiveUsers(int $limit = 10): array {
        $st = $this->db->prepare('
            SELECT u.username, u.bio, COUNT(n.id) as note_count
            FROM users u
            LEFT JOIN notes n ON n.user_id = u.id
            GROUP BY u.id
            ORDER BY note_count DESC
            LIMIT ?
        ');
        $st->bindValue(1, $limit, \PDO::PARAM_INT);
        $st->execute();
        
        return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
    }
}
?>