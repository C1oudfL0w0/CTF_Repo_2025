<?php
declare(strict_types=1);

class Session {
    
    public static function start(): void {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
    }
    
    public static function set(string $key, $value): void {
        $_SESSION[$key] = $value;
    }
    
    public static function get(string $key, $default = null) {
        return $_SESSION[$key] ?? $default;
    }
    
    public static function has(string $key): bool {
        return isset($_SESSION[$key]);
    }
    
    public static function remove(string $key): void {
        unset($_SESSION[$key]);
    }
    
    public static function flash(string $key, $value): void {
        $_SESSION['flash'][$key] = $value;
    }
    
    public static function getFlash(string $key, $default = null) {
        $value = $_SESSION['flash'][$key] ?? $default;
        unset($_SESSION['flash'][$key]);
        return $value;
    }
    
    public static function destroy(): void {
        session_destroy();
    }
    
    public static function regenerate(): void {
        session_regenerate_id(true);
    }
}
?>