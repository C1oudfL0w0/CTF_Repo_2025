<?php
declare(strict_types=1);

error_reporting(E_ALL);
ini_set('display_errors', '1');

define('APP_PATH', __DIR__);
define('BASE_PATH', dirname(__DIR__));

require APP_PATH . '/helpers.php';
require APP_PATH . '/Database.php';
require APP_PATH . '/Router.php';
require APP_PATH . '/Session.php';

Session::start();

spl_autoload_register(function ($class) {
    $prefix = 'App\\';
    $baseDir = APP_PATH . '/';
    
    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }
    
    $relativeClass = substr($class, $len);
    $file = $baseDir . str_replace('\\', '/', $relativeClass) . '.php';
    
    if (file_exists($file)) {
        require $file;
    }
});

init_db();

set_error_handler(function($errno, $errstr, $errfile, $errline) {
    throw new ErrorException($errstr, 0, $errno, $errfile, $errline);
});

set_exception_handler(function($exception) {
    error_log($exception->getMessage());
    
    if (ini_get('display_errors')) {
        echo '<h1>Error</h1>';
        echo '<p>' . h($exception->getMessage()) . '</p>';
        echo '<pre>' . h($exception->getTraceAsString()) . '</pre>';
    } else {
        echo 'An error occurred. Please try again later.';
    }
});
?>