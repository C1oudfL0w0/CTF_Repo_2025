<?php
declare(strict_types=1);

return [
    'app' => [
        'name' => 'B-Notes',
        'version' => '2.0',
        'debug' => getenv('APP_DEBUG') === 'true',
        'timezone' => 'UTC',
    ],
    
    'database' => [
        'driver' => 'sqlite',
        'path' => __DIR__ . '/../data/app.db',
    ],
    
    'session' => [
        'name' => 'BNOTES_SESSION',
        'lifetime' => 7200,
        'path' => '/',
        'secure' => false,
        'httponly' => true,
    ],
    
    'security' => [
        'secret_salt' => getenv('SECRET_SALT') ?: 'DEVELOPMENT_DEFAULT_SECRET',
        'bcrypt_cost' => 10,
        'csrf_enabled' => false,
    ],
    
    'upload' => [
        'max_size' => 5242880,
        'allowed_extensions' => ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'txt', 'md'],
        'upload_dir' => __DIR__ . '/../data/uploads/',
    ],
];
?>