<?php
declare(strict_types=1);

require __DIR__ . '/../app/bootstrap.php';

use App\Controllers\AuthController;
use App\Controllers\NoteController;
use App\Controllers\CommentController;
use App\Controllers\ApiController;
use App\Controllers\ShareController;
use App\Controllers\AdminController;
use App\Controllers\StatisticsController;
use App\Controllers\SearchController;
use App\Controllers\NotificationController;
use App\Controllers\AttachmentController;

$router = new Router();

$router->get('/', [NoteController::class, 'index']);

$router->get('/register', [AuthController::class, 'showRegister']);
$router->post('/register', [AuthController::class, 'register']);
$router->get('/login', [AuthController::class, 'showLogin']);
$router->post('/login', [AuthController::class, 'login']);
$router->get('/logout', [AuthController::class, 'logout']);
$router->get('/profile', [AuthController::class, 'profile']);
$router->post('/profile', [AuthController::class, 'updateProfile']);

$router->get('/notes/create', [NoteController::class, 'create']);
$router->post('/notes', [NoteController::class, 'store']);
$router->get('/notes/{id}', [NoteController::class, 'show']);
$router->get('/notes/{id}/edit', [NoteController::class, 'edit']);
$router->post('/notes/{id}/update', [NoteController::class, 'update']);
$router->post('/notes/{id}/delete', [NoteController::class, 'delete']);
$router->get('/my-notes', [NoteController::class, 'myNotes']);
$router->get('/favorites', [NoteController::class, 'favorites']);
$router->post('/notes/{id}/favorite', [NoteController::class, 'toggleFavorite']);
$router->get('/prize', [NoteController::class, 'prize']);

$router->post('/notes/{noteId}/comments', [CommentController::class, 'store']);
$router->post('/comments/{id}/delete', [CommentController::class, 'delete']);

$router->post('/notes/{noteId}/share', [ShareController::class, 'create']);
$router->get('/share/{shareCode}', [ShareController::class, 'view']);
$router->post('/share/{shareCode}', [ShareController::class, 'view']);

$router->post('/notes/{noteId}/attachments', [AttachmentController::class, 'upload']);
$router->get('/attachments/{id}/download', [AttachmentController::class, 'download']);
$router->post('/attachments/{id}/delete', [AttachmentController::class, 'delete']);

$router->get('/search', [SearchController::class, 'index']);
$router->get('/search/suggest', [SearchController::class, 'suggest']);

$router->get('/statistics', [StatisticsController::class, 'index']);

$router->get('/notifications', [NotificationController::class, 'index']);
$router->post('/notifications/{id}/read', [NotificationController::class, 'markAsRead']);
$router->post('/notifications/read-all', [NotificationController::class, 'markAllAsRead']);
$router->get('/notifications/count', [NotificationController::class, 'count']);

$router->get('/admin', [AdminController::class, 'dashboard']);
$router->get('/admin/users', [AdminController::class, 'users']);
$router->get('/admin/upload', [AdminController::class, 'upload']);
$router->post('/admin/upload', [AdminController::class, 'handleUpload']);
$router->get('/admin/connect', [AdminController::class, 'connect']);
$router->post('/admin/connect', [AdminController::class, 'handleConnect']);

$router->get('/api/notes', [ApiController::class, 'notes']);
$router->get('/api/notes/{id}', [ApiController::class, 'note']);
$router->get('/api/users/{username}', [ApiController::class, 'user']);
$router->get('/api/categories', [ApiController::class, 'categories']);
$router->get('/api/tags', [ApiController::class, 'tags']);
$router->get('/api/search', [ApiController::class, 'search']);
$router->get('/api/popular', [ApiController::class, 'popular']);
$router->get('/api/stats/user/{userId}', [StatisticsController::class, 'user']);
$router->get('/api/stats/note/{noteId}', [StatisticsController::class, 'note']);

$router->dispatch();
?>