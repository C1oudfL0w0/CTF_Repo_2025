<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🔌 FTP Connection - B-Notes</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: #f3f4f6;
            min-height: 100vh;
        }
        
        .navbar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 15px 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        
        .navbar-container {
            max-width: 900px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .navbar-brand {
            font-size: 24px;
            font-weight: bold;
            color: white;
            text-decoration: none;
        }
        
        .navbar-nav {
            display: flex;
            gap: 20px;
            align-items: center;
        }
        
        .nav-link {
            text-decoration: none;
            color: rgba(255,255,255,0.9);
            transition: color 0.3s ease;
            font-size: 14px;
        }
        
        .nav-link:hover {
            color: white;
        }
        
        .container {
            max-width: 900px;
            margin: 0 auto;
            padding: 0 20px 40px;
        }
        
        .page-header {
            margin-bottom: 30px;
        }
        
        .page-title {
            font-size: 32px;
            font-weight: 700;
            color: #1f2937;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .page-description {
            color: #6b7280;
            font-size: 16px;
        }
        
        .card {
            background: white;
            border-radius: 16px;
            padding: 40px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 25px;
        }
        
        .form-group {
            margin-bottom: 25px;
        }
        
        .form-label {
            display: block;
            font-weight: 600;
            color: #374151;
            margin-bottom: 10px;
            font-size: 15px;
        }
        
        .form-control {
            width: 100%;
            padding: 14px 18px;
            border: 2px solid #e5e7eb;
            border-radius: 10px;
            font-size: 15px;
            font-family: inherit;
            transition: all 0.3s ease;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1);
        }
        
        textarea.form-control {
            resize: vertical;
            min-height: 120px;
            font-family: 'Courier New', monospace;
        }
        
        .form-hint {
            font-size: 13px;
            color: #6b7280;
            margin-top: 8px;
            display: block;
        }
        
        .btn {
            padding: 14px 28px;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
        }
        
        .warning-box {
            background: #fee2e2;
            border: 1px solid #fecaca;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 25px;
        }
        
        .warning-box h4 {
            color: #991b1b;
            font-size: 15px;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .warning-box ul {
            list-style: none;
            color: #991b1b;
            font-size: 14px;
        }
        
        .warning-box li {
            padding: 4px 0;
            padding-left: 20px;
            position: relative;
        }
        
        .warning-box li::before {
            content: '🚨';
            position: absolute;
            left: 0;
        }
        
        .info-box {
            background: #eff6ff;
            border: 1px solid #bfdbfe;
            border-radius: 12px;
            padding: 20px;
        }
        
        .info-box h4 {
            color: #1e40af;
            font-size: 15px;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .info-box p {
            color: #1e40af;
            font-size: 14px;
            line-height: 1.6;
            margin-bottom: 10px;
        }
        
        .info-box code {
            background: #dbeafe;
            padding: 2px 8px;
            border-radius: 4px;
            font-family: 'Courier New', monospace;
            font-size: 13px;
        }
        
        .example-box {
            background: #f9fafb;
            border: 1px solid #e5e7eb;
            border-radius: 10px;
            padding: 15px;
            margin-top: 15px;
        }
        
        .example-box pre {
            margin: 0;
            font-family: 'Courier New', monospace;
            font-size: 13px;
            color: #374151;
            overflow-x: auto;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="navbar-container">
            <a href="/admin" class="navbar-brand">👑 Admin Panel</a>
            <div class="navbar-nav">
                <a href="/admin" class="nav-link">📊 Dashboard</a>
                <a href="/admin/users" class="nav-link">👥 Users</a>
                <a href="/admin/upload" class="nav-link">📤 Upload</a>
            </div>
        </div>
    </nav>
    
    <div class="container">
        <div class="page-header">
            <h1 class="page-title">🔌 FTP Connection Test</h1>
            <p class="page-description">Test FTP connections and stream context options</p>
        </div>
        
        <div class="warning-box">
            <h4>🚨 Critical Security Warning</h4>
            <ul>
                <li>This feature may contain SSRF vulnerabilities</li>
                <li>Only use with trusted FTP servers</li>
                <li>Be extremely careful with the options parameter</li>
                <li>Avoid using in production environments</li>
            </ul>
        </div>
        
        <div class="card">
            <form method="POST" action="/admin/connect">
                <div class="form-group">
                    <label class="form-label" for="username">👤 Username / Path</label>
                    <input 
                        type="text" 
                        id="username" 
                        name="username" 
                        class="form-control" 
                        placeholder="username or file path"
                        required
                    >
                    <small class="form-hint">FTP username or file path to access</small>
                </div>
                
                <div class="form-group">
                    <label class="form-label" for="options">⚙️ Stream Context Options (JSON)</label>
                    <textarea 
                        id="options" 
                        name="options" 
                        class="form-control"
                        placeholder='{"ftp": {"timeout": 30}}'
                    ></textarea>
                    <small class="form-hint">JSON formatted stream context options</small>
                </div>
                
                <button type="submit" class="btn btn-primary">
                    🔌 Test Connection
                </button>
            </form>
        </div>
        
        <div class="info-box">
            <h4>💡 Usage Instructions</h4>
            <p>
                This tool tests FTP connections using PHP's <code>fopen()</code> with stream contexts.
                The connection is made to <code>ftp://127.0.0.1:21/</code> with the provided username/path.
            </p>
            <p>
                <strong>Options Parameter:</strong> Must be valid JSON representing PHP stream context options.
                The JSON will be decoded and passed to <code>stream_context_create()</code>.
            </p>
            
            <div class="example-box">
                <strong>Example Options:</strong>
                <pre>{
  "ftp": {
    "timeout": 30,
    "passive": true
  }
}</pre>
            </div>
        </div>
    </div>
</body>
</html>

