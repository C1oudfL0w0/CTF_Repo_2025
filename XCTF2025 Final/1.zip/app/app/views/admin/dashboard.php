<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>👑 Admin Dashboard - B-Notes</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: #f3f4f6;
            min-height: 100vh;
        }
        
        .navbar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 15px 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        
        .navbar-container {
            max-width: 1400px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .navbar-brand {
            font-size: 24px;
            font-weight: bold;
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .navbar-nav {
            display: flex;
            gap: 20px;
            align-items: center;
        }
        
        .nav-link {
            text-decoration: none;
            color: rgba(255,255,255,0.9);
            transition: color 0.3s ease;
            font-size: 14px;
            font-weight: 500;
        }
        
        .nav-link:hover {
            color: white;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 20px 40px;
        }
        
        .page-header {
            margin-bottom: 40px;
        }
        
        .page-title {
            font-size: 36px;
            font-weight: 700;
            color: #1f2937;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .page-description {
            color: #6b7280;
            font-size: 16px;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 25px;
            margin-bottom: 40px;
        }
        
        .stat-card {
            background: white;
            border-radius: 16px;
            padding: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            transition: all 0.3s ease;
            border-left: 4px solid;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
        }
        
        .stat-card.blue {
            border-color: #3b82f6;
        }
        
        .stat-card.green {
            border-color: #10b981;
        }
        
        .stat-card.purple {
            border-color: #8b5cf6;
        }
        
        .stat-card.orange {
            border-color: #f59e0b;
        }
        
        .stat-icon {
            font-size: 40px;
            margin-bottom: 15px;
        }
        
        .stat-value {
            font-size: 32px;
            font-weight: 700;
            color: #1f2937;
            margin-bottom: 5px;
        }
        
        .stat-label {
            color: #6b7280;
            font-size: 13px;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .actions-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 40px;
        }
        
        .action-card {
            background: white;
            border-radius: 16px;
            padding: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            transition: all 0.3s ease;
            text-decoration: none;
            color: inherit;
            display: block;
        }
        
        .action-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(0,0,0,0.1);
        }
        
        .action-icon {
            font-size: 48px;
            margin-bottom: 15px;
        }
        
        .action-title {
            font-size: 20px;
            font-weight: 600;
            color: #1f2937;
            margin-bottom: 8px;
        }
        
        .action-description {
            color: #6b7280;
            font-size: 14px;
            line-height: 1.6;
        }
        
        .section {
            background: white;
            border-radius: 16px;
            padding: 35px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }
        
        .section-title {
            font-size: 24px;
            font-weight: 600;
            color: #1f2937;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .activity-list {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        
        .activity-item {
            display: flex;
            align-items: start;
            gap: 15px;
            padding: 15px;
            background: #f9fafb;
            border-radius: 10px;
            transition: all 0.3s ease;
        }
        
        .activity-item:hover {
            background: #f3f4f6;
        }
        
        .activity-icon {
            font-size: 24px;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: white;
            border-radius: 8px;
            flex-shrink: 0;
        }
        
        .activity-content {
            flex: 1;
        }
        
        .activity-text {
            color: #374151;
            font-size: 14px;
            margin-bottom: 5px;
        }
        
        .activity-text strong {
            color: #1f2937;
            font-weight: 600;
        }
        
        .activity-time {
            color: #9ca3af;
            font-size: 12px;
        }
        
        @media (max-width: 768px) {
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            .actions-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="navbar-container">
            <a href="/admin" class="navbar-brand">👑 Admin Panel</a>
            <div class="navbar-nav">
                <a href="/" class="nav-link">🏠 Home</a>
                <a href="/admin/users" class="nav-link">👥 Users</a>
                <a href="/admin/upload" class="nav-link">📤 Upload</a>
                <a href="/admin/connect" class="nav-link">🔌 FTP</a>
                <a href="/statistics" class="nav-link">📊 Stats</a>
                <a href="/profile" class="nav-link">👤 Profile</a>
            </div>
        </div>
    </nav>
    
    <div class="container">
        <div class="page-header">
            <h1 class="page-title">👑 Admin Dashboard</h1>
            <p class="page-description">System overview and management tools</p>
        </div>
        
        <div class="stats-grid">
            <div class="stat-card blue">
                <div class="stat-icon">👥</div>
                <div class="stat-value"><?= number_format($stats['total_users'] ?? 0) ?></div>
                <div class="stat-label">Total Users</div>
            </div>
            
            <div class="stat-card green">
                <div class="stat-icon">📝</div>
                <div class="stat-value"><?= number_format($stats['total_notes'] ?? 0) ?></div>
                <div class="stat-label">Total Notes</div>
            </div>
            
            <div class="stat-card purple">
                <div class="stat-icon">💬</div>
                <div class="stat-value"><?= number_format(count($stats['recent_activities'] ?? [])) ?></div>
                <div class="stat-label">Recent Activities</div>
            </div>
            
            <div class="stat-card orange">
                <div class="stat-icon">⚡</div>
                <div class="stat-value">100%</div>
                <div class="stat-label">System Health</div>
            </div>
        </div>
        
        <div class="actions-grid">
            <a href="/admin/users" class="action-card">
                <div class="action-icon">👥</div>
                <h3 class="action-title">User Management</h3>
                <p class="action-description">
                    View and manage all registered users, roles, and permissions
                </p>
            </a>
            
            <a href="/admin/upload" class="action-card">
                <div class="action-icon">📤</div>
                <h3 class="action-title">File Upload</h3>
                <p class="action-description">
                    Upload files to the server (Admin only feature)
                </p>
            </a>
            
            <a href="/admin/connect" class="action-card">
                <div class="action-icon">🔌</div>
                <h3 class="action-title">FTP Connection</h3>
                <p class="action-description">
                    Test FTP connections and manage remote files
                </p>
            </a>
            
            <a href="/statistics" class="action-card">
                <div class="action-icon">📊</div>
                <h3 class="action-title">Statistics</h3>
                <p class="action-description">
                    View detailed analytics and platform insights
                </p>
            </a>
        </div>
        
        <div class="section">
            <h2 class="section-title">📋 Recent Activity</h2>
            <?php if (!empty($stats['recent_activities'])): ?>
                <div class="activity-list">
                    <?php foreach (array_slice($stats['recent_activities'], 0, 10) as $activity): ?>
                        <div class="activity-item">
                            <div class="activity-icon">
                                <?php
                                $icons = [
                                    'login' => '🔐',
                                    'register' => '✨',
                                    'create_note' => '📝',
                                    'update_note' => '✏️',
                                    'delete_note' => '🗑️',
                                    'comment' => '💬',
                                    'favorite' => '⭐',
                                    'share' => '🔗'
                                ];
                                echo $icons[$activity['action']] ?? '📌';
                                ?>
                            </div>
                            <div class="activity-content">
                                <div class="activity-text">
                                    <strong><?= htmlspecialchars($activity['username'] ?? 'System') ?></strong>
                                    <?php
                                    $actions = [
                                        'login' => 'logged in',
                                        'register' => 'registered',
                                        'create_note' => 'created a note',
                                        'update_note' => 'updated a note',
                                        'delete_note' => 'deleted a note',
                                        'comment' => 'posted a comment',
                                        'favorite' => 'favorited a note',
                                        'share' => 'shared a note'
                                    ];
                                    echo $actions[$activity['action']] ?? $activity['action'];
                                    ?>
                                </div>
                                <div class="activity-time">
                                    <?= date('M d, Y H:i', strtotime($activity['created_at'])) ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p style="color: #9ca3af; text-align: center; padding: 40px;">No recent activity</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>

