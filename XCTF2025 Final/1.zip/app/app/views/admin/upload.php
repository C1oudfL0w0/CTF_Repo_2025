<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>📤 File Upload - B-Notes</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: #f3f4f6;
            min-height: 100vh;
        }
        
        .navbar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 15px 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        
        .navbar-container {
            max-width: 900px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .navbar-brand {
            font-size: 24px;
            font-weight: bold;
            color: white;
            text-decoration: none;
        }
        
        .navbar-nav {
            display: flex;
            gap: 20px;
            align-items: center;
        }
        
        .nav-link {
            text-decoration: none;
            color: rgba(255,255,255,0.9);
            transition: color 0.3s ease;
            font-size: 14px;
        }
        
        .nav-link:hover {
            color: white;
        }
        
        .container {
            max-width: 900px;
            margin: 0 auto;
            padding: 0 20px 40px;
        }
        
        .page-header {
            margin-bottom: 30px;
        }
        
        .page-title {
            font-size: 32px;
            font-weight: 700;
            color: #1f2937;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .page-description {
            color: #6b7280;
            font-size: 16px;
        }
        
        .card {
            background: white;
            border-radius: 16px;
            padding: 40px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 25px;
        }
        
        .upload-area {
            border: 3px dashed #e5e7eb;
            border-radius: 16px;
            padding: 60px 40px;
            text-align: center;
            transition: all 0.3s ease;
            cursor: pointer;
            background: #f9fafb;
        }
        
        .upload-area:hover {
            border-color: #667eea;
            background: #f3f4f6;
        }
        
        .upload-area.dragover {
            border-color: #667eea;
            background: #eff6ff;
        }
        
        .upload-icon {
            font-size: 64px;
            margin-bottom: 20px;
        }
        
        .upload-title {
            font-size: 20px;
            font-weight: 600;
            color: #1f2937;
            margin-bottom: 10px;
        }
        
        .upload-description {
            color: #6b7280;
            font-size: 14px;
            margin-bottom: 20px;
        }
        
        .file-input {
            display: none;
        }
        
        .btn {
            padding: 12px 28px;
            border: none;
            border-radius: 10px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
        }
        
        .warning-box {
            background: #fef3c7;
            border: 1px solid #fbbf24;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 25px;
        }
        
        .warning-box h4 {
            color: #92400e;
            font-size: 15px;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .warning-box ul {
            list-style: none;
            color: #92400e;
            font-size: 14px;
        }
        
        .warning-box li {
            padding: 4px 0;
            padding-left: 20px;
            position: relative;
        }
        
        .warning-box li::before {
            content: '⚠️';
            position: absolute;
            left: 0;
        }
        
        .info-box {
            background: #eff6ff;
            border: 1px solid #bfdbfe;
            border-radius: 12px;
            padding: 20px;
        }
        
        .info-box h4 {
            color: #1e40af;
            font-size: 15px;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .info-box p {
            color: #1e40af;
            font-size: 14px;
            line-height: 1.6;
        }
        
        .file-selected {
            margin-top: 20px;
            padding: 15px 20px;
            background: #f0fdf4;
            border: 1px solid #bbf7d0;
            border-radius: 10px;
            display: none;
            align-items: center;
            gap: 12px;
        }
        
        .file-selected.show {
            display: flex;
        }
        
        .file-icon {
            font-size: 32px;
        }
        
        .file-info {
            flex: 1;
        }
        
        .file-name {
            font-weight: 600;
            color: #166534;
            margin-bottom: 4px;
        }
        
        .file-size {
            font-size: 13px;
            color: #16a34a;
        }
    </style>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const uploadArea = document.getElementById('uploadArea');
            const fileInput = document.getElementById('fileInput');
            const fileSelected = document.getElementById('fileSelected');
            const fileName = document.getElementById('fileName');
            const fileSize = document.getElementById('fileSize');
            
            uploadArea.addEventListener('click', () => fileInput.click());
            
            uploadArea.addEventListener('dragover', (e) => {
                e.preventDefault();
                uploadArea.classList.add('dragover');
            });
            
            uploadArea.addEventListener('dragleave', () => {
                uploadArea.classList.remove('dragover');
            });
            
            uploadArea.addEventListener('drop', (e) => {
                e.preventDefault();
                uploadArea.classList.remove('dragover');
                const files = e.dataTransfer.files;
                if (files.length > 0) {
                    fileInput.files = files;
                    showFileInfo(files[0]);
                }
            });
            
            fileInput.addEventListener('change', (e) => {
                if (e.target.files.length > 0) {
                    showFileInfo(e.target.files[0]);
                }
            });
            
            function showFileInfo(file) {
                fileName.textContent = file.name;
                fileSize.textContent = formatFileSize(file.size);
                fileSelected.classList.add('show');
            }
            
            function formatFileSize(bytes) {
                if (bytes === 0) return '0 Bytes';
                const k = 1024;
                const sizes = ['Bytes', 'KB', 'MB', 'GB'];
                const i = Math.floor(Math.log(bytes) / Math.log(k));
                return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
            }
        });
    </script>
</head>
<body>
    <nav class="navbar">
        <div class="navbar-container">
            <a href="/admin" class="navbar-brand">👑 Admin Panel</a>
            <div class="navbar-nav">
                <a href="/admin" class="nav-link">📊 Dashboard</a>
                <a href="/admin/users" class="nav-link">👥 Users</a>
                <a href="/admin/connect" class="nav-link">🔌 FTP</a>
            </div>
        </div>
    </nav>
    
    <div class="container">
        <div class="page-header">
            <h1 class="page-title">📤 File Upload</h1>
            <p class="page-description">Upload files to the server (Admin only)</p>
        </div>
        
        <div class="warning-box">
            <h4>⚠️ Security Warning</h4>
            <ul>
                <li>This feature is for administrative purposes only</li>
                <li>Be cautious when uploading files to the server</li>
                <li>Verify file contents before uploading</li>
                <li>This upload may have security vulnerabilities</li>
            </ul>
        </div>
        
        <div class="card">
            <form method="POST" action="/admin/upload" enctype="multipart/form-data">
                <div class="upload-area" id="uploadArea">
                    <div class="upload-icon">📁</div>
                    <h3 class="upload-title">Click to browse or drag and drop</h3>
                    <p class="upload-description">Select a file to upload to the server</p>
                    <input 
                        type="file" 
                        name="file" 
                        id="fileInput" 
                        class="file-input"
                        required
                    >
                </div>
                
                <div class="file-selected" id="fileSelected">
                    <div class="file-icon">📄</div>
                    <div class="file-info">
                        <div class="file-name" id="fileName">File name</div>
                        <div class="file-size" id="fileSize">0 KB</div>
                    </div>
                </div>
                
                <div style="margin-top: 25px; text-align: center;">
                    <button type="submit" class="btn btn-primary">
                        🚀 Upload File
                    </button>
                </div>
            </form>
        </div>
        
        <div class="info-box">
            <h4>💡 Upload Guidelines</h4>
            <p>
                Files will be uploaded to the configured upload directory. 
                Make sure you have proper permissions and the upload directory exists.
                This feature includes basic validation but should be used with caution.
            </p>
        </div>
    </div>
</body>
</html>

