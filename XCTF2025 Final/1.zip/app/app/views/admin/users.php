<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>👥 User Management - B-Notes</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: #f3f4f6;
            min-height: 100vh;
        }
        
        .navbar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 15px 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        
        .navbar-container {
            max-width: 1400px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .navbar-brand {
            font-size: 24px;
            font-weight: bold;
            color: white;
            text-decoration: none;
        }
        
        .navbar-nav {
            display: flex;
            gap: 20px;
            align-items: center;
        }
        
        .nav-link {
            text-decoration: none;
            color: rgba(255,255,255,0.9);
            transition: color 0.3s ease;
            font-size: 14px;
        }
        
        .nav-link:hover {
            color: white;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 20px 40px;
        }
        
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }
        
        .page-title {
            font-size: 32px;
            font-weight: 700;
            color: #1f2937;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .users-table {
            background: white;
            border-radius: 16px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            overflow: hidden;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        thead {
            background: #f9fafb;
            border-bottom: 2px solid #e5e7eb;
        }
        
        th {
            padding: 18px 20px;
            text-align: left;
            font-size: 13px;
            font-weight: 600;
            color: #6b7280;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        tbody tr {
            border-bottom: 1px solid #f3f4f6;
            transition: background 0.3s ease;
        }
        
        tbody tr:hover {
            background: #f9fafb;
        }
        
        td {
            padding: 18px 20px;
            font-size: 14px;
            color: #374151;
        }
        
        .user-cell {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .user-avatar {
            font-size: 32px;
            width: 48px;
            height: 48px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50%;
        }
        
        .user-info {
            flex: 1;
        }
        
        .user-name {
            font-weight: 600;
            color: #1f2937;
            margin-bottom: 4px;
        }
        
        .user-email {
            color: #9ca3af;
            font-size: 13px;
        }
        
        .badge {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .badge-admin {
            background: #fef3c7;
            color: #92400e;
        }
        
        .badge-user {
            background: #dbeafe;
            color: #1e40af;
        }
        
        .status-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            display: inline-block;
            margin-right: 8px;
        }
        
        .status-active {
            background: #10b981;
        }
        
        .status-inactive {
            background: #9ca3af;
        }
        
        .empty-state {
            text-align: center;
            padding: 80px 20px;
            color: #9ca3af;
        }
        
        .empty-state-icon {
            font-size: 64px;
            margin-bottom: 20px;
        }
        
        @media (max-width: 768px) {
            .users-table {
                overflow-x: auto;
            }
            
            table {
                min-width: 800px;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="navbar-container">
            <a href="/admin" class="navbar-brand">👑 Admin Panel</a>
            <div class="navbar-nav">
                <a href="/" class="nav-link">🏠 Home</a>
                <a href="/admin" class="nav-link">📊 Dashboard</a>
                <a href="/admin/upload" class="nav-link">📤 Upload</a>
                <a href="/admin/connect" class="nav-link">🔌 FTP</a>
            </div>
        </div>
    </nav>
    
    <div class="container">
        <div class="page-header">
            <h1 class="page-title">👥 User Management</h1>
        </div>
        
        <?php if (empty($users)): ?>
            <div class="users-table">
                <div class="empty-state">
                    <div class="empty-state-icon">👥</div>
                    <p>No users found</p>
                </div>
            </div>
        <?php else: ?>
            <div class="users-table">
                <table>
                    <thead>
                        <tr>
                            <th>User</th>
                            <th>Role</th>
                            <th>Notes</th>
                            <th>Chance</th>
                            <th>Status</th>
                            <th>Joined</th>
                            <th>Last Login</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $usr): ?>
                            <tr>
                                <td>
                                    <div class="user-cell">
                                        <div class="user-avatar">👨‍💻</div>
                                        <div class="user-info">
                                            <div class="user-name"><?= htmlspecialchars($usr['username']) ?></div>
                                            <div class="user-email"><?= htmlspecialchars($usr['email']) ?></div>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge <?= $usr['role'] === 'admin' ? 'badge-admin' : 'badge-user' ?>">
                                        <?= $usr['role'] === 'admin' ? '👑 Admin' : '👤 User' ?>
                                    </span>
                                </td>
                                <td>
                                    <strong><?= $usr['notes_count'] ?? 0 ?></strong> notes
                                </td>
                                <td>
                                    <strong><?= $usr['chance'] ?></strong> / 2
                                </td>
                                <td>
                                    <span class="status-dot <?= $usr['last_login'] ? 'status-active' : 'status-inactive' ?>"></span>
                                    <?= $usr['last_login'] ? 'Active' : 'Inactive' ?>
                                </td>
                                <td><?= date('M d, Y', strtotime($usr['created_at'])) ?></td>
                                <td>
                                    <?= $usr['last_login'] ? date('M d, Y H:i', strtotime($usr['last_login'])) : 'Never' ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>

