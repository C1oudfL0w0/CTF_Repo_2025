<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🏠 Home - B-Notes</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: #f3f4f6;
            min-height: 100vh;
        }
        
        .navbar {
            background: white;
            padding: 15px 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            position: sticky;
            top: 0;
            z-index: 100;
        }
        
        .navbar-container {
            max-width: 1400px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .navbar-brand {
            font-size: 24px;
            font-weight: bold;
            color: #1f2937;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .navbar-nav {
            display: flex;
            gap: 20px;
            align-items: center;
        }
        
        .nav-link {
            text-decoration: none;
            color: #6b7280;
            transition: color 0.3s ease;
            font-size: 14px;
            font-weight: 500;
        }
        
        .nav-link:hover {
            color: #667eea;
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 30px 20px;
        }
        
        .layout {
            display: grid;
            grid-template-columns: 250px 1fr 300px;
            gap: 30px;
        }
        
        .sidebar {
            position: sticky;
            top: 90px;
            height: fit-content;
        }
        
        .card {
            background: white;
            border-radius: 16px;
            padding: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 20px;
        }
        
        .card-title {
            font-size: 18px;
            font-weight: 600;
            color: #1f2937;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .category-list {
            list-style: none;
        }
        
        .category-item {
            margin-bottom: 10px;
        }
        
        .category-link {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 15px;
            border-radius: 10px;
            text-decoration: none;
            color: #374151;
            transition: all 0.3s ease;
            font-size: 14px;
        }
        
        .category-link:hover {
            background: #f3f4f6;
            transform: translateX(5px);
        }
        
        .category-link.active {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            font-weight: 600;
        }
        
        .category-color {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            flex-shrink: 0;
        }
        
        .search-box {
            margin-bottom: 25px;
        }
        
        .search-input {
            width: 100%;
            padding: 14px 20px 14px 45px;
            border: 2px solid #e5e7eb;
            border-radius: 12px;
            font-size: 15px;
            transition: all 0.3s ease;
            background: white url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="%236b7280" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>') no-repeat 15px center;
        }
        
        .search-input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1);
        }
        
        .notes-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
        }
        
        .note-card {
            background: white;
            border-radius: 16px;
            padding: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            transition: all 0.3s ease;
            cursor: pointer;
            text-decoration: none;
            color: inherit;
            display: block;
        }
        
        .note-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
        }
        
        .note-header {
            display: flex;
            justify-content: space-between;
            align-items: start;
            margin-bottom: 15px;
        }
        
        .note-title {
            font-size: 18px;
            font-weight: 600;
            color: #1f2937;
            margin-bottom: 10px;
            line-height: 1.4;
        }
        
        .note-meta {
            font-size: 12px;
            color: #9ca3af;
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 12px;
        }
        
        .note-content {
            color: #6b7280;
            font-size: 14px;
            line-height: 1.6;
            margin-bottom: 15px;
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }
        
        .note-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-top: 15px;
            border-top: 1px solid #f3f4f6;
        }
        
        .note-author {
            font-size: 13px;
            color: #667eea;
            font-weight: 600;
        }
        
        .badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 600;
        }
        
        .badge-public {
            background: #d1fae5;
            color: #065f46;
        }
        
        .badge-private {
            background: #fee2e2;
            color: #991b1b;
        }
        
        .tags {
            display: flex;
            flex-wrap: wrap;
            gap: 6px;
            margin-top: 10px;
        }
        
        .tag {
            padding: 4px 10px;
            background: #f3f4f6;
            border-radius: 6px;
            font-size: 12px;
            color: #6b7280;
        }
        
        .popular-list {
            list-style: none;
        }
        
        .popular-item {
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 1px solid #f3f4f6;
        }
        
        .popular-item:last-child {
            border-bottom: none;
            margin-bottom: 0;
            padding-bottom: 0;
        }
        
        .popular-link {
            text-decoration: none;
            color: #1f2937;
            font-size: 14px;
            font-weight: 500;
            display: block;
            margin-bottom: 5px;
            transition: color 0.3s ease;
        }
        
        .popular-link:hover {
            color: #667eea;
        }
        
        .popular-stats {
            font-size: 12px;
            color: #9ca3af;
            display: flex;
            gap: 12px;
        }
        
        .alert {
            padding: 14px 18px;
            border-radius: 12px;
            margin-bottom: 25px;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .alert-success {
            background: #d1fae5;
            color: #065f46;
            border: 1px solid #a7f3d0;
        }
        
        .alert-error {
            background: #fee2e2;
            color: #991b1b;
            border: 1px solid #fecaca;
        }
        
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #9ca3af;
        }
        
        .empty-state-icon {
            font-size: 64px;
            margin-bottom: 20px;
        }
        
        .empty-state h3 {
            font-size: 20px;
            color: #6b7280;
            margin-bottom: 10px;
        }
        
        .pagination {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-top: 30px;
        }
        
        .page-link {
            padding: 10px 16px;
            background: white;
            border: 2px solid #e5e7eb;
            border-radius: 8px;
            text-decoration: none;
            color: #374151;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .page-link:hover {
            border-color: #667eea;
            color: #667eea;
        }
        
        .page-link.active {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-color: transparent;
        }
        
        @media (max-width: 1024px) {
            .layout {
                grid-template-columns: 1fr;
            }
            
            .sidebar {
                position: static;
            }
            
            .notes-grid {
                grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="navbar-container">
            <a href="/" class="navbar-brand">📝 B-Notes</a>
            <div class="navbar-nav">
                <?php if ($user): ?>
                    <a href="/notes/create" class="btn btn-primary">✍️ New Note</a>
                    <a href="/my-notes" class="nav-link">📚 My Notes</a>
                    <a href="/favorites" class="nav-link">⭐ Favorites</a>
                    <a href="/profile" class="nav-link">👤 <?= htmlspecialchars($user['username']) ?></a>
                    <?php if ($user['role'] === 'admin'): ?>
                        <a href="/admin" class="nav-link">👑 Admin</a>
                    <?php endif; ?>
                    <a href="/logout" class="nav-link">🚪 Logout</a>
                <?php else: ?>
                    <a href="/login" class="nav-link">🔐 Login</a>
                    <a href="/register" class="btn btn-primary">✨ Sign Up</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>
    
    <div class="container">
        <?php if (isset($success)): ?>
            <div class="alert alert-success">
                <span>✅</span>
                <span><?= htmlspecialchars($success) ?></span>
            </div>
        <?php endif; ?>
        
        <?php if (isset($error)): ?>
            <div class="alert alert-error">
                <span>⚠️</span>
                <span><?= htmlspecialchars($error) ?></span>
            </div>
        <?php endif; ?>
        
        <div class="layout">
            <aside class="sidebar">
                <div class="card">
                    <h3 class="card-title">📂 Categories</h3>
                    <ul class="category-list">
                        <li class="category-item">
                            <a href="/" class="category-link <?= !$currentCategory ? 'active' : '' ?>">
                                🌐 All Notes
                            </a>
                        </li>
                        <?php foreach ($categories as $category): ?>
                            <li class="category-item">
                                <a href="/?category=<?= $category['id'] ?>" 
                                   class="category-link <?= $currentCategory === $category['id'] ? 'active' : '' ?>">
                                    <span class="category-color" style="background: <?= htmlspecialchars($category['color']) ?>"></span>
                                    <?= htmlspecialchars($category['name']) ?>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </aside>
            
            <main>
                <div class="search-box">
                    <form action="/search" method="GET">
                        <input 
                            type="text" 
                            name="q" 
                            class="search-input" 
                            placeholder="🔍 Search notes, tags, users..."
                            value="<?= htmlspecialchars($search ?? '') ?>"
                        >
                    </form>
                </div>
                
                <?php if (empty($notes)): ?>
                    <div class="empty-state">
                        <div class="empty-state-icon">📭</div>
                        <h3>No notes found</h3>
                        <p>Be the first to create a note!</p>
                        <?php if ($user): ?>
                            <a href="/notes/create" class="btn btn-primary" style="margin-top: 20px;">✍️ Create Note</a>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <div class="notes-grid">
                        <?php foreach ($notes as $note): ?>
                            <a href="/notes/<?= $note['id'] ?>" class="note-card">
                                <div class="note-header">
                                    <div style="flex: 1;">
                                        <h3 class="note-title"><?= htmlspecialchars($note['title']) ?></h3>
                                        <div class="note-meta">
                                            <span>👁️ <?= $note['views'] ?? 0 ?></span>
                                            <span>💬 <?= $note['comments_count'] ?? 0 ?></span>
                                            <span>⭐ <?= $note['favorites_count'] ?? 0 ?></span>
                                        </div>
                                    </div>
                                    <span class="badge <?= $note['is_public'] ? 'badge-public' : 'badge-private' ?>">
                                        <?= $note['is_public'] ? '🌐 Public' : '🔒 Private' ?>
                                    </span>
                                </div>
                                <p class="note-content"><?= htmlspecialchars(substr($note['content'], 0, 150)) ?>...</p>
                                <div class="note-footer">
                                    <span class="note-author">✍️ <?= htmlspecialchars($note['username']) ?></span>
                                    <span style="font-size: 12px; color: #9ca3af;">
                                        <?= date('M d, Y', strtotime($note['created_at'])) ?>
                                    </span>
                                </div>
                            </a>
                        <?php endforeach; ?>
                    </div>
                    
                    <?php if ($totalPages > 1): ?>
                        <div class="pagination">
                            <?php if ($page > 1): ?>
                                <a href="?page=<?= $page - 1 ?><?= $currentCategory ? '&category=' . $currentCategory : '' ?>" class="page-link">← Previous</a>
                            <?php endif; ?>
                            
                            <?php for ($i = max(1, $page - 2); $i <= min($totalPages, $page + 2); $i++): ?>
                                <a href="?page=<?= $i ?><?= $currentCategory ? '&category=' . $currentCategory : '' ?>" 
                                   class="page-link <?= $i === $page ? 'active' : '' ?>">
                                    <?= $i ?>
                                </a>
                            <?php endfor; ?>
                            
                            <?php if ($page < $totalPages): ?>
                                <a href="?page=<?= $page + 1 ?><?= $currentCategory ? '&category=' . $currentCategory : '' ?>" class="page-link">Next →</a>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </main>
            
            <aside class="sidebar">
                <div class="card">
                    <h3 class="card-title">🔥 Popular Notes</h3>
                    <ul class="popular-list">
                        <?php foreach ($popular as $note): ?>
                            <li class="popular-item">
                                <a href="/notes/<?= $note['id'] ?>" class="popular-link">
                                    <?= htmlspecialchars($note['title']) ?>
                                </a>
                                <div class="popular-stats">
                                    <span>👁️ <?= $note['views'] ?? 0 ?></span>
                                    <span>💬 <?= $note['comments_count'] ?? 0 ?></span>
                                </div>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </aside>
        </div>
    </div>
</body>
</html>

