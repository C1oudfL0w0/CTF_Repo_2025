<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>✍️ Create Note - B-Notes</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: #f3f4f6;
            min-height: 100vh;
        }
        
        .navbar {
            background: white;
            padding: 15px 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }
        
        .navbar-container {
            max-width: 900px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .navbar-brand {
            font-size: 24px;
            font-weight: bold;
            color: #1f2937;
            text-decoration: none;
        }
        
        .navbar-nav {
            display: flex;
            gap: 20px;
            align-items: center;
        }
        
        .nav-link {
            text-decoration: none;
            color: #6b7280;
            transition: color 0.3s ease;
            font-size: 14px;
        }
        
        .nav-link:hover {
            color: #667eea;
        }
        
        .container {
            max-width: 900px;
            margin: 0 auto;
            padding: 0 20px 40px;
        }
        
        .page-header {
            margin-bottom: 30px;
        }
        
        .page-title {
            font-size: 32px;
            font-weight: 700;
            color: #1f2937;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .page-description {
            color: #6b7280;
            font-size: 16px;
        }
        
        .card {
            background: white;
            border-radius: 16px;
            padding: 40px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .form-group {
            margin-bottom: 25px;
        }
        
        .form-label {
            display: block;
            font-weight: 600;
            color: #374151;
            margin-bottom: 10px;
            font-size: 15px;
        }
        
        .form-control {
            width: 100%;
            padding: 14px 18px;
            border: 2px solid #e5e7eb;
            border-radius: 10px;
            font-size: 15px;
            font-family: inherit;
            transition: all 0.3s ease;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1);
        }
        
        textarea.form-control {
            resize: vertical;
            min-height: 400px;
            line-height: 1.6;
        }
        
        .form-select {
            width: 100%;
            padding: 14px 18px;
            border: 2px solid #e5e7eb;
            border-radius: 10px;
            font-size: 15px;
            font-family: inherit;
            transition: all 0.3s ease;
            background: white;
            cursor: pointer;
        }
        
        .form-select:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1);
        }
        
        .form-hint {
            font-size: 13px;
            color: #6b7280;
            margin-top: 8px;
            display: block;
        }
        
        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 16px;
            background: #f9fafb;
            border-radius: 10px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .checkbox-group:hover {
            background: #f3f4f6;
        }
        
        .checkbox-group input[type="checkbox"] {
            width: 20px;
            height: 20px;
            cursor: pointer;
        }
        
        .checkbox-label {
            font-size: 15px;
            color: #374151;
            font-weight: 500;
            cursor: pointer;
        }
        
        .actions {
            display: flex;
            gap: 15px;
            margin-top: 30px;
            padding-top: 30px;
            border-top: 2px solid #f3f4f6;
        }
        
        .btn {
            padding: 14px 28px;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            flex: 1;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
        }
        
        .btn-secondary {
            background: #e5e7eb;
            color: #374151;
        }
        
        .btn-secondary:hover {
            background: #d1d5db;
        }
        
        .info-box {
            background: #eff6ff;
            border: 1px solid #bfdbfe;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 25px;
        }
        
        .info-box h4 {
            color: #1e40af;
            font-size: 15px;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .info-box ul {
            list-style: none;
            font-size: 14px;
            color: #1e40af;
        }
        
        .info-box li {
            padding: 4px 0;
            padding-left: 20px;
            position: relative;
        }
        
        .info-box li::before {
            content: '•';
            position: absolute;
            left: 8px;
            font-weight: bold;
        }
        
        @media (max-width: 768px) {
            .card {
                padding: 25px;
            }
            
            .actions {
                flex-direction: column;
            }
            
            .btn {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="navbar-container">
            <a href="/" class="navbar-brand">📝 B-Notes</a>
            <div class="navbar-nav">
                <a href="/" class="nav-link">🏠 Home</a>
                <a href="/my-notes" class="nav-link">📚 My Notes</a>
                <a href="/profile" class="nav-link">👤 Profile</a>
            </div>
        </div>
    </nav>
    
    <div class="container">
        <div class="page-header">
            <h1 class="page-title">✍️ Create New Note</h1>
            <p class="page-description">Share your thoughts, ideas, and knowledge with the community</p>
        </div>
        
        <div class="card">
            <div class="info-box">
                <h4>💡 Tips for creating great notes</h4>
                <ul>
                    <li>Use a clear and descriptive title</li>
                    <li>Add relevant tags to help others find your note</li>
                    <li>Choose the appropriate category</li>
                    <li>Make it public to share with the community</li>
                </ul>
            </div>
            
            <form method="POST" action="/notes">
                <div class="form-group">
                    <label class="form-label" for="title">📌 Title *</label>
                    <input 
                        type="text" 
                        id="title" 
                        name="title" 
                        class="form-control" 
                        placeholder="Enter note title..."
                        required
                        autofocus
                    >
                </div>
                
                <div class="form-group">
                    <label class="form-label" for="category_id">📂 Category *</label>
                    <select id="category_id" name="category_id" class="form-select" required="" autofocus="">
                        <option value="">Select a category...</option>
                        <?php foreach ($categories as $category): ?>
                            <option value="<?= $category['id'] ?>">
                                <?= htmlspecialchars($category['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <small class="form-hint">Choose the most relevant category for your note</small>
                </div>
                
                <div class="form-group">
                    <label class="form-label" for="content">📝 Content *</label>
                    <textarea 
                        id="content" 
                        name="content" 
                        class="form-control" 
                        placeholder="Write your note content here..."
                        required
                    ></textarea>
                    <small class="form-hint">You can use markdown formatting</small>
                </div>
                
                <div class="form-group">
                    <label class="form-label" for="tags">🏷️ Tags</label>
                    <input 
                        type="text" 
                        id="tags" 
                        name="tags" 
                        class="form-control" 
                        placeholder="e.g. javascript, tutorial, web development"
                    >
                    <small class="form-hint">Separate tags with commas</small>
                </div>
                
                <div class="form-group">
                    <label class="checkbox-group">
                        <input 
                            type="checkbox" 
                            name="is_public" 
                            id="is_public"
                            checked
                        >
                        <span class="checkbox-label">
                            🌐 Make this note public (visible to everyone)
                        </span>
                    </label>
                </div>
                
                <div class="actions">
                    <button type="submit" class="btn btn-primary">
                        🚀 Publish Note
                    </button>
                    <a href="/" class="btn btn-secondary">
                        ❌ Cancel
                    </a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>

