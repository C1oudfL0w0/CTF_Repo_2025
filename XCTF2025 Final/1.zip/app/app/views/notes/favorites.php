<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>⭐ Favorites - B-Notes</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: #f3f4f6;
            min-height: 100vh;
        }
        
        .navbar {
            background: white;
            padding: 15px 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }
        
        .navbar-container {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .navbar-brand {
            font-size: 24px;
            font-weight: bold;
            color: #1f2937;
            text-decoration: none;
        }
        
        .navbar-nav {
            display: flex;
            gap: 20px;
            align-items: center;
        }
        
        .nav-link {
            text-decoration: none;
            color: #6b7280;
            transition: color 0.3s ease;
            font-size: 14px;
        }
        
        .nav-link:hover {
            color: #667eea;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px 40px;
        }
        
        .page-header {
            margin-bottom: 30px;
        }
        
        .page-title {
            font-size: 32px;
            font-weight: 700;
            color: #1f2937;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .page-description {
            color: #6b7280;
            font-size: 16px;
        }
        
        .favorites-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 20px;
        }
        
        .favorite-card {
            background: white;
            border-radius: 16px;
            padding: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            transition: all 0.3s ease;
            position: relative;
        }
        
        .favorite-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
        }
        
        .favorite-header {
            display: flex;
            justify-content: space-between;
            align-items: start;
            margin-bottom: 15px;
        }
        
        .note-title {
            font-size: 18px;
            font-weight: 600;
            color: #1f2937;
            text-decoration: none;
            display: block;
            margin-bottom: 10px;
            line-height: 1.4;
            transition: color 0.3s ease;
        }
        
        .note-title:hover {
            color: #667eea;
        }
        
        .unfavorite-btn {
            background: #fee2e2;
            color: #dc2626;
            border: none;
            width: 32px;
            height: 32px;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 16px;
            flex-shrink: 0;
        }
        
        .unfavorite-btn:hover {
            background: #fecaca;
            transform: scale(1.1);
        }
        
        .note-meta {
            font-size: 12px;
            color: #9ca3af;
            display: flex;
            gap: 12px;
            margin-bottom: 12px;
        }
        
        .note-excerpt {
            color: #6b7280;
            font-size: 14px;
            line-height: 1.6;
            margin-bottom: 15px;
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }
        
        .note-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-top: 15px;
            border-top: 1px solid #f3f4f6;
        }
        
        .note-author {
            font-size: 13px;
            color: #667eea;
            font-weight: 600;
        }
        
        .favorite-date {
            font-size: 12px;
            color: #9ca3af;
        }
        
        .empty-state {
            text-align: center;
            padding: 80px 20px;
            background: white;
            border-radius: 16px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .empty-state-icon {
            font-size: 80px;
            margin-bottom: 20px;
        }
        
        .empty-state h3 {
            font-size: 24px;
            color: #1f2937;
            margin-bottom: 10px;
        }
        
        .empty-state p {
            color: #6b7280;
            font-size: 16px;
            margin-bottom: 30px;
        }
        
        .btn-primary {
            padding: 12px 24px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
        }
        
        @media (max-width: 768px) {
            .favorites-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="navbar-container">
            <a href="/" class="navbar-brand">📝 B-Notes</a>
            <div class="navbar-nav">
                <a href="/" class="nav-link">🏠 Home</a>
                <a href="/my-notes" class="nav-link">📚 My Notes</a>
                <a href="/profile" class="nav-link">👤 Profile</a>
                <a href="/logout" class="nav-link">🚪 Logout</a>
            </div>
        </div>
    </nav>
    
    <div class="container">
        <div class="page-header">
            <h1 class="page-title">⭐ My Favorites</h1>
            <p class="page-description">Notes you've bookmarked for quick access</p>
        </div>
        
        <?php if (empty($favorites)): ?>
            <div class="empty-state">
                <div class="empty-state-icon">⭐</div>
                <h3>No favorites yet</h3>
                <p>Start exploring notes and add them to your favorites!</p>
                <a href="/" class="btn-primary">🔍 Explore Notes</a>
            </div>
        <?php else: ?>
            <div class="favorites-grid">
                <?php foreach ($favorites as $favorite): ?>
                    <div class="favorite-card">
                        <div class="favorite-header">
                            <div style="flex: 1;">
                                <a href="/notes/<?= $favorite['note_id'] ?>" class="note-title">
                                    <?= htmlspecialchars($favorite['title']) ?>
                                </a>
                                <div class="note-meta">
                                    <span>👁️ <?= $favorite['views'] ?? 0 ?></span>
                                    <span>💬 <?= $favorite['comments_count'] ?? 0 ?></span>
                                </div>
                            </div>
                            <form method="POST" action="/notes/<?= $favorite['note_id'] ?>/favorite">
                                <button type="submit" class="unfavorite-btn" title="Remove from favorites">
                                    ❌
                                </button>
                            </form>
                        </div>
                        <p class="note-excerpt">
                            <?= htmlspecialchars(substr($favorite['content'], 0, 120)) ?>...
                        </p>
                        <div class="note-footer">
                            <span class="note-author">✍️ <?= htmlspecialchars($favorite['username']) ?></span>
                            <span class="favorite-date">
                                ⭐ <?= date('M d, Y', strtotime($favorite['favorited_at'])) ?>
                            </span>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>

