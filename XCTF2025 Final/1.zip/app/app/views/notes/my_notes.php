<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>📚 My Notes - B-Notes</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: #f3f4f6;
            min-height: 100vh;
        }
        
        .navbar {
            background: white;
            padding: 15px 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }
        
        .navbar-container {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .navbar-brand {
            font-size: 24px;
            font-weight: bold;
            color: #1f2937;
            text-decoration: none;
        }
        
        .navbar-nav {
            display: flex;
            gap: 20px;
            align-items: center;
        }
        
        .nav-link {
            text-decoration: none;
            color: #6b7280;
            transition: color 0.3s ease;
            font-size: 14px;
        }
        
        .nav-link:hover {
            color: #667eea;
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px 40px;
        }
        
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }
        
        .page-title {
            font-size: 32px;
            font-weight: 700;
            color: #1f2937;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .alert {
            padding: 14px 18px;
            border-radius: 12px;
            margin-bottom: 25px;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .alert-success {
            background: #d1fae5;
            color: #065f46;
            border: 1px solid #a7f3d0;
        }
        
        .notes-list {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        
        .note-item {
            background: white;
            border-radius: 16px;
            padding: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            transition: all 0.3s ease;
        }
        
        .note-item:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
        }
        
        .note-main {
            display: flex;
            justify-content: space-between;
            gap: 20px;
        }
        
        .note-info {
            flex: 1;
        }
        
        .note-title {
            font-size: 20px;
            font-weight: 600;
            color: #1f2937;
            margin-bottom: 10px;
            text-decoration: none;
            display: inline-block;
            transition: color 0.3s ease;
        }
        
        .note-title:hover {
            color: #667eea;
        }
        
        .note-meta {
            font-size: 13px;
            color: #6b7280;
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            margin-bottom: 12px;
        }
        
        .note-excerpt {
            color: #6b7280;
            font-size: 14px;
            line-height: 1.6;
            margin-bottom: 15px;
        }
        
        .note-tags {
            display: flex;
            flex-wrap: wrap;
            gap: 6px;
        }
        
        .tag {
            padding: 4px 10px;
            background: #f3f4f6;
            border-radius: 6px;
            font-size: 12px;
            color: #6b7280;
        }
        
        .note-actions {
            display: flex;
            flex-direction: column;
            gap: 8px;
            min-width: 120px;
        }
        
        .btn-sm {
            padding: 8px 16px;
            font-size: 13px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            justify-content: center;
            font-weight: 600;
        }
        
        .btn-view {
            background: #667eea;
            color: white;
        }
        
        .btn-view:hover {
            background: #5568d3;
        }
        
        .btn-edit {
            background: #f59e0b;
            color: white;
        }
        
        .btn-edit:hover {
            background: #d97706;
        }
        
        .btn-delete {
            background: #ef4444;
            color: white;
        }
        
        .btn-delete:hover {
            background: #dc2626;
        }
        
        .badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 600;
        }
        
        .badge-public {
            background: #d1fae5;
            color: #065f46;
        }
        
        .badge-private {
            background: #fee2e2;
            color: #991b1b;
        }
        
        .empty-state {
            text-align: center;
            padding: 80px 20px;
            background: white;
            border-radius: 16px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .empty-state-icon {
            font-size: 80px;
            margin-bottom: 20px;
        }
        
        .empty-state h3 {
            font-size: 24px;
            color: #1f2937;
            margin-bottom: 10px;
        }
        
        .empty-state p {
            color: #6b7280;
            font-size: 16px;
            margin-bottom: 30px;
        }
        
        @media (max-width: 768px) {
            .page-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
            
            .note-main {
                flex-direction: column;
            }
            
            .note-actions {
                flex-direction: row;
                min-width: auto;
                width: 100%;
            }
            
            .btn-sm {
                flex: 1;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="navbar-container">
            <a href="/" class="navbar-brand">📝 B-Notes</a>
            <div class="navbar-nav">
                <a href="/" class="nav-link">🏠 Home</a>
                <a href="/favorites" class="nav-link">⭐ Favorites</a>
                <a href="/profile" class="nav-link">👤 Profile</a>
                <a href="/logout" class="nav-link">🚪 Logout</a>
            </div>
        </div>
    </nav>
    
    <div class="container">
        <div class="page-header">
            <h1 class="page-title">📚 My Notes</h1>
            <a href="/notes/create" class="btn btn-primary">✍️ Create New Note</a>
        </div>
        
        <?php if (isset($success)): ?>
            <div class="alert alert-success">
                <span>✅</span>
                <span><?= htmlspecialchars($success) ?></span>
            </div>
        <?php endif; ?>
        
        <?php if (empty($notes)): ?>
            <div class="empty-state">
                <div class="empty-state-icon">📭</div>
                <h3>No notes yet</h3>
                <p>Start creating your first note and share your knowledge!</p>
                <a href="/notes/create" class="btn btn-primary">✍️ Create Your First Note</a>
            </div>
        <?php else: ?>
            <div class="notes-list">
                <?php foreach ($notes as $note): ?>
                    <div class="note-item">
                        <div class="note-main">
                            <div class="note-info">
                                <a href="/notes/<?= $note['id'] ?>" class="note-title">
                                    <?= htmlspecialchars($note['title']) ?>
                                </a>
                                <div class="note-meta">
                                    <span>👁️ <?= $note['views'] ?? 0 ?> views</span>
                                    <span>💬 <?= $note['comments_count'] ?? 0 ?> comments</span>
                                    <span>⭐ <?= $note['favorites_count'] ?? 0 ?> favorites</span>
                                    <span>📅 <?= date('M d, Y', strtotime($note['created_at'])) ?></span>
                                    <span class="badge <?= $note['is_public'] ? 'badge-public' : 'badge-private' ?>">
                                        <?= $note['is_public'] ? '🌐 Public' : '🔒 Private' ?>
                                    </span>
                                </div>
                                <p class="note-excerpt">
                                    <?= htmlspecialchars(substr($note['content'], 0, 150)) ?>...
                                </p>
                            </div>
                            <div class="note-actions">
                                <a href="/notes/<?= $note['id'] ?>" class="btn-sm btn-view">
                                    👁️ View
                                </a>
                                <a href="/notes/<?= $note['id'] ?>/edit" class="btn-sm btn-edit">
                                    ✏️ Edit
                                </a>
                                <form method="POST" action="/notes/<?= $note['id'] ?>/delete" 
                                      onsubmit="return confirm('Are you sure you want to delete this note?')">
                                    <button type="submit" class="btn-sm btn-delete">
                                        🗑️ Delete
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>

