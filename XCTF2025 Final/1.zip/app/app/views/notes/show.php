<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>📄 <?= htmlspecialchars($note['title']) ?> - B-Notes</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: #f3f4f6;
            min-height: 100vh;
        }
        
        .navbar {
            background: white;
            padding: 15px 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }
        
        .navbar-container {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .navbar-brand {
            font-size: 24px;
            font-weight: bold;
            color: #1f2937;
            text-decoration: none;
        }
        
        .navbar-nav {
            display: flex;
            gap: 20px;
            align-items: center;
        }
        
        .nav-link {
            text-decoration: none;
            color: #6b7280;
            transition: color 0.3s ease;
            font-size: 14px;
        }
        
        .nav-link:hover {
            color: #667eea;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px 40px;
        }
        
        .note-header {
            background: white;
            border-radius: 16px;
            padding: 40px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }
        
        .note-title {
            font-size: 36px;
            font-weight: 700;
            color: #1f2937;
            margin-bottom: 20px;
            line-height: 1.3;
        }
        
        .note-meta {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            align-items: center;
            padding-bottom: 20px;
            border-bottom: 2px solid #f3f4f6;
            margin-bottom: 20px;
        }
        
        .meta-item {
            display: flex;
            align-items: center;
            gap: 6px;
            font-size: 14px;
            color: #6b7280;
        }
        
        .author-info {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .author-avatar {
            font-size: 32px;
        }
        
        .author-details h4 {
            color: #1f2937;
            font-size: 16px;
            margin-bottom: 4px;
        }
        
        .author-details p {
            color: #9ca3af;
            font-size: 13px;
        }
        
        .actions {
            display: flex;
            gap: 12px;
            margin-top: 20px;
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 10px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
        }
        
        .btn-secondary {
            background: #e5e7eb;
            color: #374151;
        }
        
        .btn-secondary:hover {
            background: #d1d5db;
        }
        
        .btn-success {
            background: #10b981;
            color: white;
        }
        
        .btn-success:hover {
            background: #059669;
        }
        
        .btn-warning {
            background: #f59e0b;
            color: white;
        }
        
        .btn-warning:hover {
            background: #d97706;
        }
        
        .btn-danger {
            background: #ef4444;
            color: white;
        }
        
        .btn-danger:hover {
            background: #dc2626;
        }
        
        .badge {
            display: inline-block;
            padding: 6px 14px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .badge-public {
            background: #d1fae5;
            color: #065f46;
        }
        
        .badge-private {
            background: #fee2e2;
            color: #991b1b;
        }
        
        .note-content {
            background: white;
            border-radius: 16px;
            padding: 40px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }
        
        .content-text {
            color: #374151;
            font-size: 16px;
            line-height: 1.8;
            white-space: pre-wrap;
        }
        
        .tags {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 30px;
            padding-top: 30px;
            border-top: 2px solid #f3f4f6;
        }
        
        .tag {
            padding: 8px 16px;
            background: #f3f4f6;
            border-radius: 20px;
            font-size: 14px;
            color: #667eea;
            text-decoration: none;
            transition: all 0.3s ease;
            font-weight: 500;
        }
        
        .tag:hover {
            background: #667eea;
            color: white;
        }
        
        .comments-section {
            background: white;
            border-radius: 16px;
            padding: 40px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .section-title {
            font-size: 24px;
            font-weight: 600;
            color: #1f2937;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .comment-form {
            margin-bottom: 30px;
            padding: 25px;
            background: #f9fafb;
            border-radius: 12px;
        }
        
        .form-control {
            width: 100%;
            padding: 14px 18px;
            border: 2px solid #e5e7eb;
            border-radius: 10px;
            font-size: 15px;
            font-family: inherit;
            transition: all 0.3s ease;
            resize: vertical;
            min-height: 100px;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1);
        }
        
        .comment-list {
            list-style: none;
        }
        
        .comment-item {
            padding: 20px;
            margin-bottom: 15px;
            background: #f9fafb;
            border-radius: 12px;
            border-left: 4px solid #667eea;
        }
        
        .comment-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 12px;
        }
        
        .comment-author {
            font-weight: 600;
            color: #1f2937;
            font-size: 14px;
        }
        
        .comment-date {
            color: #9ca3af;
            font-size: 12px;
        }
        
        .comment-content {
            color: #4b5563;
            font-size: 14px;
            line-height: 1.6;
        }
        
        .comment-reply {
            margin-left: 30px;
            margin-top: 10px;
            padding-left: 20px;
            border-left: 2px solid #e5e7eb;
        }
        
        .alert {
            padding: 14px 18px;
            border-radius: 12px;
            margin-bottom: 25px;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .alert-success {
            background: #d1fae5;
            color: #065f46;
            border: 1px solid #a7f3d0;
        }
        
        .alert-error {
            background: #fee2e2;
            color: #991b1b;
            border: 1px solid #fecaca;
        }
        
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: #9ca3af;
        }
        
        .empty-state-icon {
            font-size: 48px;
            margin-bottom: 15px;
        }
        
        @media (max-width: 768px) {
            .note-title {
                font-size: 28px;
            }
            
            .note-header, .note-content, .comments-section {
                padding: 25px;
            }
            
            .actions {
                flex-direction: column;
            }
            
            .btn {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="navbar-container">
            <a href="/" class="navbar-brand">📝 B-Notes</a>
            <div class="navbar-nav">
                <a href="/" class="nav-link">🏠 Home</a>
                <?php if ($user): ?>
                    <a href="/my-notes" class="nav-link">📚 My Notes</a>
                    <a href="/profile" class="nav-link">👤 Profile</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>
    
    <div class="container">
        <?php if (isset($success)): ?>
            <div class="alert alert-success">
                <span>✅</span>
                <span><?= htmlspecialchars($success) ?></span>
            </div>
        <?php endif; ?>
        
        <?php if (isset($error)): ?>
            <div class="alert alert-error">
                <span>⚠️</span>
                <span><?= htmlspecialchars($error) ?></span>
            </div>
        <?php endif; ?>
        
        <div class="note-header">
            <h1 class="note-title"><?= htmlspecialchars($note['title']) ?></h1>
            
            <div class="note-meta">
                <div class="author-info">
                    <div class="author-avatar">👨‍💻</div>
                    <div class="author-details">
                        <h4><?= htmlspecialchars($note['author']) ?></h4>
                        <p><?= date('F d, Y \a\t H:i', strtotime($note['created_at'])) ?></p>
                    </div>
                </div>
                <span class="meta-item">👁️ <?= $note['views'] ?? 0 ?> views</span>
                <span class="meta-item">💬 <?= count($comments) ?> comments</span>
                <span class="meta-item">⭐ <?= $note['favorites_count'] ?? 0 ?> favorites</span>
                <span class="badge <?= $note['is_public'] ? 'badge-public' : 'badge-private' ?>">
                    <?= $note['is_public'] ? '🌐 Public' : '🔒 Private' ?>
                </span>
            </div>
            
            <div class="actions">
                <?php if ($user): ?>
                    <form method="POST" action="/notes/<?= $note['id'] ?>/favorite" style="display: inline;">
                        <button type="submit" class="btn <?= $isFavorited ? 'btn-warning' : 'btn-success' ?>">
                            <?= $isFavorited ? '⭐ Unfavorite' : '⭐ Favorite' ?>
                        </button>
                    </form>
                    <a href="/share/create?note=<?= $note['id'] ?>" class="btn btn-secondary">
                        🔗 Share
                    </a>
                <?php endif; ?>
                
                <?php if ($isOwner): ?>
                    <a href="/notes/<?= $note['id'] ?>/edit" class="btn btn-primary">
                        ✏️ Edit
                    </a>
                    <form method="POST" action="/notes/<?= $note['id'] ?>/delete" 
                          style="display: inline;"
                          onsubmit="return confirm('Are you sure you want to delete this note?')">
                        <button type="submit" class="btn btn-danger">
                            🗑️ Delete
                        </button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="note-content">
            <div class="content-text"><?= htmlspecialchars($note['content']) ?></div>
            
            <?php if (!empty($tags)): ?>
                <div class="tags">
                    <span style="color: #6b7280; font-weight: 600;">🏷️ Tags:</span>
                    <?php foreach ($tags as $tag): ?>
                        <a href="/search?q=<?= urlencode($tag['name']) ?>&type=tags" class="tag">
                            #<?= htmlspecialchars($tag['name']) ?>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
        
        <div class="comments-section">
            <h2 class="section-title">💬 Comments (<?= count($comments) ?>)</h2>
            
            <?php if ($user): ?>
                <div class="comment-form">
                    <form method="POST" action="/comments/create">
                        <input type="hidden" name="note_id" value="<?= $note['id'] ?>">
                        <textarea 
                            name="content" 
                            class="form-control" 
                            placeholder="Write your comment here..."
                            required
                        ></textarea>
                        <button type="submit" class="btn btn-primary" style="margin-top: 15px;">
                            📝 Post Comment
                        </button>
                    </form>
                </div>
            <?php else: ?>
                <div class="alert alert-error">
                    <span>🔒</span>
                    <span>Please <a href="/login" style="color: inherit; font-weight: bold;">login</a> to post a comment</span>
                </div>
            <?php endif; ?>
            
            <?php if (empty($comments)): ?>
                <div class="empty-state">
                    <div class="empty-state-icon">💭</div>
                    <p>No comments yet. Be the first to comment!</p>
                </div>
            <?php else: ?>
                <ul class="comment-list">
                    <?php foreach ($comments as $comment): ?>
                        <?php if (!$comment['parent_id']): ?>
                            <li class="comment-item">
                                <div class="comment-header">
                                    <span class="comment-author">
                                        👤 <?= htmlspecialchars($comment['username']) ?>
                                    </span>
                                    <span class="comment-date">
                                        <?= date('M d, Y H:i', strtotime($comment['created_at'])) ?>
                                    </span>
                                </div>
                                <div class="comment-content">
                                    <?= htmlspecialchars($comment['content']) ?>
                                </div>
                                
                                <?php foreach ($comments as $reply): ?>
                                    <?php if ($reply['parent_id'] === $comment['id']): ?>
                                        <div class="comment-reply">
                                            <div class="comment-header">
                                                <span class="comment-author">
                                                    👤 <?= htmlspecialchars($reply['username']) ?>
                                                </span>
                                                <span class="comment-date">
                                                    <?= date('M d, Y H:i', strtotime($reply['created_at'])) ?>
                                                </span>
                                            </div>
                                            <div class="comment-content">
                                                <?= htmlspecialchars($reply['content']) ?>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>

