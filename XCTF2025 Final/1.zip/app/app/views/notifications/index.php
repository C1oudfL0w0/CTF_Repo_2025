<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🔔 Notifications - B-Notes</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: #f3f4f6;
            min-height: 100vh;
        }
        
        .navbar {
            background: white;
            padding: 15px 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }
        
        .navbar-container {
            max-width: 1000px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .navbar-brand {
            font-size: 24px;
            font-weight: bold;
            color: #1f2937;
            text-decoration: none;
        }
        
        .navbar-nav {
            display: flex;
            gap: 20px;
            align-items: center;
        }
        
        .nav-link {
            text-decoration: none;
            color: #6b7280;
            transition: color 0.3s ease;
            font-size: 14px;
        }
        
        .nav-link:hover {
            color: #667eea;
        }
        
        .container {
            max-width: 1000px;
            margin: 0 auto;
            padding: 0 20px 40px;
        }
        
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }
        
        .page-title {
            font-size: 32px;
            font-weight: 700;
            color: #1f2937;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .unread-count {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 32px;
            height: 32px;
            background: #ef4444;
            color: white;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 600;
            padding: 0 10px;
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        
        .btn-secondary {
            background: #e5e7eb;
            color: #374151;
        }
        
        .btn-secondary:hover {
            background: #d1d5db;
        }
        
        .notifications-list {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        
        .notification-item {
            background: white;
            border-radius: 16px;
            padding: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            transition: all 0.3s ease;
            display: flex;
            gap: 20px;
            position: relative;
        }
        
        .notification-item:hover {
            transform: translateX(5px);
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
        }
        
        .notification-item.unread {
            background: #eff6ff;
            border-left: 4px solid #3b82f6;
        }
        
        .notification-item.unread::before {
            content: '';
            position: absolute;
            top: 25px;
            right: 25px;
            width: 10px;
            height: 10px;
            background: #3b82f6;
            border-radius: 50%;
        }
        
        .notification-icon {
            font-size: 40px;
            width: 60px;
            height: 60px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50%;
            flex-shrink: 0;
        }
        
        .notification-content {
            flex: 1;
        }
        
        .notification-title {
            font-size: 18px;
            font-weight: 600;
            color: #1f2937;
            margin-bottom: 8px;
        }
        
        .notification-message {
            color: #6b7280;
            font-size: 15px;
            line-height: 1.6;
            margin-bottom: 10px;
        }
        
        .notification-meta {
            display: flex;
            gap: 15px;
            font-size: 13px;
            color: #9ca3af;
        }
        
        .notification-type {
            display: inline-block;
            padding: 4px 12px;
            background: #f3f4f6;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            color: #6b7280;
        }
        
        .empty-state {
            text-align: center;
            padding: 80px 20px;
            background: white;
            border-radius: 16px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .empty-state-icon {
            font-size: 80px;
            margin-bottom: 20px;
        }
        
        .empty-state h3 {
            font-size: 24px;
            color: #1f2937;
            margin-bottom: 10px;
        }
        
        .empty-state p {
            color: #6b7280;
            font-size: 16px;
        }
        
        @media (max-width: 768px) {
            .page-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
            
            .notification-item {
                flex-direction: column;
                text-align: center;
            }
            
            .notification-icon {
                margin: 0 auto;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="navbar-container">
            <a href="/" class="navbar-brand">📝 B-Notes</a>
            <div class="navbar-nav">
                <a href="/" class="nav-link">🏠 Home</a>
                <a href="/my-notes" class="nav-link">📚 My Notes</a>
                <a href="/profile" class="nav-link">👤 Profile</a>
                <a href="/logout" class="nav-link">🚪 Logout</a>
            </div>
        </div>
    </nav>
    
    <div class="container">
        <div class="page-header">
            <h1 class="page-title">
                🔔 Notifications
                <?php if (isset($unread_count) && $unread_count > 0): ?>
                    <span class="unread-count"><?= $unread_count ?></span>
                <?php endif; ?>
            </h1>
            <?php if (!empty($notifications)): ?>
                <form method="POST" action="/notifications/mark-all-read" style="display: inline;">
                    <button type="submit" class="btn btn-secondary">
                        ✅ Mark All as Read
                    </button>
                </form>
            <?php endif; ?>
        </div>
        
        <?php if (empty($notifications)): ?>
            <div class="empty-state">
                <div class="empty-state-icon">🔔</div>
                <h3>No notifications yet</h3>
                <p>You're all caught up! Check back later for updates.</p>
            </div>
        <?php else: ?>
            <div class="notifications-list">
                <?php foreach ($notifications as $notification): ?>
                    <div class="notification-item <?= !$notification['is_read'] ? 'unread' : '' ?>">
                        <div class="notification-icon">
                            <?php
                            $icons = [
                                'comment' => '💬',
                                'favorite' => '⭐',
                                'share' => '🔗',
                                'mention' => '👋',
                                'follow' => '👥',
                                'like' => '❤️',
                                'system' => '📢'
                            ];
                            echo $icons[$notification['type']] ?? '📌';
                            ?>
                        </div>
                        <div class="notification-content">
                            <h3 class="notification-title">
                                <?php
                                $titles = [
                                    'comment' => 'New Comment',
                                    'favorite' => 'New Favorite',
                                    'share' => 'Note Shared',
                                    'mention' => 'You were mentioned',
                                    'follow' => 'New Follower',
                                    'like' => 'Someone liked your note',
                                    'system' => 'System Notification'
                                ];
                                echo $titles[$notification['type']] ?? 'Notification';
                                ?>
                            </h3>
                            <p class="notification-message">
                                <?= htmlspecialchars($notification['message']) ?>
                            </p>
                            <div class="notification-meta">
                                <span class="notification-type">
                                    <?= ucfirst($notification['type']) ?>
                                </span>
                                <span>
                                    🕐 <?= date('M d, Y H:i', strtotime($notification['created_at'])) ?>
                                </span>
                                <?php if (!$notification['is_read']): ?>
                                    <span style="color: #3b82f6; font-weight: 600;">● New</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>

