<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🔍 Search Results - B-Notes</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: #f3f4f6;
            min-height: 100vh;
        }
        
        .navbar {
            background: white;
            padding: 15px 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }
        
        .navbar-container {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .navbar-brand {
            font-size: 24px;
            font-weight: bold;
            color: #1f2937;
            text-decoration: none;
        }
        
        .navbar-nav {
            display: flex;
            gap: 20px;
            align-items: center;
        }
        
        .nav-link {
            text-decoration: none;
            color: #6b7280;
            transition: color 0.3s ease;
            font-size: 14px;
        }
        
        .nav-link:hover {
            color: #667eea;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px 40px;
        }
        
        .search-header {
            margin-bottom: 30px;
        }
        
        .search-box {
            margin-bottom: 25px;
        }
        
        .search-input-group {
            display: flex;
            gap: 15px;
        }
        
        .search-input {
            flex: 1;
            padding: 16px 20px 16px 50px;
            border: 2px solid #e5e7eb;
            border-radius: 12px;
            font-size: 16px;
            transition: all 0.3s ease;
            background: white url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="%236b7280" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>') no-repeat 18px center;
        }
        
        .search-input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1);
        }
        
        .btn-search {
            padding: 16px 32px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-search:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
        }
        
        .filter-tabs {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        
        .filter-tab {
            padding: 10px 20px;
            background: white;
            border: 2px solid #e5e7eb;
            border-radius: 10px;
            text-decoration: none;
            color: #6b7280;
            font-size: 14px;
            font-weight: 600;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 6px;
        }
        
        .filter-tab:hover {
            border-color: #667eea;
            color: #667eea;
        }
        
        .filter-tab.active {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-color: transparent;
        }
        
        .search-info {
            background: white;
            border-radius: 12px;
            padding: 20px 25px;
            margin-bottom: 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .search-query {
            font-size: 18px;
            color: #1f2937;
        }
        
        .search-query strong {
            color: #667eea;
        }
        
        .results-count {
            color: #6b7280;
            font-size: 14px;
        }
        
        .results-list {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }
        
        .result-card {
            background: white;
            border-radius: 16px;
            padding: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            transition: all 0.3s ease;
        }
        
        .result-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(0,0,0,0.1);
        }
        
        .result-type {
            display: inline-block;
            padding: 4px 12px;
            background: #eff6ff;
            color: #1e40af;
            border-radius: 6px;
            font-size: 12px;
            font-weight: 600;
            margin-bottom: 12px;
        }
        
        .result-title {
            font-size: 22px;
            font-weight: 600;
            color: #1f2937;
            margin-bottom: 12px;
            text-decoration: none;
            display: block;
            transition: color 0.3s ease;
        }
        
        .result-title:hover {
            color: #667eea;
        }
        
        .result-meta {
            font-size: 13px;
            color: #9ca3af;
            display: flex;
            gap: 15px;
            margin-bottom: 15px;
        }
        
        .result-excerpt {
            color: #6b7280;
            font-size: 15px;
            line-height: 1.7;
            margin-bottom: 15px;
        }
        
        .result-tags {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }
        
        .tag {
            padding: 6px 12px;
            background: #f3f4f6;
            border-radius: 6px;
            font-size: 13px;
            color: #6b7280;
        }
        
        .user-result {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .user-avatar {
            font-size: 48px;
            width: 80px;
            height: 80px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50%;
        }
        
        .user-info {
            flex: 1;
        }
        
        .user-name {
            font-size: 24px;
            font-weight: 600;
            color: #1f2937;
            margin-bottom: 8px;
        }
        
        .user-bio {
            color: #6b7280;
            font-size: 15px;
            margin-bottom: 12px;
        }
        
        .user-stats {
            display: flex;
            gap: 20px;
            font-size: 14px;
            color: #6b7280;
        }
        
        .empty-state {
            text-align: center;
            padding: 80px 20px;
            background: white;
            border-radius: 16px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .empty-state-icon {
            font-size: 80px;
            margin-bottom: 20px;
        }
        
        .empty-state h3 {
            font-size: 24px;
            color: #1f2937;
            margin-bottom: 10px;
        }
        
        .empty-state p {
            color: #6b7280;
            font-size: 16px;
        }
        
        @media (max-width: 768px) {
            .search-input-group {
                flex-direction: column;
            }
            
            .search-info {
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }
            
            .user-result {
                flex-direction: column;
                text-align: center;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="navbar-container">
            <a href="/" class="navbar-brand">📝 B-Notes</a>
            <div class="navbar-nav">
                <a href="/" class="nav-link">🏠 Home</a>
                <?php if ($user): ?>
                    <a href="/my-notes" class="nav-link">📚 My Notes</a>
                    <a href="/profile" class="nav-link">👤 Profile</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>
    
    <div class="container">
        <div class="search-header">
            <div class="search-box">
                <form action="/search" method="GET" class="search-input-group">
                    <input 
                        type="text" 
                        name="q" 
                        class="search-input" 
                        placeholder="Search notes, users, tags..."
                        value="<?= htmlspecialchars($query) ?>"
                        autofocus
                    >
                    <input type="hidden" name="type" value="<?= htmlspecialchars($type) ?>">
                    <button type="submit" class="btn-search">
                        🔍 Search
                    </button>
                </form>
            </div>
            
            <div class="filter-tabs">
                <a href="/search?q=<?= urlencode($query) ?>&type=notes" 
                   class="filter-tab <?= $type === 'notes' ? 'active' : '' ?>">
                    📝 Notes
                </a>
                <a href="/search?q=<?= urlencode($query) ?>&type=users" 
                   class="filter-tab <?= $type === 'users' ? 'active' : '' ?>">
                    👤 Users
                </a>
                <a href="/search?q=<?= urlencode($query) ?>&type=tags" 
                   class="filter-tab <?= $type === 'tags' ? 'active' : '' ?>">
                    🏷️ Tags
                </a>
            </div>
        </div>
        
        <?php if ($query): ?>
            <div class="search-info">
                <div class="search-query">
                    Results for <strong>"<?= htmlspecialchars($query) ?>"</strong>
                </div>
                <div class="results-count">
                    <?= count($results) ?> result<?= count($results) !== 1 ? 's' : '' ?> found
                </div>
            </div>
        <?php endif; ?>
        
        <?php if (empty($results)): ?>
            <div class="empty-state">
                <div class="empty-state-icon">🔍</div>
                <h3>No results found</h3>
                <p>Try different keywords or search in another category</p>
            </div>
        <?php else: ?>
            <div class="results-list">
                <?php foreach ($results as $result): ?>
                    <?php if ($type === 'notes' || $type === 'tags'): ?>
                        <div class="result-card">
                            <span class="result-type">📝 Note</span>
                            <a href="/notes/<?= $result['id'] ?>" class="result-title">
                                <?= htmlspecialchars($result['title']) ?>
                            </a>
                            <div class="result-meta">
                                <span>✍️ <?= htmlspecialchars($result['author']) ?></span>
                                <span>👁️ <?= $result['views'] ?? 0 ?> views</span>
                                <span>📅 <?= date('M d, Y', strtotime($result['created_at'])) ?></span>
                            </div>
                            <p class="result-excerpt">
                                <?= isset($result['content']) ? htmlspecialchars(substr($result['content'], 0, 200)) . '...' : 'No preview available' ?>
                            </p>
                        </div>
                    <?php elseif ($type === 'users'): ?>
                        <div class="result-card">
                            <div class="user-result">
                                <div class="user-avatar">👨‍💻</div>
                                <div class="user-info">
                                    <span class="result-type">👤 User</span>
                                    <h3 class="user-name"><?= htmlspecialchars($result['username']) ?></h3>
                                    <?php if (!empty($result['bio'])): ?>
                                        <p class="user-bio"><?= htmlspecialchars($result['bio']) ?></p>
                                    <?php endif; ?>
                                    <div class="user-stats">
                                        <span>📝 <?= $result['notes_count'] ?? 0 ?> notes</span>
                                        <span>📅 Joined <?= date('M Y', strtotime($result['created_at'])) ?></span>
                                        <?php if ($result['role'] === 'admin'): ?>
                                            <span style="color: #f59e0b; font-weight: 600;">👑 Admin</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>

