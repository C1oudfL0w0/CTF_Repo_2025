<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🔗 Shared Note - B-Notes</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 40px 20px;
        }
        
        .container {
            max-width: 900px;
            margin: 0 auto;
        }
        
        .share-badge {
            text-align: center;
            color: white;
            margin-bottom: 30px;
            animation: fadeIn 0.5s ease-out;
        }
        
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .share-badge h1 {
            font-size: 48px;
            margin-bottom: 10px;
        }
        
        .share-badge p {
            font-size: 18px;
            opacity: 0.95;
        }
        
        .share-info {
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(10px);
            border-radius: 12px;
            padding: 15px 20px;
            margin-bottom: 25px;
            display: flex;
            justify-content: center;
            gap: 30px;
            flex-wrap: wrap;
            color: white;
            font-size: 14px;
        }
        
        .share-info-item {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .note-container {
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            overflow: hidden;
            animation: slideUp 0.6s ease-out;
        }
        
        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .note-header {
            padding: 40px;
            border-bottom: 2px solid #f3f4f6;
        }
        
        .note-title {
            font-size: 36px;
            font-weight: 700;
            color: #1f2937;
            margin-bottom: 20px;
            line-height: 1.3;
        }
        
        .note-meta {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            font-size: 14px;
            color: #6b7280;
        }
        
        .meta-item {
            display: flex;
            align-items: center;
            gap: 6px;
        }
        
        .note-author {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 15px 20px;
            background: #f9fafb;
            border-radius: 12px;
        }
        
        .author-avatar {
            font-size: 32px;
        }
        
        .author-details h4 {
            color: #1f2937;
            font-size: 16px;
            margin-bottom: 4px;
        }
        
        .author-details p {
            color: #9ca3af;
            font-size: 13px;
        }
        
        .note-content {
            padding: 40px;
        }
        
        .content-text {
            color: #374151;
            font-size: 16px;
            line-height: 1.8;
            white-space: pre-wrap;
        }
        
        .tags {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 30px;
            padding-top: 30px;
            border-top: 2px solid #f3f4f6;
        }
        
        .tag {
            padding: 8px 16px;
            background: #f3f4f6;
            border-radius: 20px;
            font-size: 14px;
            color: #667eea;
            font-weight: 500;
        }
        
        .note-footer {
            padding: 30px 40px;
            background: #f9fafb;
            text-align: center;
            border-top: 2px solid #e5e7eb;
        }
        
        .note-footer h3 {
            color: #1f2937;
            font-size: 20px;
            margin-bottom: 10px;
        }
        
        .note-footer p {
            color: #6b7280;
            font-size: 14px;
            margin-bottom: 20px;
        }
        
        .btn {
            padding: 12px 28px;
            border: none;
            border-radius: 10px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
        }
        
        .warning-box {
            background: #fef3c7;
            border: 1px solid #fbbf24;
            border-radius: 12px;
            padding: 15px 20px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 12px;
            color: #92400e;
            font-size: 14px;
        }
        
        .warning-icon {
            font-size: 24px;
        }
        
        @media (max-width: 768px) {
            .note-title {
                font-size: 28px;
            }
            
            .note-header, .note-content, .note-footer {
                padding: 25px;
            }
            
            .share-info {
                font-size: 12px;
                gap: 15px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="share-badge">
            <h1>🔗</h1>
            <p>You're viewing a shared note from <strong>B-Notes</strong></p>
        </div>
        
        <?php if (isset($share['expires_at']) && $share['expires_at']): ?>
            <?php 
            $expiresAt = strtotime($share['expires_at']);
            $now = time();
            $timeLeft = $expiresAt - $now;
            if ($timeLeft > 0 && $timeLeft < 86400): // Less than 24 hours
            ?>
                <div class="warning-box">
                    <span class="warning-icon">⚠️</span>
                    <span>
                        <strong>Expiring Soon!</strong> This shared link will expire 
                        <?php if ($timeLeft < 3600): ?>
                            in <?= ceil($timeLeft / 60) ?> minutes
                        <?php else: ?>
                            in <?= ceil($timeLeft / 3600) ?> hours
                        <?php endif; ?>
                    </span>
                </div>
            <?php endif; ?>
        <?php endif; ?>
        
        <div class="share-info">
            <div class="share-info-item">
                <span>👁️</span>
                <span><?= $share['view_count'] ?? 0 ?> views</span>
            </div>
            <?php if (isset($share['max_views']) && $share['max_views'] > 0): ?>
                <div class="share-info-item">
                    <span>📊</span>
                    <span><?= $share['max_views'] - ($share['view_count'] ?? 0) ?> views remaining</span>
                </div>
            <?php endif; ?>
            <?php if (isset($share['expires_at']) && $share['expires_at']): ?>
                <div class="share-info-item">
                    <span>⏰</span>
                    <span>Expires <?= date('M d, Y', strtotime($share['expires_at'])) ?></span>
                </div>
            <?php endif; ?>
        </div>
        
        <div class="note-container">
            <div class="note-header">
                <h1 class="note-title"><?= htmlspecialchars($note['title']) ?></h1>
                
                <div class="note-meta">
                    <div class="note-author">
                        <div class="author-avatar">👨‍💻</div>
                        <div class="author-details">
                            <h4><?= htmlspecialchars($note['username']) ?></h4>
                            <p>Shared on <?= date('F d, Y', strtotime($share['created_at'])) ?></p>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="note-content">
                <div class="content-text"><?= htmlspecialchars($note['content']) ?></div>
                
                <?php if (!empty($tags)): ?>
                    <div class="tags">
                        <span style="color: #6b7280; font-weight: 600;">🏷️ Tags:</span>
                        <?php foreach ($tags as $tag): ?>
                            <span class="tag">#<?= htmlspecialchars($tag['name']) ?></span>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
            
            <div class="note-footer">
                <h3>📝 Want to create your own notes?</h3>
                <p>Join B-Notes community and start sharing your knowledge!</p>
                <a href="/" class="btn btn-primary">
                    🚀 Get Started
                </a>
            </div>
        </div>
    </div>
</body>
</html>

