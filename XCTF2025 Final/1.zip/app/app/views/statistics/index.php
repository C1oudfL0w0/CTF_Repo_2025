<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>📊 Statistics - B-Notes</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: #f3f4f6;
            min-height: 100vh;
        }
        
        .navbar {
            background: white;
            padding: 15px 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }
        
        .navbar-container {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .navbar-brand {
            font-size: 24px;
            font-weight: bold;
            color: #1f2937;
            text-decoration: none;
        }
        
        .navbar-nav {
            display: flex;
            gap: 20px;
            align-items: center;
        }
        
        .nav-link {
            text-decoration: none;
            color: #6b7280;
            transition: color 0.3s ease;
            font-size: 14px;
        }
        
        .nav-link:hover {
            color: #667eea;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px 40px;
        }
        
        .page-header {
            margin-bottom: 40px;
        }
        
        .page-title {
            font-size: 36px;
            font-weight: 700;
            color: #1f2937;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .page-description {
            color: #6b7280;
            font-size: 16px;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 25px;
            margin-bottom: 40px;
        }
        
        .stat-card {
            background: white;
            border-radius: 16px;
            padding: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
        }
        
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        
        .stat-icon {
            font-size: 48px;
            margin-bottom: 15px;
        }
        
        .stat-value {
            font-size: 36px;
            font-weight: 700;
            color: #1f2937;
            margin-bottom: 8px;
        }
        
        .stat-label {
            color: #6b7280;
            font-size: 14px;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .section {
            background: white;
            border-radius: 16px;
            padding: 35px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }
        
        .section-title {
            font-size: 24px;
            font-weight: 600;
            color: #1f2937;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .tags-cloud {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
        }
        
        .tag-item {
            padding: 12px 20px;
            background: linear-gradient(135deg, #f3f4f6 0%, #e5e7eb 100%);
            border-radius: 25px;
            font-size: 14px;
            font-weight: 500;
            color: #374151;
            transition: all 0.3s ease;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .tag-item:hover {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            transform: scale(1.05);
        }
        
        .tag-count {
            background: rgba(0,0,0,0.1);
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .users-list {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
        }
        
        .user-card {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 20px;
            background: #f9fafb;
            border-radius: 12px;
            transition: all 0.3s ease;
        }
        
        .user-card:hover {
            background: #f3f4f6;
            transform: translateX(5px);
        }
        
        .user-rank {
            font-size: 24px;
            font-weight: 700;
            color: #9ca3af;
            width: 40px;
            text-align: center;
        }
        
        .user-rank.gold {
            color: #f59e0b;
        }
        
        .user-rank.silver {
            color: #9ca3af;
        }
        
        .user-rank.bronze {
            color: #d97706;
        }
        
        .user-avatar {
            font-size: 36px;
            width: 60px;
            height: 60px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50%;
        }
        
        .user-info {
            flex: 1;
        }
        
        .user-name {
            font-size: 16px;
            font-weight: 600;
            color: #1f2937;
            margin-bottom: 5px;
        }
        
        .user-stats {
            font-size: 13px;
            color: #6b7280;
        }
        
        .chart-placeholder {
            height: 300px;
            background: linear-gradient(135deg, #f3f4f6 0%, #e5e7eb 100%);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #9ca3af;
            font-size: 18px;
            font-weight: 600;
        }
        
        @media (max-width: 768px) {
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            .users-list {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="navbar-container">
            <a href="/" class="navbar-brand">📝 B-Notes</a>
            <div class="navbar-nav">
                <a href="/" class="nav-link">🏠 Home</a>
                <?php if (isset($user)): ?>
                    <a href="/my-notes" class="nav-link">📚 My Notes</a>
                    <a href="/profile" class="nav-link">👤 Profile</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>
    
    <div class="container">
        <div class="page-header">
            <h1 class="page-title">📊 Platform Statistics</h1>
            <p class="page-description">Overview of B-Notes community activity and insights</p>
        </div>
        
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">👥</div>
                <div class="stat-value"><?= number_format($stats['total_users'] ?? 0) ?></div>
                <div class="stat-label">Total Users</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">📝</div>
                <div class="stat-value"><?= number_format($stats['total_notes'] ?? 0) ?></div>
                <div class="stat-label">Total Notes</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">👁️</div>
                <div class="stat-value"><?= number_format($stats['total_views'] ?? 0) ?></div>
                <div class="stat-label">Total Views</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">💬</div>
                <div class="stat-value"><?= number_format($stats['total_comments'] ?? 0) ?></div>
                <div class="stat-label">Total Comments</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">🏷️</div>
                <div class="stat-value"><?= number_format($stats['total_tags'] ?? 0) ?></div>
                <div class="stat-label">Total Tags</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">⭐</div>
                <div class="stat-value"><?= number_format($stats['total_favorites'] ?? 0) ?></div>
                <div class="stat-label">Total Favorites</div>
            </div>
        </div>
        
        <div class="section">
            <h2 class="section-title">🔥 Trending Tags</h2>
            <?php if (!empty($stats['trending_tags'])): ?>
                <div class="tags-cloud">
                    <?php foreach ($stats['trending_tags'] as $tag): ?>
                        <a href="/search?q=<?= urlencode($tag['name']) ?>&type=tags" class="tag-item">
                            <span>#<?= htmlspecialchars($tag['name']) ?></span>
                            <span class="tag-count"><?= $tag['count'] ?></span>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p style="color: #9ca3af;">No trending tags yet</p>
            <?php endif; ?>
        </div>
        
        <div class="section">
            <h2 class="section-title">🏆 Top Contributors</h2>
            <?php if (!empty($stats['active_users'])): ?>
                <div class="users-list">
                    <?php foreach ($stats['active_users'] as $index => $activeUser): ?>
                        <div class="user-card">
                            <div class="user-rank <?= $index === 0 ? 'gold' : ($index === 1 ? 'silver' : ($index === 2 ? 'bronze' : '')) ?>">
                                <?php if ($index === 0): ?>
                                    🥇
                                <?php elseif ($index === 1): ?>
                                    🥈
                                <?php elseif ($index === 2): ?>
                                    🥉
                                <?php else: ?>
                                    #<?= $index + 1 ?>
                                <?php endif; ?>
                            </div>
                            <div class="user-avatar">👨‍💻</div>
                            <div class="user-info">
                                <div class="user-name"><?= htmlspecialchars($activeUser['username']) ?></div>
                                <div class="user-stats">
                                    📝 <?= $activeUser['notes_count'] ?? 0 ?> notes • 
                                    💬 <?= $activeUser['comments_count'] ?? 0 ?> comments
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p style="color: #9ca3af;">No active users yet</p>
            <?php endif; ?>
        </div>
        
        <div class="section">
            <h2 class="section-title">📈 Activity Overview</h2>
            <div class="chart-placeholder">
                📊 Chart visualization coming soon
            </div>
        </div>
    </div>
</body>
</html>

