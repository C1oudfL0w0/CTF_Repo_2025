from flask import Flask, request
import os

app = Flask(__name__)


@app.route("/flag", methods=["GET", "POST"])
def flag():
    user = request.headers.get("user")
    passwd = request.form.get("passwd")
    data = open('/flag', 'r').read()
    if user and user == "admin" and passwd and passwd == "xiaoming":
        return data or 'flag{flask_test}'
    return "only admin can get flag"


@app.get('/test')
def test():
    return "test"


app.run(host='0.0.0.0', port=5000)
