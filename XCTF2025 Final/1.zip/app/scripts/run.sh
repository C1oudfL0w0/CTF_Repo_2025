#!/bin/bash
exec apache2-foreground &

sleep 10

python3 /var/www/html/flask/flag.py &

curl http://127.0.0.1/register -X POST -d "username=flag" -d "password=changeme" -d "email=flag@note.com" -c /tmp/cookies_123.txt
curl http://127.0.0.1/notes -X POST -d "title=flag" -d "category_id=cat-2" -d "content=flag{test}" -b /tmp/cookies_123.txt

curl http://127.0.0.1/register -X POST -d "username=admin" -d "password=changeme" -d "email=admin@note.com"
sqlite3 /var/www/html/app/data/app.db "UPDATE users SET role = 'admin' WHERE username = 'admin';"

tail -f /dev/null