"""Nebula Salvage League main application package."""

from .main import create_app

__all__ = ["create_app"]
