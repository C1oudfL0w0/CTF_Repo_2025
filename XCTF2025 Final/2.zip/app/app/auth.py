from __future__ import annotations

import secrets
from typing import Optional

from fastapi import Depends, HTTPException, Header, status
from passlib.context import CryptContext
from sqlalchemy.orm import Session

from .database import get_db
from .models import Session as SessionModel
from .models import User
from .utils import generate_id

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def hash_password(password: str) -> str:
    return pwd_context.hash(password)


def verify_password(password: str, hashed: str) -> bool:
    return pwd_context.verify(password, hashed)


def create_session(db: Session, user: User) -> SessionModel:
    token = secrets.token_urlsafe(32)
    session = SessionModel(id=generate_id(), user_id=user.id, token=token)
    db.add(session)
    db.commit()
    db.refresh(session)
    return session


def get_current_user(
    authorization: Optional[str] = Header(None), db: Session = Depends(get_db)
) -> User:
    if not authorization:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Missing token")

    scheme, _, token = authorization.partition(" ")
    if scheme.lower() != "bearer" or not token:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token")

    session = (
        db.query(SessionModel)
        .filter(SessionModel.token == token)
        .join(User)
        .first()
    )
    if not session:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Unknown token")
    return session.user
