from __future__ import annotations

import os
import secrets
from functools import lru_cache
from pathlib import Path

from .utils import ensure_dir


class Settings:
    """Runtime configuration for the web service."""

    database_url: str
    storage_root: Path
    flag_path: Path
    legacy_hkdf_salt: bytes
    legacy_hkdf_info: bytes
    modern_hkdf_salt: bytes
    modern_hkdf_info: bytes
    maintenance_token: str
    pulse_worker_interval: float

    def __init__(self) -> None:
        base_dir = Path(os.getenv("NSL_STORAGE_ROOT", "./srv")).resolve()
        self.storage_root = base_dir
        self.database_url = os.getenv(
            "NSL_DATABASE_URL", f"sqlite:///{(base_dir / 'data.db').as_posix()}"
        )
        self.flag_path = Path(os.getenv("FLAG_PATH", "/flag"))

        # Constants for key derivation
        self.legacy_hkdf_salt = bytes.fromhex(
            os.getenv(
                "NSL_LEGACY_SALT",
                "4f3f2e1d0c0b0a090807060504030201000102030405060708090a0b0c0d0e0f",
            )
        )
        self.legacy_hkdf_info = b"relay-boot-legacy"
        self.modern_hkdf_salt = bytes.fromhex(
            os.getenv(
                "NSL_MODERN_SALT",
                "4f3f2e1d0c0b0a090807060504030201000102030405060708090a0b0c0d0e0f",
            )
        )
        self.modern_hkdf_info = b"relay-boot-modern"

        self.maintenance_token = self._load_maintenance_token()
        self.pulse_worker_interval = float(os.getenv("NSL_PULSE_INTERVAL", "1.0"))

    def _load_maintenance_token(self) -> str:
        token = os.getenv("NSL_MAINT_TOKEN")
        token_path = self.storage_root / "maintenance_token"
        if token:
            ensure_dir(token_path.parent)
            try:
                token_path.write_text(token)
            except PermissionError:
                pass
        else:
            if token_path.exists():
                token = token_path.read_text().strip()
            else:
                ensure_dir(token_path.parent)
                token = secrets.token_urlsafe(32)
                try:
                    token_path.write_text(token)
                except PermissionError:
                    pass
            os.environ["NSL_MAINT_TOKEN"] = token
        try:
            token_path.chmod(0o640)
        except PermissionError:
            pass
        return token


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
