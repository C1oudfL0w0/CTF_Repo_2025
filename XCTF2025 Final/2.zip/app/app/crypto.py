from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Optional

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import x25519
from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

from .config import get_settings
from .utils import b64encode

settings = get_settings()


@dataclass
class HandshakeResult:
    session_key: bytes
    server_private: x25519.X25519PrivateKey
    server_public_bytes: bytes
    client_public_bytes: bytes


def perform_handshake(
    mode: str,
    client_public_b64: Optional[str],
    client_seed_hex: Optional[str],
) -> HandshakeResult:
    server_private = x25519.X25519PrivateKey.generate()
    server_public_bytes = server_private.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )

    if mode == "modern":
        if not client_public_b64:
            raise ValueError("modern mode requires client_public")
        client_public_bytes = b64decode_no_padding(client_public_b64)
        client_public = x25519.X25519PublicKey.from_public_bytes(client_public_bytes)
        shared_secret = server_private.exchange(client_public)
        salt = settings.modern_hkdf_salt
        info = settings.modern_hkdf_info
    elif mode == "legacy":
        if client_public_b64:
            client_public_bytes = b64decode_no_padding(client_public_b64)
            client_public = x25519.X25519PublicKey.from_public_bytes(client_public_bytes)
        else:
            if not client_seed_hex:
                raise ValueError("legacy mode requires client_seed when client_public missing")
            seed_bytes = bytes.fromhex(client_seed_hex)
            padded = seed_bytes.ljust(32, b"\x00")
            client_private = x25519.X25519PrivateKey.from_private_bytes(padded)
            client_public = client_private.public_key()
            client_public_bytes = client_public.public_bytes(
                encoding=serialization.Encoding.Raw,
                format=serialization.PublicFormat.Raw,
            )
        shared_secret = server_private.exchange(client_public)
        salt = settings.legacy_hkdf_salt
        info = settings.legacy_hkdf_info
    else:
        raise ValueError("unknown mode")

    session_key = HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        info=info,
    ).derive(shared_secret)

    return HandshakeResult(
        session_key=session_key,
        server_private=server_private,
        server_public_bytes=server_public_bytes,
        client_public_bytes=client_public_bytes,
    )


def encrypt_ticket(session_key: bytes, aad: bytes, payload: bytes) -> tuple[str, str, str]:
    nonce = os.urandom(12)
    cipher = ChaCha20Poly1305(session_key)
    ciphertext = cipher.encrypt(nonce, payload, aad)
    tag = ciphertext[-16:]
    body = ciphertext[:-16]
    return b64encode(nonce), b64encode(aad), b64encode(body + tag)


def b64decode_no_padding(data: str) -> bytes:
    import base64

    padding = '=' * (-len(data) % 4)
    return base64.b64decode(data + padding)
