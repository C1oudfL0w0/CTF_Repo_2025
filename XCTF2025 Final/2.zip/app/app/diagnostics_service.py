from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, Header, HTTPException, status
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from .config import get_settings
from .models import RelayToken
from .utils import read_flag

settings = get_settings()

engine = create_engine(
    settings.database_url,
    connect_args={"check_same_thread": False}
    if settings.database_url.startswith("sqlite")
    else {},
)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)

app = FastAPI(title="Diagnosticsd")


def _get_flag() -> str:
    flag_path: Path = settings.flag_path
    if not flag_path.exists():
        raise HTTPException(status_code=500, detail="flag missing")
    return read_flag(flag_path)


@app.get("/health")
def health() -> dict:
    return {"status": "ok"}


@app.get("/admin/vault/snapshot")
def vault_snapshot(authorization: Optional[str] = Header(None)) -> dict:
    if not authorization:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="authorization required")
    scheme, _, token = authorization.partition(" ")
    if scheme.lower() != "bearer" or not token:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="invalid header")

    with SessionLocal() as session:
        flag_value = _get_flag()

        if token == settings.maintenance_token:
            mode = "maintenance"
        else:
            record = session.query(RelayToken).filter(RelayToken.access_token == token).first()
            if not record:
                raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="invalid token")
            mode = record.mode

        return {
            "status": "ok",
            "flag": flag_value,
            "hash": hashlib.sha256(flag_value.encode()).hexdigest(),
            "mode": mode,
        }
