from __future__ import annotations

import json
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from .config import get_settings
from .database import Base, engine, session_scope
from .models import Mission, User
from .pulsebus import PulseBus
from .routes import api_router
from .utils import ensure_dir, generate_id, read_flag

settings = get_settings()
BASE_DIR = Path(__file__).resolve().parent
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))


def create_app() -> FastAPI:
    app = FastAPI(title="Nebula Salvage League")
    app.include_router(api_router)
    app.mount(
        "/static",
        StaticFiles(directory=str(BASE_DIR / "static")),
        name="static",
    )
    app.state.pulsebus = PulseBus()

    @app.on_event("startup")
    def _startup() -> None:
        Base.metadata.create_all(bind=engine)
        _prepare_storage()
        # _sync_flag_secret()
        app.state.pulsebus.start()
        _ensure_demo_content()

    @app.on_event("shutdown")
    def _shutdown() -> None:
        if app.state.pulsebus:
            app.state.pulsebus.stop()

    @app.get("/", response_class=HTMLResponse)
    def index(request: Request) -> HTMLResponse:
        return templates.TemplateResponse("index.html", {"request": request})

    return app


def _prepare_storage() -> None:
    ensure_dir(settings.storage_root)
    ensure_dir(settings.storage_root / "data" / "missions")
    ensure_dir(settings.storage_root / "data" / "diagnostics")


# def _sync_flag_secret() -> None:
#     # Ensure the main flag file exists; if missing, create placeholder.
#     flag_path = settings.flag_path
#     if not flag_path.exists():
#         flag_path.write_text("flag{development_flag}")


def _ensure_demo_content() -> None:
    """Create a placeholder mission for first-time users."""
    with session_scope() as session:
        system_user = session.get(User, "system")
        if not system_user:
            system_user = User(
                id="system",
                username="system",
                password_hash="!",
                role="system",
            )
            session.add(system_user)
            session.flush()
        if session.query(Mission).count() == 0:
            demo = Mission(
                id=generate_id(),
                creator_id=system_user.id,
                title="Welcome Salvage Operation",
                telemetry_url="https://example.com/telemetry.json",
                status="active",
            )
            session.add(demo)


app = create_app()
