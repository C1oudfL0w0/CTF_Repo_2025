from __future__ import annotations

import json
from datetime import datetime
from typing import Any, Dict, Optional

from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    ForeignKey,
    Integer,
    LargeBinary,
    String,
    Text,
)
from sqlalchemy.orm import relationship

from .database import Base


def _now() -> datetime:
    return datetime.utcnow()


class User(Base):
    __tablename__ = "users"

    id = Column(String(64), primary_key=True)
    username = Column(String(64), unique=True, nullable=False)
    password_hash = Column(String(128), nullable=False)
    role = Column(String(32), default="user", nullable=False)
    created_at = Column(DateTime, default=_now, nullable=False)

    sessions = relationship("Session", back_populates="user", cascade="all, delete-orphan")
    relays = relationship("Relay", back_populates="owner", cascade="all, delete-orphan")


class Session(Base):
    __tablename__ = "sessions"

    id = Column(String(64), primary_key=True)
    user_id = Column(String(64), ForeignKey("users.id"), nullable=False)
    token = Column(String(128), unique=True, nullable=False)
    created_at = Column(DateTime, default=_now, nullable=False)

    user = relationship("User", back_populates="sessions")


class Relay(Base):
    __tablename__ = "relays"

    id = Column(String(64), primary_key=True)
    owner_id = Column(String(64), ForeignKey("users.id"), nullable=False)
    name = Column(String(128), nullable=False)
    created_at = Column(DateTime, default=_now, nullable=False)

    owner = relationship("User", back_populates="relays")
    tokens = relationship("RelayToken", back_populates="relay", cascade="all, delete-orphan")
    jobs = relationship("PulseJob", back_populates="relay", cascade="all, delete-orphan")
    logs = relationship("MissionLog", back_populates="relay")


class RelayToken(Base):
    __tablename__ = "relay_tokens"

    id = Column(String(64), primary_key=True)
    relay_id = Column(String(64), ForeignKey("relays.id"), nullable=False)
    mode = Column(String(32), nullable=False)
    access_token = Column(String(128), unique=True, nullable=False)
    ticket_encrypted = Column(LargeBinary, nullable=False)
    aad = Column(String(256), nullable=False)
    nonce = Column(String(64), nullable=False)
    created_at = Column(DateTime, default=_now, nullable=False)

    relay = relationship("Relay", back_populates="tokens")


class Mission(Base):
    __tablename__ = "missions"

    id = Column(String(64), primary_key=True)
    creator_id = Column(String(64), ForeignKey("users.id"), nullable=False)
    title = Column(String(128), nullable=False)
    telemetry_url = Column(String(256), nullable=True)
    status = Column(String(32), default="draft", nullable=False)
    created_at = Column(DateTime, default=_now, nullable=False)


class MissionLog(Base):
    __tablename__ = "mission_logs"

    id = Column(String(64), primary_key=True)
    relay_id = Column(String(64), ForeignKey("relays.id"), nullable=True)
    mission_id = Column(String(64), ForeignKey("missions.id"), nullable=True)
    channel = Column(String(64), nullable=False)
    payload = Column(Text, nullable=False)
    created_at = Column(DateTime, default=_now, nullable=False)

    relay = relationship("Relay", back_populates="logs")

    def set_payload(self, data: Dict[str, Any]) -> None:
        self.payload = json.dumps(data, ensure_ascii=False)

    def get_payload(self) -> Dict[str, Any]:
        try:
            return json.loads(self.payload)
        except Exception:
            return {"raw": self.payload}


class Blueprint(Base):
    __tablename__ = "blueprints"

    id = Column(String(64), primary_key=True)
    owner_id = Column(String(64), ForeignKey("users.id"), nullable=False)
    slug = Column(String(128), unique=True, nullable=False)
    meta = Column(Text, nullable=True)
    unlock_hash = Column(String(128), nullable=False)
    created_at = Column(DateTime, default=_now, nullable=False)


class PulseJob(Base):
    __tablename__ = "pulse_jobs"

    id = Column(String(64), primary_key=True)
    relay_id = Column(String(64), ForeignKey("relays.id"), nullable=False)
    task = Column(String(64), nullable=False)
    topic = Column(String(128), nullable=False)
    params = Column(Text, nullable=False)
    status = Column(String(32), default="queued", nullable=False)
    result = Column(Text, nullable=True)
    privileged = Column(Boolean, default=False, nullable=False)
    created_at = Column(DateTime, default=_now, nullable=False)
    updated_at = Column(DateTime, default=_now, nullable=False)

    relay = relationship("Relay", back_populates="jobs")

    def set_params(self, data: Dict[str, Any]) -> None:
        self.params = json.dumps(data, ensure_ascii=False)

    def get_params(self) -> Dict[str, Any]:
        try:
            return json.loads(self.params)
        except Exception:
            return {}

    def set_result(self, data: Optional[Dict[str, Any]]) -> None:
        if data is None:
            self.result = None
        else:
            self.result = json.dumps(data, ensure_ascii=False)

    def get_result(self) -> Optional[Dict[str, Any]]:
        if not self.result:
            return None
        try:
            return json.loads(self.result)
        except Exception:
            return {"raw": self.result}


class SupportTicket(Base):
    __tablename__ = "support_tickets"

    id = Column(String(64), primary_key=True)
    author_id = Column(String(64), ForeignKey("users.id"), nullable=False)
    status = Column(String(32), default="open", nullable=False)
    staging_path = Column(String(256), nullable=True)
    created_at = Column(DateTime, default=_now, nullable=False)


class DiagnosticExport(Base):
    __tablename__ = "diagnostic_exports"

    id = Column(String(64), primary_key=True)
    scope = Column(String(64), nullable=False)
    target = Column(String(128), nullable=False)
    file_path = Column(String(256), nullable=False)
    created_at = Column(DateTime, default=_now, nullable=False)
