from __future__ import annotations

import threading
import time
from datetime import datetime
from typing import Callable, Optional

import requests
from sqlalchemy.orm import Session

from ..config import get_settings
from ..database import SessionLocal
from ..models import MissionLog, PulseJob
from ..utils import generate_id

settings = get_settings()


class PulseBus:
    """Extremely small task queue with a single worker thread."""

    def __init__(self, session_factory: Callable[[], Session] = SessionLocal) -> None:
        self._session_factory = session_factory
        self._thread: Optional[threading.Thread] = None
        self._running = threading.Event()

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._running.set()
        self._thread = threading.Thread(target=self._run, name="PulseBusWorker", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._running.clear()
        if self._thread:
            self._thread.join(timeout=2)

    def _run(self) -> None:
        while self._running.is_set():
            session: Session = self._session_factory()
            try:
                job = (
                    session.query(PulseJob)
                    .filter(PulseJob.status == "queued")
                    .order_by(PulseJob.created_at)
                    .first()
                )
                if not job:
                    session.close()
                    time.sleep(settings.pulse_worker_interval)
                    continue
                job.status = "running"
                session.commit()

                try:
                    result = self._execute_job(session, job)
                    job.status = "completed"
                    job.set_result(result)
                    job.updated_at = datetime.utcnow()
                except Exception as exc:  # noqa: BLE001
                    job.status = "failed"
                    job.set_result({"error": str(exc)})
                    job.updated_at = datetime.utcnow()
                finally:
                    session.commit()
            finally:
                session.close()
                try:
                    self._session_factory.remove()  # type: ignore[attr-defined]
                except AttributeError:
                    pass

    def _execute_job(self, session: Session, job: PulseJob) -> dict:
        topic = job.topic
        params = job.get_params()
        if topic == "telemetry.collect":
            telemetry = {
                "status": "ok",
                "relay_id": job.relay_id,
                "collected": True,
                "metrics": params.get("metrics", ["battery", "temperature"]),
            }
            self._write_log(session, job, "telemetry", telemetry)
            return telemetry
        if topic == "maintenance.vault.snapshot":
            response = requests.get(
                "http://127.0.0.1:6070/admin/vault/snapshot",
                headers={"Authorization": f"Bearer {settings.maintenance_token}"},
                timeout=3,
            )
            response.raise_for_status()
            data = response.json()
            self._write_log(session, job, "maintenance", data)
            return data
        # Unknown topic
        info = {"status": "skipped", "topic": topic}
        self._write_log(session, job, "pulse", info)
        return info

    def _write_log(self, session: Session, job: PulseJob, channel: str, data: dict) -> None:
        log = MissionLog(id=generate_id(), relay_id=job.relay_id, channel=channel)
        log.set_payload(data)
        session.add(log)
        session.flush()
