"""API route registration."""

from fastapi import APIRouter

from . import diagnostics, missions, pulsebus, relays, support, users

api_router = APIRouter()

api_router.include_router(users.router, tags=["users"])
api_router.include_router(relays.router, tags=["relays"])
api_router.include_router(missions.router, tags=["missions"])
api_router.include_router(support.router, tags=["support"])
api_router.include_router(diagnostics.router, tags=["diagnostics"])
api_router.include_router(pulsebus.router, tags=["pulsebus"])

__all__ = ["api_router"]
