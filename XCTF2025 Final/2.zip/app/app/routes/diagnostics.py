from __future__ import annotations

import io
import json
import tarfile
from pathlib import Path

import requests
from fastapi import APIRouter, Depends, Header, HTTPException, status
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from ..auth import get_current_user
from ..config import get_settings
from ..database import get_db
from ..models import DiagnosticExport, SupportTicket
from ..utils import ensure_dir, generate_id

router = APIRouter()
settings = get_settings()


@router.get("/diagnostics/bundle")
def diagnostics_bundle(
    ticket: str,
    user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    if not ticket:
        raise HTTPException(status_code=400, detail="ticket required")

    record = (
        db.query(SupportTicket)
        .filter(SupportTicket.id == ticket, SupportTicket.author_id == user.id)
        .first()
    )
    if not record or not record.staging_path:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="ticket not ready")

    staging_root = Path(record.staging_path)
    if not staging_root.exists():
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="staging missing")

    manifest_path = staging_root / "manifest.json"
    if not manifest_path.exists():
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="manifest missing")

    try:
        manifest = json.loads(manifest_path.read_text())
    except ValueError as exc:  # noqa: BLE001
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="invalid manifest") from exc

    includes = manifest.get("includes")
    if not isinstance(includes, list) or not includes:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="manifest empty")

    buf = io.BytesIO()
    with tarfile.open(mode="w", fileobj=buf, dereference=True) as archive:
        for entry in includes:
            if not isinstance(entry, str):
                continue
            entry_name = entry.strip()
            if not entry_name or entry_name.startswith("/"):
                continue
            if ".." in Path(entry_name).parts:
                continue
            candidate = staging_root / entry_name
            if not candidate.exists():
                continue
            ensure_dir(candidate.parent)
            archive.add(candidate, arcname=entry_name)

    buf.seek(0)

    export = DiagnosticExport(
        id=generate_id(),
        scope="support-ticket",
        target=ticket,
        file_path=str(staging_root),
    )
    db.add(export)
    db.commit()

    headers = {"Content-Disposition": f"attachment; filename=diagnostics-{ticket}.tar"}
    return StreamingResponse(buf, media_type="application/x-tar", headers=headers)


@router.get("/admin/vault/snapshot")
def admin_vault_snapshot(authorization: str = Header(None)) -> dict:
    if not authorization:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="authorization required")
    try:
        resp = requests.get(
            "http://127.0.0.1:6070/admin/vault/snapshot",
            headers={"Authorization": authorization},
            timeout=3,
        )
    except requests.RequestException as exc:  # noqa: BLK001
        raise HTTPException(status_code=502, detail="vault upstream unreachable") from exc

    if resp.status_code == 200:
        return resp.json()

    detail: str
    try:
        detail = resp.json().get("detail", "vault upstream error")
    except ValueError:
        detail = "vault upstream error"
    raise HTTPException(status_code=resp.status_code, detail=detail)
