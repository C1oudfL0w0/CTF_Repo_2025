from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from .. import schemas
from ..auth import get_current_user
from ..database import get_db
from ..models import Mission
from ..utils import generate_id

router = APIRouter(prefix="/api/missions")


@router.post("", response_model=schemas.MissionResponse)
def create_mission(
    payload: schemas.MissionCreateRequest,
    user=Depends(get_current_user),
    db: Session = Depends(get_db),
) -> schemas.MissionResponse:
    mission = Mission(
        id=generate_id(),
        creator_id=user.id,
        title=payload.title,
        telemetry_url=payload.telemetry_url,
        status="active",
    )
    db.add(mission)
    db.commit()
    db.refresh(mission)
    return schemas.MissionResponse(
        id=mission.id,
        title=mission.title,
        status=mission.status,
        created_at=mission.created_at,
    )
