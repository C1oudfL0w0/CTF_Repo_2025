from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy.orm import Session

from .. import schemas
from ..auth import get_current_user
from ..database import get_db
from ..models import PulseJob, Relay
from ..utils import generate_id

router = APIRouter(prefix="/api/pulsebus")

TASK_TEMPLATES = {
    "telemetry.collect": {
        "topic": "telemetry.collect",
        "privileged": False,
        "params": {"metrics": ["battery", "temperature"]},
    }
}


@router.post("/relays/{relay_id}/schedule")
def schedule_job(
    relay_id: str,
    payload: schemas.PulseScheduleRequest,
    request: Request,
    user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    relay = db.query(Relay).filter(Relay.id == relay_id, Relay.owner_id == user.id).first()
    if not relay:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="relay not found")

    template = TASK_TEMPLATES.get(payload.task)
    if not template:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="unknown task")

    job_body = {**template, **payload.dict(exclude_unset=True)}

    job = PulseJob(
        id=generate_id(),
        relay_id=relay.id,
        task=payload.task,
        topic=job_body.get("topic", template["topic"]),
        privileged=job_body.get("privileged", template.get("privileged", False)),
    )
    job.set_params(job_body.get("params", {}))

    db.add(job)
    db.commit()

    pulsebus = request.app.state.pulsebus
    if pulsebus:
        pulsebus.start()

    return {"job_id": job.id, "topic": job.topic}
