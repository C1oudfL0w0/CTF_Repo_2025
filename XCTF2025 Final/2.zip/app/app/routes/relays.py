from __future__ import annotations

import json
from datetime import datetime, timedelta

import requests
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from .. import schemas
from ..auth import get_current_user
from ..crypto import encrypt_ticket, perform_handshake
from ..database import get_db
from ..models import MissionLog, Relay, RelayToken
from ..utils import b64decode, b64encode, generate_id

router = APIRouter(prefix="/api/relays")


@router.post("", response_model=schemas.RelayResponse)
def create_relay(
    payload: schemas.RelayCreateRequest,
    user=Depends(get_current_user),
    db: Session = Depends(get_db),
) -> schemas.RelayResponse:
    relay = Relay(id=generate_id(), owner_id=user.id, name=payload.name)
    db.add(relay)
    db.commit()
    db.refresh(relay)
    return schemas.RelayResponse(id=relay.id, name=relay.name, created_at=relay.created_at)


@router.post("/bootstrap", response_model=schemas.RelayBootstrapResponse)
def relay_bootstrap(
    payload: schemas.RelayBootstrapRequest,
    user=Depends(get_current_user),
    db: Session = Depends(get_db),
) -> schemas.RelayBootstrapResponse:
    relay = db.query(Relay).filter(Relay.id == payload.relay_id).first()
    if not relay or relay.owner_id != user.id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="relay not found")

    try:
        hs = perform_handshake(payload.mode, payload.client_public, payload.client_seed)
    except ValueError as exc:  # noqa: BLE001
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc

    access_token = f"NL-VAULT-{generate_id()}"
    ticket = {
        "relay_id": relay.id,
        "scope": "vault.read",
        "access_token": access_token,
        "audience": "internal-vault",
        "expires_at": (datetime.utcnow() + timedelta(minutes=10)).isoformat() + "Z",
    }
    aad = f"relay:{relay.id}".encode()
    payload_bytes = json.dumps(ticket, ensure_ascii=False).encode()
    nonce_b64, aad_b64, wrapped_b64 = encrypt_ticket(hs.session_key, aad, payload_bytes)

    token_record = RelayToken(
        id=generate_id(),
        relay_id=relay.id,
        mode=payload.mode,
        access_token=access_token,
        ticket_encrypted=b64decode(wrapped_b64),
        aad=aad_b64,
        nonce=nonce_b64,
    )
    db.add(token_record)
    db.commit()
    return schemas.RelayBootstrapResponse(
        relay_id=relay.id,
        server_public=b64encode(hs.server_public_bytes),
        aad=aad_b64,
        nonce=nonce_b64,
        wrapped_ticket=wrapped_b64,
    )


@router.get("/{relay_id}/logs", response_model=schemas.MissionLogList)
def relay_logs(
    relay_id: str,
    user=Depends(get_current_user),
    db: Session = Depends(get_db),
) -> schemas.MissionLogList:
    relay = db.query(Relay).filter(Relay.id == relay_id, Relay.owner_id == user.id).first()
    if not relay:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="relay not found")
    logs = (
        db.query(MissionLog)
        .filter(MissionLog.relay_id == relay_id)
        .order_by(MissionLog.created_at.desc())
        .limit(20)
        .all()
    )
    entries = [
        schemas.MissionLogEntry(
            id=log.id,
            channel=log.channel,
            payload=log.get_payload(),
            created_at=log.created_at,
        )
        for log in logs
    ]
    return schemas.MissionLogList(relay_id=relay_id, logs=list(reversed(entries)))


@router.get("/{relay_id}/vault")
def relay_vault_snapshot(
    relay_id: str,
    access_token: str,
    user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    relay = db.query(Relay).filter(Relay.id == relay_id, Relay.owner_id == user.id).first()
    if not relay:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="relay not found")

    token_record = (
        db.query(RelayToken)
        .filter(RelayToken.relay_id == relay_id, RelayToken.access_token == access_token)
        .order_by(RelayToken.created_at.desc())
        .first()
    )
    if not token_record:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="invalid token")

    resp = requests.get(
        "http://127.0.0.1:6070/admin/vault/snapshot",
        headers={"Authorization": f"Bearer {access_token}"},
        timeout=3,
    )
    if resp.status_code != 200:
        raise HTTPException(status_code=502, detail="vault unavailable")
    data = resp.json()
    return {
        "status": data.get("status"),
        "mode": data.get("mode"),
        "detail": "vault status available to relay owner",
    }
