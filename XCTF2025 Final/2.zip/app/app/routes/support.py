from __future__ import annotations

import io
import os
import shutil
import tarfile
from pathlib import Path

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile, status
from sqlalchemy.orm import Session

from .. import schemas
from ..auth import get_current_user
from ..config import get_settings
from ..database import get_db
from ..models import SupportTicket
from ..utils import ensure_dir, generate_id

router = APIRouter(prefix="/api/support")
settings = get_settings()


@router.post("/tickets", response_model=schemas.SupportTicketResponse)
def create_support_ticket(
    user=Depends(get_current_user),
    db: Session = Depends(get_db),
) -> schemas.SupportTicketResponse:
    ticket = SupportTicket(id=generate_id(), author_id=user.id)
    db.add(ticket)
    db.commit()
    db.refresh(ticket)
    return schemas.SupportTicketResponse(id=ticket.id, status=ticket.status, created_at=ticket.created_at)


@router.post("/tickets/{ticket_id}/upload", response_model=schemas.SupportUploadResponse)
async def upload_diagnostic_package(
    ticket_id: str,
    archive: UploadFile = File(...),
    user=Depends(get_current_user),
    db: Session = Depends(get_db),
) -> schemas.SupportUploadResponse:
    ticket = (
        db.query(SupportTicket)
        .filter(SupportTicket.id == ticket_id, SupportTicket.author_id == user.id)
        .first()
    )
    if not ticket:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="ticket not found")

    if archive.content_type not in {"application/x-tar", "application/gzip", "application/octet-stream"}:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="invalid archive type")

    raw = await archive.read()
    if not raw:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="empty archive")

    staging_root = settings.storage_root / "data" / "diagnostics" / ticket.id
    if staging_root.exists():
        shutil.rmtree(staging_root)
    ensure_dir(staging_root)

    try:
        _extract_archive(raw, staging_root)
    except tarfile.ReadError as exc:  # noqa: BLE001
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="malformed archive") from exc

    ticket.staging_path = str(staging_root)
    db.commit()

    return schemas.SupportUploadResponse(status="ok", message="diagnostic package processed")


def _extract_archive(payload: bytes, staging_root: Path) -> None:
    ensure_dir(staging_root)
    with tarfile.open(fileobj=io.BytesIO(payload), mode="r:*") as archive:
        for member in archive.getmembers():
            member_path = (staging_root / member.name).resolve()
            _assert_within(staging_root.resolve(), member_path)

            if member.isdir():
                ensure_dir(member_path)
                continue

            ensure_dir(member_path.parent)

            if member.issym():
                if member_path.exists() or member_path.is_symlink():
                    member_path.unlink()
                os.symlink(member.linkname, member_path)
            elif member.isfile():
                extracted = archive.extractfile(member)
                if extracted is None:
                    continue
                with open(member_path, "wb") as handle:
                    shutil.copyfileobj(extracted, handle)


def _assert_within(base: Path, target: Path) -> None:
    try:
        target.relative_to(base)
    except ValueError as exc:  # noqa: BLE001
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="invalid member path") from exc


__all__ = ["router"]
