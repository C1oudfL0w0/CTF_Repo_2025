from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from .. import schemas
from ..auth import create_session, hash_password, verify_password
from ..database import get_db
from ..models import Session as SessionModel
from ..models import User
from ..utils import generate_id

router = APIRouter(prefix="/api/users")


@router.post("/register", response_model=schemas.AuthTokenResponse)
def register(payload: schemas.UserRegisterRequest, db: Session = Depends(get_db)) -> schemas.AuthTokenResponse:
    existing = db.query(User).filter(User.username == payload.username).first()
    if existing:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="username taken")
    user = User(id=generate_id(), username=payload.username, password_hash=hash_password(payload.password))
    db.add(user)
    db.commit()
    db.refresh(user)
    session = create_session(db, user)
    return schemas.AuthTokenResponse(token=session.token)


@router.post("/login", response_model=schemas.AuthTokenResponse)
def login(payload: schemas.UserLoginRequest, db: Session = Depends(get_db)) -> schemas.AuthTokenResponse:
    user = db.query(User).filter(User.username == payload.username).first()
    if not user or not verify_password(payload.password, user.password_hash):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="invalid credentials")
    session = create_session(db, user)
    return schemas.AuthTokenResponse(token=session.token)


@router.post("/logout")
def logout(authorization: str, db: Session = Depends(get_db)) -> dict:
    scheme, _, token = authorization.partition(" ")
    if scheme.lower() != "bearer" or not token:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="invalid header")
    deleted = db.query(SessionModel).filter(SessionModel.token == token).delete()
    db.commit()
    if not deleted:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="session not found")
    return {"detail": "ok"}
