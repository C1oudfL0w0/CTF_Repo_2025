from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field, constr


class UserRegisterRequest(BaseModel):
    username: constr(min_length=3, max_length=48)
    password: constr(min_length=6, max_length=128)


class UserLoginRequest(BaseModel):
    username: constr(min_length=3, max_length=48)
    password: constr(min_length=6, max_length=128)


class AuthTokenResponse(BaseModel):
    token: str


class RelayCreateRequest(BaseModel):
    name: constr(min_length=3, max_length=120)


class RelayResponse(BaseModel):
    id: str
    name: str
    created_at: datetime


class MissionCreateRequest(BaseModel):
    title: constr(min_length=3, max_length=120)
    telemetry_url: Optional[str] = None


class MissionResponse(BaseModel):
    id: str
    title: str
    status: str
    created_at: datetime


class RelayBootstrapRequest(BaseModel):
    mode: constr(strip_whitespace=True)
    relay_id: str
    client_public: Optional[str] = None
    client_seed: Optional[str] = None


class RelayBootstrapResponse(BaseModel):
    relay_id: str
    server_public: str
    aad: str
    nonce: str
    wrapped_ticket: str



class PulseScheduleRequest(BaseModel):
    task: constr(min_length=3, max_length=64)
    topic: Optional[str] = None
    params: Dict[str, Any] = Field(default_factory=dict)


class MissionLogEntry(BaseModel):
    id: str
    channel: str
    payload: Dict[str, Any]
    created_at: datetime


class MissionLogList(BaseModel):
    relay_id: str
    logs: List[MissionLogEntry]


class SupportTicketResponse(BaseModel):
    id: str
    status: str
    created_at: datetime


class SupportUploadResponse(BaseModel):
    status: str
    message: str
