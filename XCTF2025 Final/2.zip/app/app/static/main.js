(() => {
  const state = {
    baseUrl: window.location.origin,
    token: null,
    relayId: null,
    lastTicket: null,
  };

  const els = {
    accountStatus: document.getElementById("account-status"),
    missionStatus: document.getElementById("mission-status"),
    relayStatus: document.getElementById("relay-status"),
    handshakeOutput: document.getElementById("handshake-output"),
    queueStatus: document.getElementById("queue-status"),
    diagnosticsStatus: document.getElementById("diagnostics-status"),
    logsOutput: document.getElementById("logs-output"),
  };

  const overview = {
    account: document.getElementById("overview-account"),
    mission: document.getElementById("overview-mission"),
    relay: document.getElementById("overview-relay"),
    queue: document.getElementById("overview-queue"),
  };

  const forms = {
    register: document.getElementById("form-register"),
    login: document.getElementById("form-login"),
    mission: document.getElementById("form-mission"),
    relay: document.getElementById("form-relay"),
    handshake: document.getElementById("form-handshake"),
    queue: document.getElementById("form-queue"),
    diagnostics: document.getElementById("form-diagnostics"),
  };

  const refreshLogsBtn = document.getElementById("btn-refresh-logs");

  function setStatus(element, html) {
    if (element) {
      element.innerHTML = html;
    }
  }

  function formatToken(token) {
    if (!token) return "";
    if (token.length <= 12) {
      return token;
    }
    return `${token.slice(0, 10)}…${token.slice(-6)}`;
  }

  async function apiFetch(path, options = {}) {
    const headers = new Headers(options.headers || {});
    const body = options.body;
    const isFormData = body instanceof FormData;

    if (!isFormData && body && typeof body === "object" && !(body instanceof Blob)) {
      headers.set("Content-Type", "application/json");
    }
    if (!headers.has("Authorization") && state.token) {
      headers.set("Authorization", `Bearer ${state.token}`);
    }

    const response = await fetch(`${state.baseUrl}${path}`, {
      method: options.method || "GET",
      body:
        !isFormData && body && typeof body === "object" && !(body instanceof Blob)
          ? JSON.stringify(body)
          : body,
      headers,
    });

    if (!response.ok) {
      const text = await response.text();
      let message = `${response.status}`;
      if (text) {
        try {
          const data = JSON.parse(text);
          if (data.detail) {
            message += `: ${data.detail}`;
          } else {
            message += `: ${text}`;
          }
        } catch (err) {
          message += `: ${text}`;
        }
      }
      throw new Error(message);
    }

    if (options.expectJson === false) {
      return response;
    }
    const contentType = response.headers.get("content-type") || "";
    if (contentType.includes("application/json")) {
      return response.json();
    }
    return response;
  }

  function requireAuth(messageTarget) {
    if (state.token) return true;
    setStatus(
      messageTarget || els.accountStatus,
      `<div class="danger">当前操作需要登录。请先完成注册或登录。</div>`
    );
    return false;
  }

  function requireRelay(messageTarget) {
    if (state.relayId) return true;
    setStatus(
      messageTarget || els.relayStatus,
      `<div>当前中继：<strong id="relay-label">尚未创建</strong></div><div class="muted">请先创建中继，再执行该操作。</div>`
    );
    return false;
  }

  if (forms.register) {
    forms.register.addEventListener("submit", async (event) => {
      event.preventDefault();
      const form = new FormData(forms.register);
      try {
        const resp = await apiFetch("/api/users/register", {
          method: "POST",
          body: Object.fromEntries(form.entries()),
        });
        state.token = resp.token;
        setStatus(
          els.accountStatus,
          `<div>当前状态：<strong>已登录</strong></div><div class="muted">Bearer ${formatToken(
            state.token
          )}…（点击按钮即可调用 API）</div>`
        );
        if (overview.account) {
          overview.account.textContent = "已登录";
        }
      } catch (error) {
        setStatus(els.accountStatus, `<div class="danger">注册失败：${error.message}</div>`);
        if (overview.account) {
          overview.account.textContent = "认证失败";
        }
      }
    });
  }

  if (forms.login) {
    forms.login.addEventListener("submit", async (event) => {
      event.preventDefault();
      const form = new FormData(forms.login);
      try {
        const resp = await apiFetch("/api/users/login", {
          method: "POST",
          body: Object.fromEntries(form.entries()),
        });
        state.token = resp.token;
        setStatus(
          els.accountStatus,
          `<div>当前状态：<strong>已登录</strong></div><div class="muted">令牌刷新成功，Bearer ${formatToken(
            state.token
          )}…</div>`
        );
        if (overview.account) {
          overview.account.textContent = "已登录";
        }
      } catch (error) {
        setStatus(els.accountStatus, `<div class="danger">登录失败：${error.message}</div>`);
        if (overview.account) {
          overview.account.textContent = "认证失败";
        }
      }
    });
  }

  if (forms.mission) {
    forms.mission.addEventListener("submit", async (event) => {
      event.preventDefault();
      if (!requireAuth(els.accountStatus)) {
        return;
      }
      const form = new FormData(forms.mission);
      const payload = {
        title: form.get("title"),
        telemetry_url: form.get("telemetry_url"),
      };
      try {
        const mission = await apiFetch("/api/missions", {
          method: "POST",
          body: payload,
        });
        setStatus(
          els.missionStatus,
          `<div>任务已创建：<strong>${mission.title}</strong></div><div class="muted">ID：${mission.id}</div>`
        );
        if (overview.mission) {
          overview.mission.textContent = `${mission.title}`;
        }
      } catch (error) {
        setStatus(els.missionStatus, `<div class="danger">创建失败：${error.message}</div>`);
        if (overview.mission) {
          overview.mission.textContent = "创建失败";
        }
      }
    });
  }

  if (forms.relay) {
    forms.relay.addEventListener("submit", async (event) => {
      event.preventDefault();
      if (!requireAuth(els.accountStatus)) {
        return;
      }
      const form = new FormData(forms.relay);
      try {
        const relay = await apiFetch("/api/relays", {
          method: "POST",
          body: Object.fromEntries(form.entries()),
        });
        state.relayId = relay.id;
        setStatus(
          els.relayStatus,
          `<div>当前中继：<strong>${relay.name}</strong></div><div class="muted">ID：${relay.id}</div>`
        );
        const label = document.getElementById("relay-label");
        if (label) {
          label.textContent = `${relay.name} (${relay.id.slice(0, 6)}…)`;
        }
        if (overview.relay) {
          overview.relay.textContent = relay.name;
        }
      } catch (error) {
        setStatus(els.relayStatus, `<div class="danger">创建失败：${error.message}</div>`);
        if (overview.relay) {
          overview.relay.textContent = "创建失败";
        }
      }
    });
  }

  if (forms.handshake) {
    forms.handshake.addEventListener("submit", async (event) => {
      event.preventDefault();
      if (!requireAuth(els.accountStatus) || !requireRelay(els.relayStatus)) {
        return;
      }
      const form = new FormData(forms.handshake);
      const mode = form.get("mode") || "modern";
      const clientSeed = (form.get("client_seed") || "").trim();
      const clientPublic = (form.get("client_public") || "").trim();

      if (mode === "modern" && !clientPublic) {
        setStatus(els.handshakeOutput, `<span class="danger">modern 模式需要填写 Client Public。</span>`);
        return;
      }
      if (mode === "legacy" && !clientPublic && !clientSeed) {
        setStatus(
          els.handshakeOutput,
          `<span class="danger">legacy 模式需提供 Client Seed 或 Client Public。</span>`
        );
        return;
      }

      const payload = {
        relay_id: state.relayId,
        mode,
      };
      if (clientPublic) {
        payload.client_public = clientPublic;
      }
      if (clientSeed) {
        payload.client_seed = clientSeed;
      }

      try {
        const data = await apiFetch("/api/relays/bootstrap", {
          method: "POST",
          body: payload,
        });
        state.lastTicket = data;
        const summary = [
          `<div>握手成功，服务端公钥已返回。</div>`,
          `<pre>${JSON.stringify(
            {
              server_public: data.server_public,
              aad: data.aad,
              nonce: data.nonce,
              wrapped_ticket: data.wrapped_ticket,
            },
            null,
            2
          )}</pre>`,
          `<div class="muted">请在现场设备上使用返回数据解包票据并完成接入。</div>`,
        ].join("");
        setStatus(els.handshakeOutput, summary);
        if (overview.relay && state.relayId) {
          overview.relay.textContent = `已握手 · ${state.relayId.slice(0, 6)}…`;
        }
      } catch (error) {
        setStatus(els.handshakeOutput, `<span class="danger">握手失败：${error.message}</span>`);
      }
    });
  }

  if (forms.queue) {
    forms.queue.addEventListener("submit", async (event) => {
      event.preventDefault();
      if (!requireAuth(els.accountStatus) || !requireRelay(els.relayStatus)) {
        return;
      }
      const form = new FormData(forms.queue);
      const task = (form.get("task") || "").trim();
      const topic = (form.get("topic") || "").trim();
      const paramsRaw = (form.get("params") || "").trim();

      if (!task) {
        setStatus(els.queueStatus, `<div class="danger">任务类型不能为空。</div>`);
        return;
      }

      let params;
      if (paramsRaw) {
        try {
          params = JSON.parse(paramsRaw);
        } catch (error) {
          setStatus(els.queueStatus, `<div class="danger">参数 JSON 无法解析：${error.message}</div>`);
          return;
        }
      } else {
        params = {};
      }
      if (state.relayId && !params.relay_id) {
        params.relay_id = state.relayId;
      }

      const payload = {
        task,
        params,
      };
      if (topic) {
        payload.topic = topic;
      }

      try {
        const resp = await apiFetch(`/api/pulsebus/relays/${state.relayId}/schedule`, {
          method: "POST",
          body: payload,
        });
        setStatus(
          els.queueStatus,
          `<div>作业已提交：<strong>${resp.job_id}</strong></div><div class="muted">Topic：${resp.topic}</div>`
        );
        setTimeout(loadLogs, 1500);
        if (overview.queue) {
          overview.queue.textContent = `已提交 ${resp.job_id}`;
        }
      } catch (error) {
        setStatus(els.queueStatus, `<div class="danger">提交失败：${error.message}</div>`);
        if (overview.queue) {
          overview.queue.textContent = "提交失败";
        }
      }
    });
  }

  if (forms.diagnostics) {
    forms.diagnostics.addEventListener("submit", async (event) => {
      event.preventDefault();
      if (!requireAuth(els.accountStatus)) {
        return;
      }
      const form = new FormData(forms.diagnostics);
      const params = new URLSearchParams(Object.fromEntries(form.entries()));
      try {
        const response = await apiFetch(`/diagnostics/bundle?${params.toString()}`, {
          method: "GET",
          expectJson: false,
        });
        const blob = await response.blob();
        const url = URL.createObjectURL(blob);
        setStatus(
          els.diagnosticsStatus,
          `<div>导出已生成。</div><div><a class="tag" href="${url}" download="diagnostics.tar">下载 tar 包</a></div>`
        );
      } catch (error) {
        setStatus(els.diagnosticsStatus, `<div class="danger">导出失败：${error.message}</div>`);
      }
    });
  }

  async function loadLogs() {
    if (!state.relayId || !state.token) {
      if (els.logsOutput) {
        els.logsOutput.textContent = "尚未加载日志。";
      }
      return;
    }
    try {
      const data = await apiFetch(`/api/relays/${state.relayId}/logs`);
      if (!data.logs || data.logs.length === 0) {
        els.logsOutput.textContent = "暂无日志。";
        return;
      }
      const lines = data.logs
        .map(
          (entry) =>
            `[${entry.created_at}] (${entry.channel}) ${JSON.stringify(entry.payload, null, 0)}`
        )
        .join("\n\n");
      els.logsOutput.textContent = lines;
    } catch (error) {
      els.logsOutput.textContent = `获取失败：${error.message}`;
    }
  }

  if (refreshLogsBtn) {
    refreshLogsBtn.addEventListener("click", () => {
      loadLogs();
    });
  }

  loadLogs();
})();
