from __future__ import annotations

import base64
import json
import os
import secrets
from pathlib import Path
from typing import Any, Dict


def generate_id() -> str:
    return secrets.token_hex(16)


def b64encode(data: bytes) -> str:
    return base64.b64encode(data).decode("ascii")


def b64decode(data: str) -> bytes:
    return base64.b64decode(data.encode("ascii"))


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def atomic_write(path: Path, content: str) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(content)
    tmp.replace(path)


def json_dumps(data: Dict[str, Any]) -> str:
    return json.dumps(data, ensure_ascii=False, separators=(",", ":"))


def read_flag(flag_path: Path) -> str:
    if flag_path.exists():
        return flag_path.read_text().strip()
    return os.getenv("FLAG", "flag{development_flag}")
