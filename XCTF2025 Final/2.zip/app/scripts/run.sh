#!/usr/bin/env bash
set -euo pipefail

APP_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

export PYTHONPATH="$APP_ROOT"
export NSL_STORAGE_ROOT="${NSL_STORAGE_ROOT:-$APP_ROOT/storage}"
export NSL_DATABASE_URL="${NSL_DATABASE_URL:-sqlite:///${NSL_STORAGE_ROOT}/data.db}"

mkdir -p "$NSL_STORAGE_ROOT"

if [ -z "${NSL_MAINT_TOKEN:-}" ]; then
  NSL_MAINT_TOKEN=$(python3 - <<'PY'
import secrets
print(secrets.token_urlsafe(32))
PY
  )
  export NSL_MAINT_TOKEN
fi

SERVICE_USER=${NSL_SERVICE_USER:-nsl}

if ! id -u "$SERVICE_USER" >/dev/null 2>&1; then
  useradd -r -m -s /bin/bash "$SERVICE_USER"
fi

chown -R "$SERVICE_USER":"$SERVICE_USER" "$NSL_STORAGE_ROOT"

printf "%s" "$NSL_MAINT_TOKEN" > "$NSL_STORAGE_ROOT/maintenance_token"
chown root:root "$NSL_STORAGE_ROOT/maintenance_token" 2>/dev/null || true
chmod 640 "$NSL_STORAGE_ROOT/maintenance_token" 2>/dev/null || true

export PYTHONPATH NSL_STORAGE_ROOT NSL_DATABASE_URL NSL_MAINT_TOKEN

run_as_service_user() {
  su -s /bin/sh "$SERVICE_USER" -c "$1"
}

cleanup() {
  if [[ -n "${diag_pid:-}" ]]; then
    kill -TERM "$diag_pid" 2>/dev/null || true
  fi
  if [[ -n "${ssh_pid:-}" ]]; then
    kill -TERM "$ssh_pid" 2>/dev/null || true
  fi
}

trap cleanup EXIT INT TERM

mkdir -p /var/run/sshd
/usr/sbin/sshd -D &
ssh_pid=$!

run_as_service_user "PYTHONPATH='$PYTHONPATH' NSL_STORAGE_ROOT='$NSL_STORAGE_ROOT' NSL_DATABASE_URL='$NSL_DATABASE_URL' NSL_MAINT_TOKEN='$NSL_MAINT_TOKEN' uvicorn app.diagnostics_service:app --host 127.0.0.1 --port 6070" &
diag_pid=$!

run_as_service_user "PYTHONPATH='$PYTHONPATH' NSL_STORAGE_ROOT='$NSL_STORAGE_ROOT' NSL_DATABASE_URL='$NSL_DATABASE_URL' NSL_MAINT_TOKEN='$NSL_MAINT_TOKEN' uvicorn app.main:app --host 0.0.0.0 --port 8080 --reload"
