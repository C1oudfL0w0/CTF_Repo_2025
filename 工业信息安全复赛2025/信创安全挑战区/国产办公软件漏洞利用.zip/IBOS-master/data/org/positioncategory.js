var Ibos = Ibos || {}; Ibos.data = Ibos.data || {};
Ibos.data.positioncategory = {"f_1":{"id":"f_1","text":"\u9ed8\u8ba4\u5206\u7c7b","nocheck":true,"pid":"f_0"}};