<?php

/**
 * @Descripttion : FOXCMS 文件下载模块
 * @Author : FoxCMS Team
 * @Date : 2024/01/01 00:00
 * @version : V1.08
 * @copyright : ©2021-现在 贵州黔狐科技股份有限公司 版权所有
 * @LastEditTime : 2024/01/01 00:00
 */

namespace app\plus\controller;

use think\Request;
use think\Response;
use think\Session;

class Download
{
    private $allowedPaths = [
        'uploads' => 1,
        'static' => 1,
    ];

    /**
     * 文件下载功能
     *
     * GET /plus/download/file?name=avatar.jpg
     */
    public function file()
    {
        // 获取下载参数
        $name = request()->param('name', '');

        if (empty($name)) {
            $content =  "请指定要下载的文件";
            $type = "html";
            header("Content-type: text/html; charset=utf-8");
            return Response::create($content, $type, 0);
        }

        $filePath = 'uploads/' . $name;

        $fullPath = root_path()  . $filePath;


        if (file_exists($fullPath) && is_file($fullPath)) {
            return $this->downloadFile($fullPath, basename($fullPath));
        } else {
            $content =  "文件不存在: " . $fullPath;
            $type = "html";
            header("Content-type: text/html; charset=utf-8");
            return Response::create($content, $type, 0);
        }
    }

    /**
     * 下载文件方法
     */
    private function downloadFile($filePath, $fileName)
    {
        // 清除输出缓冲区
        if (ob_get_level()) {
            ob_end_clean();
        }

        // 设置响应头
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . $fileName . '"');
        header('Content-Length: ' . filesize($filePath));
        header('Cache-Control: private, no-cache, no-store, must-revalidate');
        header('Pragma: no-cache');
        header('Expires: 0');

        // 读取并输出文件
        readfile($filePath);
        exit;
    }

}