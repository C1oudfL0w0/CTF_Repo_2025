<?php
return [
	'type' => 'mysql',
	'hostname' => '127.0.0.1',
	'database' => 'foxcms7dfda1',
	'username' => 'fox',
	'password' => '123456',
	'hostport' => '3306',
	'charset' => 'utf8mb4',
	'prefix' => 'fox_',
];