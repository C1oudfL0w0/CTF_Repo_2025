<?php
//000000000060
 exit();?>
a:18:{s:2:"id";s:3:"int";s:6:"map_ak";s:6:"string";s:7:"company";s:6:"string";s:11:"company_tel";s:6:"string";s:5:"email";s:6:"string";s:7:"linkman";s:6:"string";s:5:"phone";s:6:"string";s:2:"qq";s:6:"string";s:12:"customer_url";s:6:"string";s:8:"qr_code1";s:6:"string";s:8:"qr_code2";s:6:"string";s:15:"contact_address";s:6:"string";s:11:"geolocation";s:6:"string";s:11:"create_time";s:8:"datetime";s:11:"update_time";s:8:"datetime";s:4:"lang";s:6:"string";s:3:"_pk";s:2:"id";s:8:"_autoinc";s:2:"id";}