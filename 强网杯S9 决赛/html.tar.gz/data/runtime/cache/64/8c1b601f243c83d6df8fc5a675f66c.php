<?php
//000000000060
 exit();?>
a:10:{s:2:"id";s:3:"int";s:9:"column_id";s:3:"int";s:6:"column";s:6:"string";s:11:"team_status";s:6:"string";s:7:"content";s:6:"string";s:4:"lang";s:6:"string";s:11:"create_time";s:8:"datetime";s:11:"update_time";s:8:"datetime";s:3:"_pk";s:2:"id";s:8:"_autoinc";s:2:"id";}