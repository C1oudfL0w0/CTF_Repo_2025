<?php
//000000000060
 exit();?>
a:9:{s:2:"id";s:3:"int";s:4:"name";s:6:"string";s:7:"is_used";s:3:"int";s:15:"search_group_id";s:3:"int";s:11:"create_time";s:8:"datetime";s:11:"update_time";s:8:"datetime";s:4:"sort";s:3:"int";s:3:"_pk";s:2:"id";s:8:"_autoinc";s:2:"id";}