<?php
//000000000060
 exit();?>
a:12:{s:2:"id";s:3:"int";s:4:"name";s:6:"string";s:4:"type";s:3:"int";s:4:"sort";s:3:"int";s:6:"remark";s:6:"string";s:6:"status";s:3:"int";s:3:"sid";s:6:"string";s:4:"lang";s:6:"string";s:11:"create_time";s:8:"datetime";s:11:"update_time";s:8:"datetime";s:3:"_pk";s:2:"id";s:8:"_autoinc";s:2:"id";}