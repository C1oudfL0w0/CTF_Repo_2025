<?php
//000000000060
 exit();?>
a:7:{s:2:"id";s:3:"int";s:2:"ip";s:6:"string";s:11:"description";s:6:"string";s:11:"create_time";s:8:"datetime";s:11:"update_time";s:8:"datetime";s:3:"_pk";s:2:"id";s:8:"_autoinc";s:2:"id";}