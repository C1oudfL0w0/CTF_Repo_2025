<?php
//000000000060
 exit();?>
a:11:{s:2:"id";s:3:"int";s:10:"page_title";s:6:"string";s:2:"ip";s:6:"string";s:7:"browser";s:6:"string";s:9:"from_page";s:6:"string";s:11:"source_site";s:6:"string";s:12:"browser_type";s:6:"string";s:11:"create_time";s:8:"datetime";s:6:"cookie";s:6:"string";s:3:"_pk";s:2:"id";s:8:"_autoinc";s:2:"id";}