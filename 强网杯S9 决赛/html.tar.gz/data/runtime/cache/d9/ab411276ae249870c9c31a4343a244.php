<?php
//000000000060
 exit();?>
a:17:{s:2:"id";s:3:"int";s:5:"group";s:6:"string";s:4:"name";s:6:"string";s:5:"title";s:6:"string";s:5:"dtype";s:6:"string";s:6:"define";s:6:"string";s:9:"maxlength";s:3:"int";s:7:"dfvalue";s:6:"string";s:6:"remark";s:6:"string";s:9:"is_system";s:3:"int";s:10:"sort_order";s:3:"int";s:6:"status";s:3:"int";s:11:"create_time";s:8:"datetime";s:11:"update_time";s:8:"datetime";s:8:"call_tag";s:6:"string";s:3:"_pk";s:2:"id";s:8:"_autoinc";s:2:"id";}