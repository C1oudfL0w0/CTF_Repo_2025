<?php
//000000000060
 exit();?>
a:14:{s:2:"id";s:3:"int";s:7:"storage";s:3:"int";s:3:"app";s:3:"int";s:7:"user_id";s:3:"int";s:9:"file_name";s:6:"string";s:9:"file_size";s:3:"int";s:9:"extension";s:6:"string";s:3:"url";s:6:"string";s:11:"create_time";s:8:"datetime";s:9:"file_type";s:6:"string";s:15:"file_group_type";s:6:"string";s:4:"size";s:6:"string";s:3:"_pk";s:2:"id";s:8:"_autoinc";s:2:"id";}