<?php if (!defined("RUNTIME")) exit();  /*a:5:{s:42:"/var/www/html/templates/foxui01/index.html";i:1763639525;s:45:"/var/www/html/templates/foxui01///header.html";i:1763639525;s:42:"/var/www/html/templates/foxui01///nav.html";i:1763639525;s:44:"/var/www/html/templates/foxui01///fixed.html";i:1763639525;s:45:"/var/www/html/templates/foxui01///footer.html";i:1763639525;}*/ ?>
<!--
 * @Descripttion : FOXCMS是一款高效的PHP多端跨平台内容管理系统
 * @Author       : FoxCMS Team
 * @Date         : 2023-01-10 09:33:37
 * @version      : V1.08
 * @copyright    : ©2021-现在 贵州黔狐科技股份有限公司 版权所有
 * @LastEditTime : 2024-07-06 10:15:54
-->
<!DOCTYPE html>
<html lang="cn">
    <head>
        <meta charset="UTF-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<link href="<?php $param = ['field'=>'web_icon', 'add'=>$add];$tagBasic = new app\taglib\fox\TagBasic;$tagBasic->getList($param); ?>" rel="icon" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="/templates/skin/css/foxui-1.21.min.css" />
<link rel="stylesheet" href="/templates/skin/css/animate.min.css" />
<link rel="stylesheet" href="/templates/skin/css/swiper.min.css" />
<link rel="stylesheet" href="/templates/skin/css/common.min.css" />
<script src="/templates/skin/js/jquery-3.6.0.min.js"></script>
<script src="/templates/skin/js/swiper.min.js"></script>
<script src="/templates/skin/js/wow.min.js"></script>

        <title><?php $param = ['field'=>'title', 'add'=>$add];$tagBasic = new app\taglib\fox\TagBasic;$tagBasic->getList($param); ?></title>
        <meta name="keywords" content="<?php $param = ['field'=>'keyword', 'add'=>$add];$tagBasic = new app\taglib\fox\TagBasic;$tagBasic->getList($param); ?>" />
        <meta name="description" content="<?php $param = ['field'=>'description', 'add'=>$add];$tagBasic = new app\taglib\fox\TagBasic;$tagBasic->getList($param); ?>" />
    </head>
    <body>
        <!-- 顶部 -->
        <header class="foxui-border-bottom foxui-bg-white"><div class="foxcms-container foxcms-header-pc foxui-hidden-sm foxui-hidden-xs">
    <div class="foxcms-logo">
        <div class="logo">
            <img style="height: 28px" src="<?php $param = ['field'=>'web_logo', 'add'=>$add];$tagBasic = new app\taglib\fox\TagBasic;$tagBasic->getList($param); ?>" alt="" />
        </div>
        <p class="foxui-border foxui-radius-round foxui-color-regular foxui-hidden-md foxui-hidden-sm foxui-hidden-xs">基础版演示</p>
    </div>
    <div class="foxcms-nav">
        <div class="nav">
            <ul class="foxui-menu">
                <?php $field = ["currentstyle"=>'is-current']; ?>
                <li class="foxui-menu-item <?php echo $field['currentstyle']; ?>">
                    <a class="foxui-link" href="/">首页</a>
                </li>
                
                <?php $param = ['typeid'=>'', 'orderbyid'=>'sort', 'limit'=>'0,2', 'sid'=>''
        , 'typeidP'=>$field["id"],'calltype'=>'self','notypeid'=>'contain','orderby'=>'admin','sortorder'=>'asc'];$model = "column";$tagNav = new app\taglib\fox\TagNav;$__LIST__ = $tagNav->getList($param,'self','admin asc','0','999');$__LIST__ = columnList($__LIST__, -1); if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $index = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$field): $mod = ($index % 2 );++$index;?>
                <li class="foxui-menu-submenu <?php echo $field['currentstyle']; ?>">
                    <div class="foxui-menu-handle foxui-menu-icon">
                        <a class="foxui-link" href="<?php echo $field['link']; ?>"><?php echo $field['name']; ?></a>
                    </div>
                    <div class="foxui-menu-menu">
                        <div class="foxui-menu-slide foxcms-container">
                            <div class="nav-swiper nav-swiper-text">
                                <ul class="foxui-display-flex foxui-justify-content-center">
                                    <?php $param = ['typeid'=>'', 'orderbyid'=>'sort', 'limit'=>'', 'sid'=>''
        , 'typeidP'=>$field["id"],'calltype'=>'parent','notypeid'=>'self','orderby'=>'admin','sortorder'=>'asc'];$model = "column";$tagNav = new app\taglib\fox\TagNav;$__LIST__ = $tagNav->getList($param,'son','admin asc','0','999');$__LIST__ = columnList($__LIST__, -1); if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $index = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($index % 2 );++$index;?>
                                    <li>
                                        <a href="<?php echo $v['link']; ?>" class="swiper-content foxui-link"><?php echo $v['name']; ?></a>
                                    </li>
                                    <?php endforeach; endif; else: echo "" ;endif; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </li>
                <?php endforeach; endif; else: echo "" ;endif; $param = ['typeid'=>'3,4', 'orderbyid'=>'sort', 'limit'=>'', 'sid'=>''
        , 'typeidP'=>$field["id"],'calltype'=>'self','notypeid'=>'contain','orderby'=>'admin','sortorder'=>'asc'];$model = "column";$tagNav = new app\taglib\fox\TagNav;$__LIST__ = $tagNav->getList($param,'self','admin asc','0','999');$__LIST__ = columnList($__LIST__, -1); if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $index = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$field): $mod = ($index % 2 );++$index;?>
                <li class="foxui-menu-submenu <?php echo $field['currentstyle']; ?>">
                    <div class="foxui-menu-handle foxui-menu-icon">
                        <a class="foxui-link" href="<?php echo $field['link']; ?>"><?php echo $field['name']; ?></a>
                    </div>
                    <div class="foxui-menu-menu">
                        <div class="foxui-menu-slide foxcms-container">
                            <div class="swiper nav-swiper nav-swiper-image">
                                <div class="swiper-wrapper">
                                    <?php $tagArclist = new app\taglib\fox\TagArclist;$param = ['notypeid'=>'','apply'=>'nav','currentstyle'=>''
        ,'typeid'=>'', 'limit'=>'', 'columnModel'=>'', 'type'=>'son', 'sid'=>''
        ,  'typeidP'=>$field["id"],'calltype'=>'parent','addfields'=>'author,team_status','channel'=>''];$__LIST__ = $tagArclist->getList($param,'c','create_time desc','0','12');$__LIST__ = alterList($__LIST__,'', -1); if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $index = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($index % 2 );++$index;$model = $v["model"]; ?>
                                    <div class="swiper-slide">
                                        <a href="<?php echo $v['link']; ?>" class="swiper-content foxui-link">
                                            <div class="<?php if($field['id'] == 4): ?> case-img <?php else: ?> product-img <?php endif; ?>">
                                                <img src="<?php echo $v['img_url']; ?>" alt="" />
                                            </div>
                                            <p><?php echo $v['title']; ?></p>
                                        </a>
                                    </div>
                                    <?php endforeach; endif; else: echo "" ;endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
                <?php endforeach; endif; else: echo "" ;endif; $param = ['typeid'=>'5', 'orderbyid'=>'sort', 'limit'=>'', 'sid'=>''
        , 'typeidP'=>$field["id"],'calltype'=>'self','notypeid'=>'contain','orderby'=>'admin','sortorder'=>'asc'];$model = "column";$tagNav = new app\taglib\fox\TagNav;$__LIST__ = $tagNav->getList($param,'self','admin asc','0','999');$__LIST__ = columnList($__LIST__, -1); if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $index = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$field): $mod = ($index % 2 );++$index;?>
                <li class="foxui-menu-submenu <?php echo $field['currentstyle']; ?>">
                    <div class="foxui-menu-handle foxui-menu-icon">
                        <a class="foxui-link" href="<?php echo $field['link']; ?>"><?php echo $field['name']; ?></a>
                    </div>
                    <div class="foxui-menu-menu">
                        <div class="foxui-menu-slide foxcms-container">
                            <div class="nav-swiper nav-swiper-text">
                                <ul class="foxui-display-flex foxui-justify-content-center">
                                    <?php $param = ['typeid'=>'', 'orderbyid'=>'sort', 'limit'=>'', 'sid'=>''
        , 'typeidP'=>$field["id"],'calltype'=>'parent','notypeid'=>'self','orderby'=>'admin','sortorder'=>'asc'];$model = "column";$tagNav = new app\taglib\fox\TagNav;$__LIST__ = $tagNav->getList($param,'son','admin asc','0','999');$__LIST__ = columnList($__LIST__, -1); if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $index = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($index % 2 );++$index;?>
                                    <li>
                                        <a href="<?php echo $v['link']; ?>" class="swiper-content foxui-link"><?php echo $v['name']; ?></a>
                                    </li>
                                    <?php endforeach; endif; else: echo "" ;endif; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </li>
                <?php endforeach; endif; else: echo "" ;endif; $param = ['typeid'=>'6', 'orderbyid'=>'sort', 'limit'=>'', 'sid'=>''
        , 'typeidP'=>$field["id"],'calltype'=>'self','notypeid'=>'contain','orderby'=>'admin','sortorder'=>'asc'];$model = "column";$tagNav = new app\taglib\fox\TagNav;$__LIST__ = $tagNav->getList($param,'self','admin asc','0','999');$__LIST__ = columnList($__LIST__, -1); if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $index = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$field): $mod = ($index % 2 );++$index;?>
                <li class="foxui-menu-item <?php echo $field['currentstyle']; ?>">
                    <a class="foxui-link" href="<?php echo $field['link']; ?>"><?php echo $field['name']; ?></a>
                </li>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
        </div>
        <div class="phone foxui-hidden-sm foxui-hidden-xs">
            <div class="phone-inner">
                <i class="foxui-icon-dianhua-o foxui-margin-right-4 foxui-hidden-lg foxui-hidden-md"></i>
                <h3 class="foxui-hidden-lg foxui-hidden-md"><?php $param = ['field'=>'company_tel'];$tagContact = new app\taglib\fox\TagContact;$tagContact->getList($param); ?></h3>
                <i class="foxui-icon-sousuo-o search-icon"></i>
            </div>
        </div>
    </div>
    <div class="foxcms-search">
        <div class="search-head foxcms-container">
            <?php $param = ['typeid'=>'','model'=>''];$tagSearchform = new app\taglib\fox\TagSearchform;$__LIST__ = $tagSearchform->getList($param); if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $index = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$field): $mod = ($index % 2 );++$index;?>
            <form method="get" action="<?php echo $field['link']; ?>">
                <div class="foxui-input-group">
                    <div class="foxui-input-prefix">
                        <i class="foxui-icon-sousuo-o foxui-prefix-icon"></i>
                        <input name="fields" value="title" type="hidden" />
                        <input name="kwtype" value="1" type="hidden" />
                        <input name="keyword" placeholder="输入关键词" value="" />
                    </div>
                </div>
                <input type="submit" style="display: none" />
            </form>
            <?php endforeach; endif; else: echo "" ;endif; ?>
            <i class="foxui-icon-guanbi-o search-close"></i>
        </div>
        <div class="search-menu">
            <div class="foxcms-container">
                <div class="search-menu-inner">
                    <div class="title">大家都在搜</div>
                    <div class="list">
                        <?php $param = ['way'=>'1','param'=>'','showall'=>'0', 'row'=>'-1', 'pid'=>'-1', 'currentstyle'=>''];$tagSearchgrounp = new app\taglib\fox\TagSearchgrounp;$__LIST__ = $tagSearchgrounp->getList($param,'sort desc'); if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $index = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$field): $mod = ($index % 2 );++$index;?>
                        <a class="foxui-link"><?php echo $field['name']; ?></a>
                        <?php endforeach; endif; else: echo "" ;endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="foxcms-header-h5 foxui-visible-sm foxui-visible-xs">
    <div class="nav-mask"></div>
    <div class="nav-content">
        <div class="nav-head foxui-border-bottom">
            <i class="foxui-icon-liebiao-o"></i>
            <a href="/" class="foxcms-logo">
                <img style="height: 26px" src="<?php $param = ['field'=>'web_logo', 'add'=>$add];$tagBasic = new app\taglib\fox\TagBasic;$tagBasic->getList($param); ?>" alt="" />
            </a>
            <i class="foxui-icon-sousuo-o"></i>
        </div>
        <div class="nav-menu">
            <div class="nav-menu-inner">
                <ul class="foxui-collapse" data-fold="accordion">
                    <?php $param = ['typeid'=>'', 'orderbyid'=>'sort', 'limit'=>'0,5', 'sid'=>''
        , 'typeidP'=>$field["id"],'calltype'=>'self','notypeid'=>'contain','orderby'=>'admin','sortorder'=>'asc'];$model = "column";$tagNav = new app\taglib\fox\TagNav;$__LIST__ = $tagNav->getList($param,'self','admin asc','0','999');$__LIST__ = columnList($__LIST__, -1); if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $index = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$field): $mod = ($index % 2 );++$index;?>
                    <li class="foxui-collapse-item">
                        <div class="foxui-collapse-head foxui-collapse-handle">
                            <a href="<?php echo $field['link']; ?>" style="margin-right: 20px"><?php echo $field['name']; ?></a>
                            <i class="foxui-icon-xiangyou-o foxui-collapse-icon"></i>
                        </div>
                        <div class="foxui-collapse-content">
                            <ul>
                                <?php $param = ['typeid'=>'', 'orderbyid'=>'sort', 'limit'=>'', 'sid'=>''
        , 'typeidP'=>$field["id"],'calltype'=>'parent','notypeid'=>'self','orderby'=>'admin','sortorder'=>'asc'];$model = "column";$tagNav = new app\taglib\fox\TagNav;$__LIST__ = $tagNav->getList($param,'son','admin asc','0','999');$__LIST__ = columnList($__LIST__, -1); if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $index = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($index % 2 );++$index;?>
                                <li>
                                    <a class="foxui-link text-link" href="<?php echo $v['link']; ?>"><?php echo $v['name']; ?></a>
                                </li>
                                <?php endforeach; endif; else: echo "" ;endif; ?>
                            </ul>
                        </div>
                    </li>
                    <?php endforeach; endif; else: echo "" ;endif; $param = ['typeid'=>'6', 'orderbyid'=>'sort', 'limit'=>'', 'sid'=>''
        , 'typeidP'=>$field["id"],'calltype'=>'self','notypeid'=>'contain','orderby'=>'admin','sortorder'=>'asc'];$model = "column";$tagNav = new app\taglib\fox\TagNav;$__LIST__ = $tagNav->getList($param,'self','admin asc','0','999');$__LIST__ = columnList($__LIST__, -1); if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $index = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$field): $mod = ($index % 2 );++$index;?>
                    <li class="foxui-collapse-item">
                        <div class="foxui-collapse-head">
                            <a href="<?php echo $field['link']; ?>" style="margin-right: 20px"><?php echo $field['name']; ?></a>
                            <i class="foxui-icon-xiangyou-o foxui-collapse-icon right-icon"></i>
                        </div>
                    </li>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </ul>
            </div>
        </div>
        <div class="search-menu">
            <div class="search-menu-inner foxui-padding-top-20 foxui-padding-bottom-28">
                <?php $param = ['typeid'=>'','model'=>''];$tagSearchform = new app\taglib\fox\TagSearchform;$__LIST__ = $tagSearchform->getList($param); if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $index = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$field): $mod = ($index % 2 );++$index;?>
                <form method="get" action="<?php echo $field['link']; ?>">
                    <input name="fields" value="title" type="hidden" />
                    <input name="kwtype" value="1" type="hidden" />
                    <input name="keyword" placeholder="输入关键词" value="" />
                    <button class="foxui-solid-primary foxui-block foxui-margin-top-20">搜索</button>
                </form>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </div>
        </div>
    </div>
</div>
<script>
    new Swiper('.nav-swiper-image', {
        slidesPerView: 2.5,
        spaceBetween: 16,
        freeMode: true,
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
        },
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
        breakpoints: {
            992: { slidesPerView: 5.5 },
        },
    });

    $(document).on('click', '.foxcms-header-pc .search-icon', function () {
        let $container = $(this).closest('.foxcms-header-pc');
        $container.find('.nav, .phone').fadeOut(300);
        $container.find('.search').fadeIn(300);
        $container.find('.foxcms-search').slideDown(300);
    });
    $(document).on('click', '.foxcms-header-pc .search-close', function () {
        let $container = $(this).closest('.foxcms-header-pc');
        $container.find('.nav, .phone').fadeIn(300);
        $container.find('.search').fadeOut(300);
        $container.find('.foxcms-search').slideUp(300);
    });

    $(document).on('click', '.foxcms-header-pc .search-menu .list a', function () {
        $('.foxcms-header-pc .foxui-input-group input[name="keyword"]').val($(this).text());
        $('.foxcms-search input[type="submit"]').click();
    });

    $(document).on('click', '.foxcms-header-h5 .foxui-icon-liebiao-o', function () {
        let $this = $(this),
            $container = $this.closest('.foxcms-header-h5');
        $container.find('.search-menu').slideUp(300);
        $this.removeClass('foxui-icon-liebiao-o').addClass('foxui-icon-guanbi-o');
        $container.find('.nav-mask').fadeIn(300);
        $container.find('.nav-menu').slideDown(300);
        $('body').css('overflow', 'hidden');
    });
    $(document).on('click', '.foxcms-header-h5 .foxui-icon-guanbi-o', function () {
        let $this = $(this),
            $container = $this.closest('.foxcms-header-h5');
        $this.removeClass('foxui-icon-guanbi-o').addClass('foxui-icon-liebiao-o');
        $container.find('.nav-mask').fadeOut(300);
        $container.find('.nav-menu').slideUp(300);
        $('body').css('overflow', 'auto');
    });

    $(document).on('click', '.foxcms-header-h5 .nav-mask', function () {
        $('.foxcms-header-h5 .foxui-icon-guanbi-o').click();
        let $container = $(this).closest('.foxcms-header-h5');
        if ($container.find('.search-menu').css('display') === 'block') {
            $container.find('.nav-mask').fadeOut(300);
            $container.find('.search-menu').slideUp(300);
            $('body').css('overflow', 'auto');
        }
    });

    $(document).on('click', '.foxcms-header-h5 .foxui-icon-sousuo-o', function () {
        let $this = $(this),
            $container = $this.closest('.foxcms-header-h5');
        $container.find('.foxui-icon-guanbi-o').removeClass('foxui-icon-guanbi-o').addClass('foxui-icon-liebiao-o');
        $container.find('.nav-menu').slideUp(300);
        $container.find('.nav-mask').fadeIn(300);
        $container.find('.search-menu').slideDown(300);
        $('body').css('overflow', 'hidden');
    });
</script>
</header>
        <!-- 主体内容 -->
        <main class="index-main">
            <!-- 通栏图 -->
            <div class="foxcms-index-banner">
                <div class="foxcms-banner-pc foxui-hidden-sm foxui-hidden-xs">
                    <div class="swiper index-swiper-pc" style="--swiper-navigation-color: #666; --swiper-pagination-bullet-inactive-color: #666; --swiper-pagination-color: #666">
                        <div class="swiper-wrapper">
                            <?php $status=0; if($status == 1): ?>
                            <div class="swiper-slide">
                                <div class="swiper-item" style="background-image: url(<?php echo $ad['img_url']; ?>)">
                                    <div class="foxcms-container">
                                        <div class="foxui-row foxui-gutter-10">
                                            <div class="foxui-col-sm-24 foxui-col-lg-24">
                                                <div class="content left">
                                                    <h1 style="color: #333"><?php echo $ad['title']; ?></h1>
                                                    <p style="color: #666"><?php echo $ad['adv_info']; ?></p>
                                                    <a style="color: #666; border-color: #666" href="<?php echo $ad['link']; ?>" class="view-btn">
                                                        <span>查看详情</span>
                                                        <i class="foxui-icon-qianwang-o"></i>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="swiper-button-next"></div>
                        <div class="swiper-button-prev"></div>
                        <div class="swiper-pagination"></div>
                    </div>
                </div>
                <div class="foxcms-banner-h5 foxui-visible-sm foxui-visible-xs">
                    <div class="swiper index-swiper-h5" style="--swiper-navigation-color: #fff; --swiper-pagination-bullet-inactive-color: #fff; --swiper-pagination-color: #fff">
                        <div class="swiper-wrapper">
                            <?php $status=0; if($status == 1): ?>
                            <div class="swiper-slide">
                                <div class="swiper-item" style="background-image: url(<?php echo $ad['img_url']; ?>)">
                                    <div class="foxcms-container">
                                        <div class="foxui-row foxui-gutter-10">
                                            <div class="foxui-col-sm-24">
                                                <div class="content left">
                                                    <h1 style="color: #333"><?php echo $ad['title']; ?></h1>
                                                    <p style="color: #666"><?php echo $ad['adv_info']; ?></p>
                                                    <a style="color: #666; border-color: #666" href="<?php echo $ad['link']; ?>" class="view-btn">
                                                        <span>查看详情</span>
                                                        <i class="foxui-icon-qianwang-o"></i>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <!-- 案例展示 -->
            <div class="tabs-section">
                <div class="foxcms-container">
                    <?php $param = ['typeid'=>'4', 'orderbyid'=>'sort', 'limit'=>'', 'limit'=>'', 'sid'=>''
        , 'typeidP'=>$field["id"],'calltype'=>'self','notypeid'=>'contain','orderby'=>'admin','sortorder'=>'asc'];$model = "column";$tagChannel = new app\taglib\fox\TagChannel;$__LIST__ = $tagChannel->getList($param,'top','admin asc','0','999');$__LIST__ = columnList($__LIST__, -1); if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $index = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$field): $mod = ($index % 2 );++$index;?>
                    <div class="tabs-head">
                        <h1><?php echo $field['name']; ?></h1>
                        <p><?php echo $field['en_name']; ?></p>
                    </div>
                    <div class="foxui-tabs foxui-type-line foxui-position-right">
                        <div class="foxui-tabs-header">
                            <?php $param = ['typeid'=>'', 'orderbyid'=>'sort', 'limit'=>'', 'limit'=>'', 'sid'=>''
        , 'typeidP'=>$field["id"],'calltype'=>'parent','notypeid'=>'self','orderby'=>'admin','sortorder'=>'asc'];$model = "column";$tagChannel = new app\taglib\fox\TagChannel;$__LIST__ = $tagChannel->getList($param,'son','admin asc','0','999');$__LIST__ = columnList($__LIST__, -1); if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $index = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$cv): $mod = ($index % 2 );++$index;?>
                            <div class="foxui-tabs-item<?php if($index==1): ?> is-active<?php endif; ?>"><?php echo $cv['name']; ?></div>
                            <?php endforeach; endif; else: echo "" ;endif; ?>
                        </div>
                        <div class="foxui-tabs-content">
                            <?php $param = ['typeid'=>'', 'orderbyid'=>'sort', 'limit'=>'', 'limit'=>'', 'sid'=>''
        , 'typeidP'=>$field["id"],'calltype'=>'parent','notypeid'=>'self','orderby'=>'admin','sortorder'=>'asc'];$model = "column";$tagChannel = new app\taglib\fox\TagChannel;$__LIST__ = $tagChannel->getList($param,'son','admin asc','0','999');$__LIST__ = columnList($__LIST__, -1); if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $index = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$cv): $mod = ($index % 2 );++$index;?>
                            <div class="foxui-tabs-pane">
                                <div class="foxui-row foxui-gutter-1">
                                    <?php $tagArclist = new app\taglib\fox\TagArclist;$param = ['notypeid'=>'','apply'=>'article','currentstyle'=>''
        ,'typeid'=>'', 'limit'=>'', 'columnModel'=>'', 'type'=>'', 'sid'=>''
        ,  'typeidP'=>$cv["id"],'calltype'=>'parent','addfields'=>'','channel'=>''];$__LIST__ = $tagArclist->getList($param,'c','create_time desc','0','6');$__LIST__ = alterList($__LIST__,'', -1); if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $index = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$av): $mod = ($index % 2 );++$index;$model = $av["model"]; ?>
                                    <div class="foxui-col-sm-12 foxui-col-lg-8">
                                        <a href="<?php echo $av['link']; ?>" class="list-case-item" style="display: block">
                                            <div class="pic">
                                                <img src="<?php echo $av['img_url']; ?>" alt="" />
                                                <?php if($av['model'] == 'video'): ?>
                                                <i class="foxui-icon-bofang-f"></i>
                                                <?php endif; ?>
                                            </div>
                                            <div class="cover">
                                                <div class="cover-head">
                                                    <h2><?php echo $av['title']; ?></h2>
                                                </div>
                                                <div class="cover-foot">
                                                    <h3><?php echo $av['column']; ?></h3>
                                                    <p><?php echo $av['tags']; ?></p>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                    <?php endforeach; endif; else: echo "" ;endif; ?>
                                </div>
                            </div>
                            <?php endforeach; endif; else: echo "" ;endif; ?>
                        </div>
                    </div>
                    <div class="more-btn wow slideInUp" style="margin-top: 40px; margin-bottom: 80px">
                        <a class="more-plain-btn" href="<?php echo $field['link']; ?>">
                            <span>MORE</span>
                            <i class="foxui-icon-qianwang-o"></i>
                        </a>
                    </div>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </div>
            </div>
            <!-- 公司简介 -->
            <div class="company-info">
                <div class="foxui-row foxui-gutter-0">
                    <?php $param = ['typeid'=>'7', 'orderbyid'=>'sort', 'limit'=>'', 'limit'=>'', 'sid'=>''
        , 'typeidP'=>$field["id"],'calltype'=>'self','notypeid'=>'contain','orderby'=>'admin','sortorder'=>'asc'];$model = "column";$tagChannel = new app\taglib\fox\TagChannel;$__LIST__ = $tagChannel->getList($param,'self','admin asc','0','999');$__LIST__ = columnList($__LIST__, -1); if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $index = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$field): $mod = ($index % 2 );++$index;?>
                    <div class="foxui-col-md-12">
                        <div class="pic wow slideInUp">
                            <img src="<?php echo $field['pic_url']; ?>" alt="<?php $param = ['field'=>'name', 'add'=>$add];$tagBasic = new app\taglib\fox\TagBasic;$tagBasic->getList($param); ?>"/>
                        </div>
                    </div>
                    <div class="foxui-col-md-12">
                        <div class="text wow slideInUp">
                            <div class="text-inner">
                                <h1><?php echo $field['name']; ?></h1>
                                <h4><?php echo $field['en_name']; ?></h4>
                                <p><?php $param = ['sid'=>'','typeid'=>'','filed'=>'content', 'typeidP'=>$field["id"],'calltype'=>'parent','filter'=>'cn_substr,320','model'=>''];$tagSingle = new app\taglib\fox\TagSingle;$tagSingle->getList($param); ?></p>
                                <div>
                                    <a class="foxui-link" href="<?php echo $field['link']; ?>">
                                        <span>查看详情</span>
                                        <i class="foxui-icon-qianwang-o"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </div>
            </div>
            <!-- 新闻资讯 -->
            <div class="foxui-bg-white">
                <div class="tabs-section news-section">
                    <?php $param = ['typeid'=>'2', 'orderbyid'=>'sort', 'limit'=>'', 'limit'=>'', 'sid'=>''
        , 'typeidP'=>$field["id"],'calltype'=>'self','notypeid'=>'contain','orderby'=>'admin','sortorder'=>'asc'];$model = "column";$tagChannel = new app\taglib\fox\TagChannel;$__LIST__ = $tagChannel->getList($param,'top','admin asc','0','999');$__LIST__ = columnList($__LIST__, -1); if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $index = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$field): $mod = ($index % 2 );++$index;?>
                    <div class="foxcms-container">
                        <div class="tabs-head">
                            <h1><?php echo $field['name']; ?></h1>
                            <p><?php echo $field['en_name']; ?></p>
                        </div>
                        <div class="foxui-tabs foxui-type-line foxui-position-right foxui-margin-top-0">
                            <div class="foxui-tabs-header">
                                <?php $param = ['typeid'=>'', 'orderbyid'=>'sort', 'limit'=>'', 'limit'=>'', 'sid'=>''
        , 'typeidP'=>$field["id"],'calltype'=>'parent','notypeid'=>'self','orderby'=>'admin','sortorder'=>'asc'];$model = "column";$tagChannel = new app\taglib\fox\TagChannel;$__LIST__ = $tagChannel->getList($param,'son','admin asc','0','999');$__LIST__ = columnList($__LIST__, -1); if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $index = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$cv): $mod = ($index % 2 );++$index;?>
                                <div class="foxui-tabs-item<?php if($index==1): ?> is-active<?php endif; ?>"><?php echo $cv['name']; ?></div>
                                <?php endforeach; endif; else: echo "" ;endif; ?>
                            </div>
                            <div class="foxui-tabs-content">
                                <?php $param = ['typeid'=>'', 'orderbyid'=>'sort', 'limit'=>'', 'limit'=>'', 'sid'=>''
        , 'typeidP'=>$field["id"],'calltype'=>'parent','notypeid'=>'self','orderby'=>'admin','sortorder'=>'asc'];$model = "column";$tagChannel = new app\taglib\fox\TagChannel;$__LIST__ = $tagChannel->getList($param,'son','admin asc','0','999');$__LIST__ = columnList($__LIST__, -1); if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $index = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$cv): $mod = ($index % 2 );++$index;?>
                                <div class="foxui-tabs-pane">
                                    <div class="swiper recommend-swiper enterprise-swiper">
                                        <div class="swiper-wrapper">
                                            <?php $param = ['notypeid'=>'', 'typeid'=>'', 'limit'=>'', 'type'=>'self'
        , 'sid'=>'', 'typeidP'=>$cv["id"],'calltype'=>'parent'];$model = "article";$tagArticle = new app\taglib\fox\TagArticle;$__LIST__ = $tagArticle->getList($param,'c','release_time desc','0','6');$__LIST__ = alterList($__LIST__,'article', -1); if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $index = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$av): $mod = ($index % 2 );++$index;?>
                                            <div class="swiper-slide">
                                                <a href="<?php echo $av['link']; ?>" class="list-article-item wow slideInUp">
                                                    <div class="pic">
                                                        <img src="<?php echo $av['img_url']; ?>" alt="" />
                                                    </div>
                                                    <div class="text">
                                                        <div class="info">
                                                            <div class="left">
                                                                <span><?php echo $av['column']; ?></span>
                                                                <span><?php echo date('Y-m-d',!is_numeric($av['release_time'])? strtotime($av['release_time']) : $av['release_time']); ?></span>
                                                            </div>
                                                            <div class="right">
                                                                <i class="foxui-icon-xianshi-o"></i>
                                                                <span><?php echo $av['click']; ?></span>
                                                            </div>
                                                        </div>
                                                        <h1 class="foxui-ellipsis-2"><?php echo $av['title']; ?></h1>
                                                        <p class="foxui-ellipsis-3"><?php echo cn_substr($av['content'],120); ?></p>
                                                    </div>
                                                </a>
                                            </div>
                                            <?php endforeach; endif; else: echo "" ;endif; ?>
                                        </div>
                                        <div class="swiper-pagination"></div>
                                        <div class="swiper-button-prev"></div>
                                        <div class="swiper-button-next"></div>
                                    </div>
                                    <div class="more-btn" style="margin-top: 40px; margin-bottom: 40px">
                                        <a class="more-plain-btn" href="<?php echo $cv['link']; ?>">
                                            <span>MORE</span>
                                            <i class="foxui-icon-qianwang-o"></i>
                                        </a>
                                    </div>
                                </div>
                                <?php endforeach; endif; else: echo "" ;endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </div>
            </div>
            <!-- 产品中心 -->
            <div class="link-section">
                <div class="foxcms-container">
                    <?php $param = ['typeid'=>'3', 'orderbyid'=>'sort', 'limit'=>'', 'limit'=>'', 'sid'=>''
        , 'typeidP'=>$field["id"],'calltype'=>'self','notypeid'=>'contain','orderby'=>'admin','sortorder'=>'asc'];$model = "column";$tagChannel = new app\taglib\fox\TagChannel;$__LIST__ = $tagChannel->getList($param,'top','admin asc','0','999');$__LIST__ = columnList($__LIST__, -1); if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $index = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$field): $mod = ($index % 2 );++$index;?>
                    <div class="link-section-head">
                        <div class="foxui-row foxui-gutter-xs-4 foxui-gutter-sm-4 foxui-align-items-center">
                            <div class="foxui-col-sm-24 foxui-col-xs-24 foxui-col-md-8">
                                <h1><?php echo $field['name']; ?></h1>
                                <p><?php echo $field['en_name']; ?></p>
                            </div>
                            <div class="foxui-col-sm-24 foxui-col-xs-24 foxui-col-md-16">
                                <ul>
                                    <?php $param = ['typeid'=>'', 'orderbyid'=>'sort', 'limit'=>'', 'limit'=>'', 'sid'=>''
        , 'typeidP'=>$field["id"],'calltype'=>'parent','notypeid'=>'self','orderby'=>'admin','sortorder'=>'asc'];$model = "column";$tagChannel = new app\taglib\fox\TagChannel;$__LIST__ = $tagChannel->getList($param,'son','admin asc','0','999');$__LIST__ = columnList($__LIST__, -1); if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $index = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$cv): $mod = ($index % 2 );++$index;?>
                                    <li>
                                        <a class="foxui-link" href="<?php echo $cv['link']; ?>"><?php echo $cv['name']; ?></a>
                                    </li>
                                    <?php endforeach; endif; else: echo "" ;endif; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="link-section-list">
                        <div class="foxui-row foxui-gutter-6">
                            <?php $param = ['notypeid'=>'','typeid'=>'', 'limit'=>''
        , 'sid'=>'','type'=>'son',  'typeidP'=>$field["id"],'calltype'=>'parent'];$model = "product";$tagProduct = new app\taglib\fox\TagProduct;$__LIST__ = $tagProduct->getList($param,'c','release_time desc','0','8');$__LIST__ = alterList($__LIST__,'product', -1); if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $index = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$av): $mod = ($index % 2 );++$index;?>
                            <div class="foxui-col-md-12 foxui-col-lg-6">
                                <a href="<?php echo $av['link']; ?>" class="list-product-item wow slideInUp">
                                    <div class="pic">
                                        <img src="<?php echo $av['img_url']; ?>" alt="" />
                                    </div>
                                    <div class="text">
                                        <h1 class="foxui-ellipsis"><?php echo $av['title']; ?></h1>
                                        <p class="foxui-ellipsis-2"><?php echo $av['description']; ?></p>
                                        <div class="price">
                                            <span>￥</span>
                                            <strong><?php echo $av['price']; ?></strong>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <?php endforeach; endif; else: echo "" ;endif; ?>
                        </div>
                        <div class="more-btn" style="margin-top: 40px; margin-bottom: 80px">
                            <a class="more-plain-btn" href="<?php echo $field['link']; ?>">
                                <span>MORE</span>
                                <i class="foxui-icon-qianwang-o"></i>
                            </a>
                        </div>
                    </div>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </div>
            </div>
            <!-- 合作客户 -->
            <div class="more-section foxui-bg-white">
                <div class="foxcms-container">
                    <?php $param = ['typeid'=>'10', 'orderbyid'=>'sort', 'limit'=>'', 'limit'=>'', 'sid'=>''
        , 'typeidP'=>$field["id"],'calltype'=>'self','notypeid'=>'contain','orderby'=>'admin','sortorder'=>'asc'];$model = "column";$tagChannel = new app\taglib\fox\TagChannel;$__LIST__ = $tagChannel->getList($param,'self','admin asc','0','999');$__LIST__ = columnList($__LIST__, -1); if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $index = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$field): $mod = ($index % 2 );++$index;?>
                    <div class="more-section-head">
                        <div class="title">
                            <h1><?php echo $field['name']; ?></h1>
                            <p><?php echo $field['en_name']; ?></p>
                        </div>
                        <div class="more-btn">
                            <a class="more-plain-btn" href="<?php echo $field['link']; ?>">
                                <span>MORE</span>
                                <i class="foxui-icon-qianwang-o"></i>
                            </a>
                        </div>
                    </div>
                    <div class="more-section-list">
                        <div class="list-customer foxui-row foxui-gutter-0">
                            <?php $param = ['notypeid'=>'', 'typeid'=>'', 'limit'=>'', 'type'=>'self'
        , 'sid'=>'', 'typeidP'=>$field["id"],'calltype'=>'parent'];$model = "article";$tagArticle = new app\taglib\fox\TagArticle;$__LIST__ = $tagArticle->getList($param,'c','release_time desc','0','12');$__LIST__ = alterList($__LIST__,'article', -1); if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $index = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$av): $mod = ($index % 2 );++$index;?>
                            <div class="col foxui-col-xs-12 foxui-col-sm-8 foxui-col-lg-6 foxui-col-xxl-4">
                                <div class="pic wow slideInUp">
                                    <img src="<?php echo $av['img_url']; ?>" alt="" />
                                </div>
                            </div>
                            <?php endforeach; endif; else: echo "" ;endif; ?>
                        </div>
                    </div>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </div>
            </div>
            <!-- 需求表单 -->
            <div class="foxcms-container requried-container">
                <div class="foxui-bg-white required-form wow slideInUp">
                    <form id="requiredForm" action="/plus/Diyform/receive" method="post">
                        <input type="hidden" name="id" style="flex: 1" value="1" />
                        <div class="foxui-row foxui-gutter-6">
                            <div class="foxui-col-sm-12 foxui-col-lg-4">
                                <div class="input-item">
                                    <input type="text" name="text0" placeholder="阁下贵姓" autocomplete="off" value="" />
                                </div>
                            </div>
                            <div class="foxui-col-sm-12 foxui-col-lg-4">
                                <div class="input-item">
                                    <input type="text" name="text1" placeholder="手机号码" autocomplete="off" value="" />
                                </div>
                            </div>
                            <div class="foxui-col-sm-24 foxui-col-lg-12">
                                <div class="input-item">
                                    <input type="text" name="text2" placeholder="告诉我们您的需求" autocomplete="off" value="" />
                                </div>
                            </div>
                            <div class="foxui-col-sm-24 foxui-col-lg-4">
                                <div class="input-item">
                                    <button class="foxui-solid-primary foxui-block submit-btn">
                                        <span>需求提交</span>
                                        <i class="foxui-icon-qianwang-o"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <input type="submit" value="提交" style="display: none" />
                    </form>
                </div>
            </div>
            <!-- 右侧浮动内容 -->
            <div class="foxcms-fixed-container"><div class="foxcms-fixed-content foxui-hidden-xs">
    <ul class="fixed-nav">
        <li>
            <div class="edit">
                <a class="icon foxui-link message">
                    <i class="foxui-icon-bianji-o"></i>
                </a>
            </div>
        </li>
        <li>
            <a class="icon foxui-link kefu" href="<?php $param = ['field'=>'customer_url'];$tagContact = new app\taglib\fox\TagContact;$tagContact->getList($param); ?>">
                <i class="foxui-icon-kefu-o"></i>
            </a>
        </li>
        <li>
            <a class="icon foxui-link ewm">
                <i class="foxui-icon-erweima-o"></i>
            </a>
        </li>
        <li>
            <a class="icon foxui-link phone">
                <i class="foxui-icon-dianhua-o"></i>
            </a>
        </li>
    </ul>
    <div class="fixed-top">
        <i class="foxui-icon-xiangxia-o"></i>
        <span>TOP</span>
    </div>
</div>

<script>
    $(function () {
        foxui.confirmtip({
            el: '.fixed-nav .message',
            title: '留言给我们',
            content: _messageHtml(),
            width: '340px',
            placement: ['left', 'center'],
            className: 'fixed-btn-wrapper message-wrapper',
        });

        foxui.confirmtip({
            el: '.fixed-nav .ewm',
            content: `<img src="<?php $param = ['field'=>'qr_code1'];$tagContact = new app\taglib\fox\TagContact;$tagContact->getList($param); ?>"/>`,
            trigger: 'hover',
            placement: ['left', 'center'],
            className: 'fixed-btn-wrapper',
        });

        foxui.confirmtip({
            el: '.fixed-nav .phone',
            content: `<p class="phone"><i class="foxui-icon-shouji-f"></i><span><?php $param = ['field'=>'phone'];$tagContact = new app\taglib\fox\TagContact;$tagContact->getList($param); ?></span></p>`,
            trigger: 'hover',
            placement: ['left', 'center'],
            className: 'fixed-btn-wrapper',
        });
    });

    $(document).on('click', '.foxcms-fixed-container .fixed-top', function () {
        $(window).scrollTop(0);
    });

    function _messageHtml() {
        return [
            '<div class="message">',
            '<form action="/plus/Diyform/receive" method="post">',
            '<input type="hidden" name="id" style="flex: 1" value="1" />',
            '<div class="input-item">',
            '<input type="text" name="text0" placeholder="阁下贵姓" autocomplete="off" value="" />',
            '</div>',
            '<div class="input-item">',
            '<input type="text" name="text1" placeholder="手机号码" autocomplete="off" value="" />',
            '</div>',
            '<div class="input-item">',
            '<input type="text" name="text2" placeholder="告诉我们您的需求" autocomplete="off" value="" />',
            '</div>',
            '<div class="input-item submit-item">',
            '<button class="foxui-solid-primary foxui-block submit-btn">',
            '<span>提交留言</span>',
            '</button>',
            '</div>',
            '</form>',
            '</div>',
        ].join('');
    }
</script>
</div>
        </main>
        <!-- 底部 -->
        <footer class="wow slideInUp"><div class="foxcms-container foxcms-footer-pc foxui-hidden-sm foxui-hidden-xs">
    <div class="footer-nav">
        <ul class="left">
            <?php $param = ['typeid'=>'', 'orderbyid'=>'sort', 'limit'=>'0,5', 'sid'=>''
        , 'typeidP'=>$field["id"],'calltype'=>'self','notypeid'=>'contain','orderby'=>'admin','sortorder'=>'asc'];$model = "column";$tagNav = new app\taglib\fox\TagNav;$__LIST__ = $tagNav->getList($param,'self','admin asc','0','999');$__LIST__ = columnList($__LIST__, -1); if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $index = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$field): $mod = ($index % 2 );++$index;?>
            <li>
                <dl>
                    <dt><?php echo $field['name']; ?></dt>
                    <?php $param = ['typeid'=>'', 'orderbyid'=>'sort', 'limit'=>'', 'sid'=>''
        , 'typeidP'=>$field["id"],'calltype'=>'parent','notypeid'=>'self','orderby'=>'admin','sortorder'=>'asc'];$model = "column";$tagNav = new app\taglib\fox\TagNav;$__LIST__ = $tagNav->getList($param,'son','admin asc','0','999');$__LIST__ = columnList($__LIST__, -1); if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $index = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($index % 2 );++$index;?>
                    <dd>
                        <a href="<?php echo $v['link']; ?>"><?php echo $v['name']; ?></a>
                    </dd>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </dl>
            </li>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </ul>

    </div>


</div>
<div class="foxcms-footer-h5 foxui-visible-sm foxui-visible-xs">
    <div class="footer-nav">
        <ul class="foxui-collapse" data-fold="accordion">
            <?php $param = ['typeid'=>'', 'orderbyid'=>'sort', 'limit'=>'0,5', 'sid'=>''
        , 'typeidP'=>$field["id"],'calltype'=>'self','notypeid'=>'contain','orderby'=>'admin','sortorder'=>'asc'];$model = "column";$tagNav = new app\taglib\fox\TagNav;$__LIST__ = $tagNav->getList($param,'self','admin asc','0','999');$__LIST__ = columnList($__LIST__, -1); if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $index = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$field): $mod = ($index % 2 );++$index;?>
            <li class="foxui-collapse-item">
                <div class="foxui-collapse-head foxui-collapse-handle">
                    <span style="margin-right: 20px"><?php echo $field['name']; ?></span>
                    <i class="foxui-icon-xiangyou-o foxui-collapse-icon"></i>
                </div>
                <div class="foxui-collapse-content">
                    <ul>
                        <?php $param = ['typeid'=>'', 'orderbyid'=>'sort', 'limit'=>'', 'sid'=>''
        , 'typeidP'=>$field["id"],'calltype'=>'parent','notypeid'=>'self','orderby'=>'admin','sortorder'=>'asc'];$model = "column";$tagNav = new app\taglib\fox\TagNav;$__LIST__ = $tagNav->getList($param,'son','admin asc','0','999');$__LIST__ = columnList($__LIST__, -1); if(is_array($__LIST__) || $__LIST__ instanceof \think\Collection || $__LIST__ instanceof \think\Paginator): $index = 0; $__LIST__ = $__LIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($index % 2 );++$index;?>
                        <li>
                            <a href="<?php echo $v['link']; ?>"><?php echo $v['name']; ?></a>
                        </li>
                        <?php endforeach; endif; else: echo "" ;endif; ?>
                    </ul>
                </div>
            </li>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </ul>
    </div>

</div>
</footer>
    </body>
    <script src="/templates/skin/js/foxui-1.21.min.js"></script>
    <script src="/templates/skin/js/common.js"></script>
    <script src="/templates/skin/js/form.js"></script>

    <script>
        setTimeout(() => {
            new Swiper('.index-swiper-pc', {
                loop: true,
                autoplay: true,
                pagination: {
                    el: '.index-swiper-pc .swiper-pagination',
                },
                navigation: {
                    nextEl: '.index-swiper-pc .swiper-button-next',
                    prevEl: '.index-swiper-pc .swiper-button-prev',
                },
            });

            new Swiper('.index-swiper-h5', {
                loop: true,
                autoplay: true,
            });

            new Swiper('.enterprise-swiper', {
                slidesPerView: 1,
                spaceBetween: 30,
                breakpoints: {
                    991: { slidesPerView: 3 },
                },
                pagination: {
                    el: '.enterprise-swiper .swiper-pagination',
                    clickable: true,
                },
                navigation: {
                    nextEl: '.enterprise-swiper .swiper-button-next',
                    prevEl: '.enterprise-swiper .swiper-button-prev',
                },
            });

            new Swiper('.industry-swiper', {
                slidesPerView: 1,
                spaceBetween: 30,
                breakpoints: {
                    991: { slidesPerView: 3 },
                },
                pagination: {
                    el: '.industry-swiper .swiper-pagination',
                    clickable: true,
                },
                navigation: {
                    nextEl: '.industry-swiper .swiper-button-next',
                    prevEl: '.industry-swiper .swiper-button-prev',
                },
            });

            new Swiper('.media-swiper', {
                slidesPerView: 1,
                spaceBetween: 30,
                breakpoints: {
                    991: { slidesPerView: 3 },
                },
                pagination: {
                    el: '.media-swiper .swiper-pagination',
                    clickable: true,
                },
                navigation: {
                    nextEl: '.media-swiper .swiper-button-next',
                    prevEl: '.media-swiper .swiper-button-prev',
                },
            });
        }, 300);
    </script>
</html>
