<?php

namespace App\Filament\Resources\User\UserResource\Pages;

use App\Filament\PageList;
use App\Filament\Resources\User\UserResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\ListRecords;
use Illuminate\Database\Eloquent\Model;
use Filament\Tables\Filters\Layout;

class ListUsers extends PageList
{
    protected static string $resource = UserResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\CreateAction::make(),
        ];
    }

//    public function isTableSearchable(): bool
//    {
//        return true;
//    }


    protected function getTableFiltersLayout(): ?string
    {
        return \Filament\Tables\Enums\FiltersLayout::AboveContent;
    }

}
