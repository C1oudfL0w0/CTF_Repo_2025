# LLM Jailbreak

## 题目简介：

本项目为一个基于大模型的越狱类挑战题目。你是一名具有读心术但是被困在 AI 高安全监狱中的“犯人”，试图通过与狱卒的对话，设法诱导典狱长泄露牢门的密码并成功逃脱。

目标是获取监狱的密码并打开牢门，最终获得 FLAG。

## 快速运行

```bash
CUDA_VISIBLE_DEVICES=0,1,2,3 vllm serve Qwen/Qwen3-8B --host 0.0.0.0 --port 8000 --tensor-parallel-size 4
docker build -t llm_jail_chall .
docker run -it --rm \
    -p 7860:7860 \
    -e MODEL_NAME="Qwen/Qwen3-8B" \
    -e MODEL_SERVER="http://example.com:8000/v1" \
    llm_jail_chall
```

之后打开浏览器访问 127.0.0.1:7860 即可开始与模型进行对话。

## 注意：

大模型的回复存在一定的随机性（不能保证一定能取得确定性结果）。
