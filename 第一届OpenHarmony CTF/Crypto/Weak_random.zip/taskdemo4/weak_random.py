from secret import flag
import time
import os
import random
from Crypto.Util.number import *
from Crypto.Cipher import AES
import os
import hashlib

assert(len(flag)==32)

def padding(message):
    padding_len = 16 - len(message)%16
    ret = hex(padding_len)[2:].zfill(2)
    return bytes.fromhex(ret*padding_len)+message

def get_weak_entropy():
    time_now=time.time()%10000

    entropy_part1 = int(time_now) & 0xFFFF 

    entropy_part2 = os.getpid() & 0xFF

    final_seed = entropy_part1 + (entropy_part2 << 8) 
    random.seed(final_seed)
    
    key = random.getrandbits(128) 

    return key
entropy_key=get_weak_entropy()
iv = os.urandom(16)
key_bytes = entropy_key.to_bytes(16, byteorder='big')
msg=padding(flag.encode())
aes = AES.new(key_bytes,AES.MODE_CBC,iv=iv)
enc = aes.encrypt(msg)
print(enc.hex())
check=hashlib.sha256(flag.encode('utf-8')).hexdigest()  
print(check)
#enc=f3f040958bc8cbba6b7ccd87d77d54bb12200603a81fed2bf31cc5598127e0c9e97e971082e742c7a013ca4df2040f5a
#check=9d0df2157e9072272fb70bafc948336bf8c5e7532629a4d4887e9c74e74f204a